from typing import Any

from . import container_ocr as core


def _empty_result() -> dict[str, Any]:
    return {
        "raw_text": "",
        "base10": "",
        "check_digit": "",
        "full_code": "",
        "score": -1.0,
        "is_valid_iso": False,
        "status": "NOT_FOUND",
    }


def ocr_horizontal_container_regions(
    expanded,
    *,
    enable_resize_digit_pass: bool = True,
    enable_oneline_slow_fallback: bool = True,
) -> dict[str, Any]:
    core.logger.info("route: enter _ocr_horizontal_container_regions")
    best_raw = ""

    letters_zone = core._extract_zone(expanded, 0.02, 0.40, 0.02, 0.98)
    owner = ""
    owner_score = -1.0
    owner_raw = ""
    if letters_zone is not None and letters_zone.size:
        letter_passes = [(core._preprocess_fast(letters_zone), 0.0)]
        for prepared, phase_bonus in letter_passes:
            pairs = core._extract_text_pairs(core._run_ocr(prepared))
            if pairs and len(" ".join(text for text, _ in pairs)) > len(best_raw):
                best_raw = " ".join(text for text, _ in pairs).strip()
            local_owner, local_score, local_raw = core._best_owner_code_from_pairs(pairs)
            if local_owner:
                final = local_score + phase_bonus
                if final > owner_score:
                    owner = local_owner
                    owner_score = final
                    owner_raw = local_raw
        needs_hard_letters = len(owner) != 4 or owner_score < 1.145 or len(core.clean(owner_raw)) != 4
        if needs_hard_letters:
            pairs = core._extract_text_pairs(core._run_ocr(core._preprocess_hard(letters_zone)))
            if pairs and len(" ".join(text for text, _ in pairs)) > len(best_raw):
                best_raw = " ".join(text for text, _ in pairs).strip()
            local_owner, local_score, local_raw = core._best_owner_code_from_pairs(pairs)
            if local_owner and local_score > owner_score:
                owner = local_owner
                owner_score = local_score
                owner_raw = local_raw

    numeric_candidates: list[dict[str, Any]] = []
    fast_digit_zones: list[tuple[Any, float, float]] = []
    digit_specs_fast = [
        (0.30, 1.00, core._preprocess_fast, 0.03),
        (0.34, 1.00, core._preprocess_fast, 0.02),
        (0.40, 1.00, core._preprocess_fast, 0.00),
    ]
    for x1, x2, preprocessor, phase_bonus in digit_specs_fast:
        zone = core._extract_zone(expanded, x1, x2, 0.02, 0.98)
        if zone is None or not zone.size:
            continue
        pairs = core._extract_text_pairs(core._run_ocr(preprocessor(zone)))
        if pairs and len(" ".join(text for text, _ in pairs)) > len(best_raw):
            best_raw = " ".join(text for text, _ in pairs).strip()
        numeric_candidates.extend(core._numeric_region_candidates(pairs, phase_bonus=phase_bonus))
        fast_digit_zones.append((zone, phase_bonus, x1))

    base6, check_digit, numeric_score, numeric_raw, numeric_meta = core._pick_best_numeric_candidate(numeric_candidates)

    has_zero_check_votes = numeric_meta.get("check_vote_count", 0) <= 0
    needs_resize_digits = (
        not base6
        or (not check_digit and not has_zero_check_votes)
        or (
            check_digit
            and not numeric_meta["has_direct_full"]
            and numeric_meta.get("check_margin", 0.0) < 1.02
        )
    )
    if enable_resize_digit_pass and needs_resize_digits:
        resize_digit_zones = fast_digit_zones
        if check_digit and numeric_meta.get("check_vote_count", 0) <= 1:
            resize_digit_zones = [item for item in fast_digit_zones if item[2] <= 0.30]
        for zone, phase_bonus, _x1 in resize_digit_zones:
            pairs = core._collect_strip_pairs(zone, phase_bonus=phase_bonus, profile="light")
            if pairs and len(" ".join(text for text, _ in pairs)) > len(best_raw):
                best_raw = " ".join(text for text, _ in pairs).strip()
            numeric_candidates.extend(core._numeric_region_candidates(pairs, phase_bonus=phase_bonus))
        base6, check_digit, numeric_score, numeric_raw, numeric_meta = core._pick_best_numeric_candidate(numeric_candidates)

    needs_hard_digits = (
        not base6
        or not check_digit
        or (
            not numeric_meta["has_direct_full"]
            and numeric_meta["check_vote_count"] > 1
            and numeric_meta.get("check_margin", 0.0) < 0.90
        )
    )
    if needs_hard_digits:
        digit_specs_hard = [
            (0.30, 1.00, core._preprocess_hard, 0.01),
            (0.34, 1.00, core._preprocess_hard, 0.02),
            (0.40, 1.00, core._preprocess_hard, 0.00),
        ]
        for x1, x2, preprocessor, phase_bonus in digit_specs_hard:
            zone = core._extract_zone(expanded, x1, x2, 0.02, 0.98)
            if zone is None or not zone.size:
                continue
            pairs = core._extract_text_pairs(core._run_ocr(preprocessor(zone)))
            if pairs and len(" ".join(text for text, _ in pairs)) > len(best_raw):
                best_raw = " ".join(text for text, _ in pairs).strip()
            numeric_candidates.extend(core._numeric_region_candidates(pairs, phase_bonus=phase_bonus))
        base6, check_digit, numeric_score, numeric_raw, numeric_meta = core._pick_best_numeric_candidate(numeric_candidates)

    should_consult_square = bool(
        base6
        and (
            not check_digit
            or (
                not numeric_meta.get("has_direct_full")
                and (
                    numeric_meta.get("check_vote_count", 0) <= 0
                    or numeric_meta.get("check_margin", 0.0) < 1.00
                )
            )
        )
    )
    if should_consult_square:
        right_side_votes = core._collect_right_check_digit_votes(expanded, include_zone=False)
        resolved_digit, resolved_score, resolved_meta = core._resolve_check_digit_for_base(base6, numeric_candidates, right_side_votes)
        if resolved_digit:
            check_digit = resolved_digit
            numeric_score = max(numeric_score, resolved_score)
            numeric_meta["resolved_vote_count"] = resolved_meta["vote_count"]
            numeric_meta["resolved_margin"] = resolved_meta["margin"]
            numeric_meta["resolved_direct_count"] = resolved_meta["direct_count"]
            numeric_meta["resolved_square_count"] = resolved_meta["square_count"]
    else:
        numeric_meta["resolved_vote_count"] = 0
        numeric_meta["resolved_margin"] = 0.0
        numeric_meta["resolved_direct_count"] = 0
        numeric_meta["resolved_square_count"] = 0

    full_code = ""
    base10 = ""
    if owner and base6:
        base10 = f"{owner}{base6}"
        if not check_digit and core._CONTAINER10_RE.fullmatch(base10):
            check_digit = str(core._iso6346_check_digit(base10))
        full_code = f"{base10}{check_digit}" if check_digit else base10

    if owner_raw and numeric_raw:
        best_raw = f"{owner_raw} {numeric_raw}".strip()
    elif owner_raw:
        best_raw = owner_raw
    elif numeric_raw:
        best_raw = numeric_raw

    combined_score = max(owner_score, 0.0) + max(numeric_score, 0.0)
    legacy_result = {
        "raw_text": best_raw,
        "base10": base10,
        "check_digit": check_digit if full_code and len(full_code) == 11 else "",
        "full_code": full_code,
        "score": float(combined_score),
        "is_valid_iso": bool(len(full_code) == 11 and core._is_valid_iso6346(full_code)),
        "status": "FULL_11"
        if len(full_code) == 11
        else ("PARTIAL_10" if len(full_code) == 10 else ("RAW_ONLY" if best_raw else "NOT_FOUND")),
    }
    if not enable_oneline_slow_fallback:
        return legacy_result

    legacy_status = str(legacy_result.get("status") or "")
    legacy_valid = bool(legacy_result.get("is_valid_iso"))
    if legacy_status == "FULL_11" and legacy_valid:
        return legacy_result

    oneline_3zone_result = core._ocr_oneline_3zone_regions(expanded)
    three_zone_valid = bool(oneline_3zone_result.get("is_valid_iso"))
    if three_zone_valid and not legacy_valid:
        return oneline_3zone_result
    if oneline_3zone_result.get("base10") and not legacy_result.get("base10"):
        return oneline_3zone_result
    if core._result_structure_rank(oneline_3zone_result) > core._result_structure_rank(legacy_result):
        return oneline_3zone_result
    return legacy_result
