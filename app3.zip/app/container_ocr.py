from __future__ import annotations

import hashlib
import json
import logging
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from collections import OrderedDict
from pathlib import Path
from typing import Any, Optional

os.environ.setdefault("PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK", "True")
os.environ.setdefault("FLAGS_use_mkldnn", "0")
os.environ.setdefault("FLAGS_enable_pir_in_executor", "0")
os.environ.setdefault("FLAGS_enable_pir_api", "0")

_DLL_DIR_HANDLES: list[Any] = []


def _configure_windows_gpu_dlls() -> None:
    if os.name != "nt":
        return

    paddle_device = os.getenv("PADDLE_DEVICE", "cpu").strip().lower()
    if not paddle_device.startswith("gpu"):
        return

    site_packages = Path(sys.prefix) / "Lib" / "site-packages"
    candidate_dirs = [
        site_packages / "nvidia" / "cu13" / "bin" / "x86_64",
        site_packages / "nvidia" / "cu13" / "bin",
        site_packages / "nvidia" / "cu13" / "lib" / "x64",
        site_packages / "nvidia" / "cudnn" / "bin",
    ]

    existing_dirs = [path for path in candidate_dirs if path.exists()]
    if not existing_dirs:
        return

    os.environ["PATH"] = ";".join([*(str(path) for path in existing_dirs), os.environ.get("PATH", "")])
    for path in existing_dirs:
        try:
            _DLL_DIR_HANDLES.append(os.add_dll_directory(str(path)))
        except (AttributeError, FileNotFoundError, OSError):
            continue


_configure_windows_gpu_dlls()

import cv2
import numpy as np
from paddleocr import PaddleOCR

from .container_layout import classify_container_layout, extract_split_door_rois, extract_two_line_rois, foreground_mask, merge_bands

logger = logging.getLogger("container_ocr")

EARLY_OK = float(os.getenv("OCR_EARLY_OK", "0.93"))
CACHE_SIZE = int(os.getenv("OCR_CACHE_SIZE", "256"))
HORIZONTAL_RATIO_THRESHOLD = float(os.getenv("OCR_HORIZONTAL_RATIO_THRESHOLD", "3.2"))

VERTICAL_RATIO_THRESHOLD = float(os.getenv("OCR_VERTICAL_RATIO_THRESHOLD", "0.22"))

SPECIALIZED_OCR_SETTINGS: dict[str, Any] = {
    "routing": {
        "enable_specialized_routes": True,
        "auto_low_res_video_like": True,
    },
    "low_res_video_like": {
        "laplacian_var_threshold": 120.0,
        "min_short_side": 220,
        "expand_left_ratio": 0.14,
        "expand_right_ratio": 0.16,
        "expand_top_ratio": 0.09,
        "expand_bottom_ratio": 0.10,
    },
    "split_door_4_2_box": {
        "enabled": True,
        "min_aspect_ratio": 1.55,
        "max_aspect_ratio": 3.20,
        "seam_window": (0.38, 0.62),
        "seam_brightness_percentile": 85.0,
        "seam_brightness_margin": 5.0,
        "right_box_zone": (0.76, 1.00, 0.00, 1.00),
        "prefer_full_code_bonus": 1.50,
        "prefer_check_digit_bonus": 0.60,
        "enable_two_lines_hard_fallback": True,
        "enable_resize_digit_pass": False,
    },
    "vertical_narrow_boxed": {
        "enabled": True,
        "max_aspect_ratio": 0.23,
        "min_height": 700,
        "bottom_box_zone": (0.00, 1.00, 0.84, 1.00),
        "expand_left_ratio": 0.08,
        "expand_right_ratio": 0.08,
        "expand_top_ratio": 0.04,
        "expand_bottom_ratio": 0.12,
        "prefer_full_code_bonus": 1.20,
        "prefer_check_digit_bonus": 0.80,
        "straight_ratio_threshold": 0.90,
        "normalize_min_abs_angle_deg": 1.2,
        "normalize_max_abs_angle_deg": 20.0,
        "normalize_pad_x_ratio": 0.16,
        "normalize_pad_top_ratio": 0.05,
        "normalize_pad_bottom_ratio": 0.14,
    },
}

BASE_DIR = Path(__file__).resolve().parent
MODELS_DIR = (BASE_DIR / ".." / "models" / "paddleocr").resolve()
DET_MODEL_DIR = Path(os.getenv("PADDLE_DET_MODEL_DIR", MODELS_DIR / "PP-OCRv5_server_det"))
REC_MODEL_DIR = Path(os.getenv("PADDLE_REC_MODEL_DIR", MODELS_DIR / "en_PP-OCRv5_mobile_rec"))
TEXTLINE_ORI_MODEL_DIR = Path(os.getenv("PADDLE_TEXTLINE_ORI_MODEL_DIR", MODELS_DIR / "PP-LCNet_x1_0_textline_ori"))
DOC_ORI_MODEL_DIR = Path(
    os.getenv("PADDLE_DOC_ORI_MODEL_DIR", MODELS_DIR / "PP-LCNet_x1_0_doc_ori")
)
DOC_UNWARP_MODEL_DIR = Path(os.getenv("PADDLE_DOC_UNWARP_MODEL_DIR", MODELS_DIR / "UVDoc"))
_TESSERACT_EXE_CACHE: str | None = None


def _ensure_gray(img: np.ndarray) -> np.ndarray:
    if img is None or img.size == 0:
        return img
    if len(img.shape) == 2:
        return img
    return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)


def _ensure_bgr(img: np.ndarray) -> np.ndarray:
    if img is None or img.size == 0:
        return img
    if len(img.shape) == 2:
        return cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    return img


def _build_ocr() -> PaddleOCR:
    cpu_threads = max(1, int(os.getenv("PADDLE_CPU_THREADS", "2")))
    kwargs: dict[str, Any] = {
        "lang": "en",
        "use_textline_orientation": True,
        "device": os.getenv("PADDLE_DEVICE", "cpu"),
        "enable_hpi": False,
        "enable_mkldnn": False,
        "cpu_threads": cpu_threads,
    }

    if DET_MODEL_DIR.exists() and REC_MODEL_DIR.exists():
        kwargs["text_detection_model_dir"] = str(DET_MODEL_DIR)
        kwargs["text_recognition_model_dir"] = str(REC_MODEL_DIR)
    if TEXTLINE_ORI_MODEL_DIR.exists():
        kwargs["textline_orientation_model_dir"] = str(TEXTLINE_ORI_MODEL_DIR)
    if DOC_ORI_MODEL_DIR.exists():
        kwargs["doc_orientation_classify_model_dir"] = str(DOC_ORI_MODEL_DIR)
    if DOC_UNWARP_MODEL_DIR.exists():
        kwargs["doc_unwarping_model_dir"] = str(DOC_UNWARP_MODEL_DIR)

    return PaddleOCR(**kwargs)


def _resolve_tesseract_executable() -> str:
    global _TESSERACT_EXE_CACHE
    if _TESSERACT_EXE_CACHE is not None:
        return _TESSERACT_EXE_CACHE

    candidates = [
        os.getenv("TESSERACT_EXE", "").strip(),
        str((BASE_DIR / ".." / ".." / "third_party" / "tesseract" / "tesseract.exe").resolve()),
        r"C:\Program Files\Tesseract-OCR\tesseract.exe",
        shutil.which("tesseract") or "",
    ]
    for candidate in candidates:
        if candidate and Path(candidate).exists():
            _TESSERACT_EXE_CACHE = candidate
            return candidate

    _TESSERACT_EXE_CACHE = ""
    return _TESSERACT_EXE_CACHE


ocr = _build_ocr()

_CLEAN_RE = re.compile(r"[^A-Z0-9]+")
_CONTAINER_RE = re.compile(r"[A-Z]{4}\d{7}")
_CONTAINER10_RE = re.compile(r"[A-Z]{4}\d{6}")
_DIGIT_CHUNK_RE = re.compile(r"\d+")
_CACHE: "OrderedDict[str, tuple[str, float, bool, dict[str, Any]]]" = OrderedDict()

_TO_LETTER = {
    "0": "O",
    "1": "I",
    "2": "Z",
    "3": "B",
    "4": "A",
    "5": "S",
    "6": "G",
    "7": "Z",
    "8": "B",
}

_TO_DIGIT = {
    "O": "0",
    "Q": "0",
    "D": "0",
    "U": "0",
    "I": "1",
    "L": "1",
    "Z": "2",
    "S": "5",
    "B": "8",
    "G": "6",
}


def clean(s: str) -> str:
    return _CLEAN_RE.sub("", s.upper())


def _preprocess_fast(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    gray = clahe.apply(gray)
    return cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)


def _preprocess_hard(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.bilateralFilter(gray, 5, 40, 40)
    clahe = cv2.createCLAHE(clipLimit=2.2, tileGridSize=(8, 8))
    gray = clahe.apply(gray)
    thr = cv2.adaptiveThreshold(
        gray,
        255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        31,
        3,
    )
    return cv2.cvtColor(thr, cv2.COLOR_GRAY2BGR)


def _run_ocr(img):
    if hasattr(ocr, "predict"):
        try:
            return ocr.predict(img)
        except Exception:
            # Fallback for environments where PaddleOCR v3 predict path fails on CPU runtime.
            if hasattr(ocr, "ocr"):
                return ocr.ocr(img)
            raise
    return ocr.ocr(img)


def _get_text_rec_model():
    try:
        return ocr.paddlex_pipeline._pipeline.text_rec_model
    except Exception:
        return None


def _run_text_recognition_batch(images: list[Any]) -> list[tuple[str, float]]:
    samples = [_ensure_bgr(img) for img in images if img is not None and getattr(img, "size", 0)]
    if not samples:
        return []

    rec_model = _get_text_rec_model()
    if rec_model is None:
        out: list[tuple[str, float]] = []
        for img in samples:
            pairs = _extract_text_pairs(_run_ocr(img))
            if pairs:
                out.append(max(pairs, key=lambda item: item[1]))
            else:
                out.append(("", 0.0))
        return out

    results: list[tuple[str, float]] = []
    try:
        predicted = list(rec_model.predict(samples, batch_size=len(samples)))
    except Exception:
        predicted = []

    if not predicted:
        for img in samples:
            pairs = _extract_text_pairs(_run_ocr(img))
            if pairs:
                results.append(max(pairs, key=lambda item: item[1]))
            else:
                results.append(("", 0.0))
        return results

    for item in predicted:
        payload = getattr(item, "json", {})
        if isinstance(payload, dict):
            res = payload.get("res", {})
        else:
            res = {}
        text = clean(str(res.get("rec_text") or ""))
        try:
            score = float(res.get("rec_score") or 0.0)
        except Exception:
            score = 0.0
        results.append((text, score))
    return results


def _letter_value(ch: str) -> int:
    value = 10
    for letter in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
        if value % 11 == 0:
            value += 1
        if letter == ch:
            return value
        value += 1
    raise ValueError(f"Unsupported letter: {ch}")


def _iso6346_check_digit(code10: str) -> int:
    total = 0
    for pos, ch in enumerate(code10):
        if ch.isdigit():
            value = int(ch)
        else:
            value = _letter_value(ch)
        total += value * (2 ** pos)

    remainder = total % 11
    return 0 if remainder == 10 else remainder


def _is_valid_iso6346(code11: str) -> bool:
    code11 = clean(code11)
    if not _CONTAINER_RE.fullmatch(code11):
        return False
    expected = _iso6346_check_digit(code11[:10])
    actual = int(code11[10])
    return expected == actual


def _force_owner_category_u(prefix: str) -> str:
    prefix = "".join(_TO_LETTER.get(ch, ch) for ch in clean(prefix))
    if len(prefix) < 4:
        return prefix
    return f"{prefix[:3]}U"


def _normalize_window_to_container(part: str) -> Optional[str]:
    part = clean(part)
    if len(part) != 11:
        return None

    prefix = _force_owner_category_u(part[:4])
    suffix = "".join(_TO_DIGIT.get(ch, ch) for ch in part[4:])
    candidate = prefix + suffix
    if _CONTAINER_RE.fullmatch(candidate):
        return candidate
    return None


def _normalized_candidates(raw: str) -> list[str]:
    s = clean(raw)
    if len(s) < 11:
        return []

    out = []
    seen = set()
    for i in range(len(s) - 10):
        part = s[i:i + 11]
        candidate = _normalize_window_to_container(part)
        if candidate and candidate not in seen:
            seen.add(candidate)
            out.append(candidate)
    return out


def _normalize_window_to_container10(part: str) -> Optional[str]:
    part = clean(part)
    if len(part) != 10:
        return None

    prefix = _force_owner_category_u(part[:4])
    suffix = "".join(_TO_DIGIT.get(ch, ch) for ch in part[4:])
    candidate = prefix + suffix
    if _CONTAINER10_RE.fullmatch(candidate):
        return candidate
    return None


def _normalized_base_candidates(raw: str) -> list[str]:
    s = clean(raw)
    if len(s) < 10:
        return []

    out = []
    seen = set()
    for i in range(len(s) - 9):
        part = s[i:i + 10]
        candidate = _normalize_window_to_container10(part)
        if candidate and candidate not in seen:
            seen.add(candidate)
            out.append(candidate)

    # Reordered blocks are common on crops: e.g. "438607TCKU" should become "TCKU438607".
    for m in re.finditer(r"\d{6}[A-Z]{4}", s):
        part = m.group(0)
        candidate = _normalize_window_to_container10(part[6:] + part[:6])
        if candidate and candidate not in seen:
            seen.add(candidate)
            out.append(candidate)

    # Heuristic pairing for slightly noisy OCR streams with separated alpha/digit groups.
    alpha_blocks = [m.group(0) for m in re.finditer(r"[A-Z]{4,}", s)]
    digit_blocks = [m.group(0) for m in re.finditer(r"\d{6,}", s)]
    for a in alpha_blocks:
        for d in digit_blocks:
            candidate = _normalize_window_to_container10(a[:4] + d[:6])
            if candidate and candidate not in seen:
                seen.add(candidate)
                out.append(candidate)
    return out


def _extract_result_json(pred_item) -> dict:
    payload = getattr(pred_item, "json", pred_item)
    if isinstance(payload, str):
        try:
            return json.loads(payload)
        except Exception:
            return {}
    if isinstance(payload, dict):
        return payload
    return {}


def _extract_text_pairs_from_predict(j: dict) -> list[tuple[str, float]]:
    res = j.get("res", {})
    texts = res.get("rec_texts", []) or []
    scores = res.get("rec_scores", []) or []

    pairs = []
    for raw_text, raw_score in zip(texts, scores):
        text = clean(str(raw_text))
        if not text:
            continue
        try:
            score = float(raw_score)
        except Exception:
            score = 0.0
        pairs.append((text, score))
    return pairs


def _extract_text_pairs(result) -> list[tuple[str, float]]:
    if not result:
        return []

    if isinstance(result, list) and result and hasattr(result[0], "json"):
        return _extract_text_pairs_from_predict(_extract_result_json(result[0]))

    pairs = []
    lines = result[0] if isinstance(result, list) and result else []
    for line in lines or []:
        if not line or len(line) < 2:
            continue
        text = clean(str(line[1][0]))
        if not text:
            continue
        pairs.append((text, float(line[1][1])))
    return pairs


def _text_pair_preview(text_pairs: list[tuple[str, float]], *, limit: int = 8) -> list[dict[str, Any]]:
    preview: list[dict[str, Any]] = []
    for text, score in text_pairs[:limit]:
        preview.append(
            {
                "text": str(text),
                "score": round(float(score), 4),
            }
        )
    return preview


def _candidate_groups(text_pairs: list[tuple[str, float]]) -> list[tuple[str, float]]:
    if not text_pairs:
        return []

    groups: list[tuple[str, float]] = []
    seen = set()
    texts = [t for t, _ in text_pairs]
    scores = [s for _, s in text_pairs]
    n = len(texts)

    def add_candidate(raw: str, score: float):
        key = (raw, round(score, 6))
        if raw and key not in seen:
            seen.add(key)
            groups.append((raw, score))

    for text, score in text_pairs:
        add_candidate(text, score)

    add_candidate("".join(texts), sum(scores) / max(1, len(scores)))
    add_candidate(" ".join(texts), sum(scores) / max(1, len(scores)))

    for size in range(2, min(7, n + 1)):
        for i in range(n - size + 1):
            joined = "".join(texts[i:i + size])
            avg_score = sum(scores[i:i + size]) / size
            add_candidate(joined, avg_score)

    return groups


def _container_text_quality(code: str) -> float:
    if not code:
        return 0.0

    code = clean(code)
    if not _CONTAINER_RE.fullmatch(code):
        return 0.0

    score = 0.85
    if code[:4].isalpha():
        score += 0.05
    if code[4:].isdigit():
        score += 0.05
    if _is_valid_iso6346(code):
        score += 0.05
    return min(1.0, score)


def _container_base_quality(code10: str) -> float:
    code10 = clean(code10)
    if not _CONTAINER10_RE.fullmatch(code10):
        return 0.0
    score = 0.8
    if code10[:4].isalpha():
        score += 0.1
    if code10[4:].isdigit():
        score += 0.1
    return min(1.0, score)


def _is_horizontal_crop(img) -> bool:
    if img is None or img.size == 0:
        return False
    h, w = img.shape[:2]
    if h <= 0:
        return False
    return (w / float(h)) >= HORIZONTAL_RATIO_THRESHOLD


def _is_vertical_crop(img) -> bool:
    if img is None or img.size == 0:
        return False
    h, w = img.shape[:2]
    if h <= 0:
        return False
    return (w / float(h)) <= VERTICAL_RATIO_THRESHOLD


def _laplacian_variance(img) -> float:
    if img is None or img.size == 0:
        return 0.0
    gray = _ensure_gray(img)
    try:
        return float(cv2.Laplacian(gray, cv2.CV_64F).var())
    except Exception:
        return 0.0


def _looks_like_low_res_video_frame(img, config: Optional[dict[str, Any]] = None) -> bool:
    if img is None or img.size == 0:
        return False
    cfg = SPECIALIZED_OCR_SETTINGS["low_res_video_like"]
    h, w = img.shape[:2]
    short_side = min(h, w)
    blur_score = _laplacian_variance(img)
    return short_side <= int(cfg["min_short_side"]) or blur_score <= float(cfg["laplacian_var_threshold"])


def _bright_seam_near_center(img, *, x_from: float, x_to: float, percentile: float, margin: float) -> bool:
    if img is None or img.size == 0:
        return False
    gray = _ensure_gray(img)
    col_strength = gray.mean(axis=0).astype(np.float32)
    w = col_strength.shape[0]
    x1 = max(0, int(w * x_from))
    x2 = min(w, int(w * x_to))
    if x2 - x1 < 6:
        return False
    window = col_strength[x1:x2]
    if window.size == 0:
        return False
    seam_value = float(window.max())
    baseline = float(np.percentile(col_strength, percentile))
    return seam_value >= (baseline + margin)


def _boxed_digit_present_in_zone(img, zone: tuple[float, float, float, float]) -> bool:
    roi = _extract_zone(img, *zone)
    if roi is None or roi.size == 0:
        return False
    try:
        return len(_square_like_roi_entries(roi)) > 0
    except Exception:
        return False


def _detect_split_door_4_2_box(img, config: Optional[dict[str, Any]] = None) -> bool:
    if img is None or img.size == 0:
        return False
    cfg = SPECIALIZED_OCR_SETTINGS["split_door_4_2_box"]
    h, w = img.shape[:2]
    ratio = w / float(max(1, h))
    if ratio < float(cfg["min_aspect_ratio"]) or ratio > float(cfg["max_aspect_ratio"]):
        return False
    if not _boxed_digit_present_in_zone(img, tuple(cfg["right_box_zone"])):
        return False
    seam_x1, seam_x2 = tuple(cfg["seam_window"])
    return _bright_seam_near_center(
        img,
        x_from=float(seam_x1),
        x_to=float(seam_x2),
        percentile=float(cfg["seam_brightness_percentile"]),
        margin=float(cfg["seam_brightness_margin"]),
    )


def _detect_vertical_narrow_boxed(img, config: Optional[dict[str, Any]] = None) -> bool:
    if img is None or img.size == 0:
        return False
    cfg = SPECIALIZED_OCR_SETTINGS["vertical_narrow_boxed"]
    h, w = img.shape[:2]
    ratio = w / float(max(1, h))
    if h < int(cfg["min_height"]):
        return False
    if ratio > float(cfg["max_aspect_ratio"]):
        return False
    return _boxed_digit_present_in_zone(img, tuple(cfg["bottom_box_zone"]))


def _result_structure_rank(
    result: dict[str, Any],
    *,
    prefer_full_code_bonus: float = 1.0,
    prefer_check_digit_bonus: float = 0.5,
) -> float:
    rank = float(result.get("score", -1.0))
    if result.get("raw_text"):
        rank += 0.8
    if result.get("base10"):
        rank += 5.0
    if result.get("check_digit"):
        rank += float(prefer_check_digit_bonus)
    if result.get("full_code") and len(str(result.get("full_code") or "")) == 11:
        rank += float(prefer_full_code_bonus)
    if result.get("is_valid_iso"):
        rank += 2.0
    status = str(result.get("status") or "")
    if status == "PARTIAL_10":
        rank += 1.2
    elif status == "FULL_11":
        rank += 2.2
    return rank


def _read_bottom_boxed_digit(img, config: Optional[dict[str, Any]] = None) -> tuple[str, float]:
    if img is None or img.size == 0:
        return "", -1.0
    cfg = SPECIALIZED_OCR_SETTINGS["vertical_narrow_boxed"]
    zone = tuple(cfg["bottom_box_zone"])
    bottom = _extract_zone(img, *zone)
    if bottom is None or bottom.size == 0:
        return "", -1.0

    best_digit = ""
    best_score = -1.0
    for _rect, roi in _square_like_roi_entries(bottom):
        digit, score = _read_digit_from_roi(roi, square_bias=True)
        if digit and score > best_score:
            best_digit = digit
            best_score = score
    return best_digit, best_score


def _ocr_split_door_4_2_box(img, config: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    from . import container_ocr_twolines as twolines

    return twolines.ocr_split_door_4_2_box(img, config=config)

def _ocr_vertical_narrow_boxed(img, config: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    from . import container_ocr_vertical as vertical

    return vertical.ocr_vertical_narrow_boxed(img, config=config)


def _vertical_resize_keep(img, target_h: int = 1800):
    if img is None or img.size == 0:
        return img
    h, _w = img.shape[:2]
    if h >= target_h:
        return img
    scale = target_h / float(max(1, h))
    return cv2.resize(img, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)


def _vertical_make_char_mask(img):
    if img is None or img.size == 0:
        return np.zeros((1, 1), dtype=np.uint8)

    gray = _ensure_gray(img)
    clahe = cv2.createCLAHE(clipLimit=2.5, tileGridSize=(8, 8))
    gray = clahe.apply(gray)

    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (19, 19))
    tophat = cv2.morphologyEx(gray, cv2.MORPH_TOPHAT, kernel)
    blur = cv2.GaussianBlur(tophat, (3, 3), 0)

    _thr, mask = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    close_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 5))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, close_kernel, iterations=1)

    legacy = _vertical_foreground_mask(img)
    if legacy is not None and legacy.size:
        mask = cv2.bitwise_or(mask, legacy)
    return mask


def _vertical_estimate_column_rotation(mask) -> float:
    if mask is None or mask.size == 0:
        return 0.0

    num, _labels, stats, centroids = cv2.connectedComponentsWithStats(mask, 8)
    h, w = mask.shape[:2]

    pts = []
    min_area = max(12.0, 0.00025 * h * w)
    for i in range(1, num):
        x, y, ww, hh, area = stats[i]
        if area < min_area:
            continue
        if hh < 0.02 * h or ww < 0.025 * w:
            continue
        if ww > 0.75 * w:
            continue
        pts.append(centroids[i])

    if len(pts) < 3:
        return 0.0

    pts_np = np.array(pts, dtype=np.float32)
    vx, vy, _x0, _y0 = cv2.fitLine(pts_np, cv2.DIST_L2, 0, 0.01, 0.01).flatten()
    angle_deg = math.degrees(math.atan2(float(vy), float(vx)))
    rotate_deg = 90.0 - angle_deg
    return max(min(rotate_deg, 20.0), -20.0)


def _vertical_rotate_bound(img, angle: float):
    if img is None or img.size == 0 or abs(angle) < 0.15:
        return img

    h, w = img.shape[:2]
    cx, cy = w / 2.0, h / 2.0
    matrix = cv2.getRotationMatrix2D((cx, cy), angle, 1.0)

    cos = abs(matrix[0, 0])
    sin = abs(matrix[0, 1])
    new_w = int((h * sin) + (w * cos))
    new_h = int((h * cos) + (w * sin))

    matrix[0, 2] += (new_w / 2.0) - cx
    matrix[1, 2] += (new_h / 2.0) - cy

    return cv2.warpAffine(
        img,
        matrix,
        (new_w, new_h),
        flags=cv2.INTER_CUBIC,
        borderMode=cv2.BORDER_REPLICATE,
    )


def _vertical_alignment_boxes(img) -> list[tuple[int, int, int, int]]:
    if img is None or img.size == 0:
        return []
    try:
        mask = _vertical_make_char_mask(img)
        boxes = _vertical_find_char_boxes(img, mask)
    except Exception:
        boxes = []
    if not boxes:
        return []

    h, w = img.shape[:2]
    heights = [box[3] for box in boxes]
    median_h = float(np.median(heights)) if heights else 0.0
    max_h = max(int(h * 0.30), int(round(median_h * 2.8)) if median_h > 0 else 0)
    filtered = [
        box for box in boxes
        if box[3] <= max_h
        and box[2] <= int(w * 0.65)
        and (box[2] * box[3]) <= int(h * w * 0.18)
    ]
    if len(filtered) >= 2:
        return filtered
    return boxes


def _vertical_axis_warp_crop(
    img,
    boxes: list[tuple[int, int, int, int]],
    *,
    pad_x_ratio: float,
    pad_top_ratio: float,
    pad_bottom_ratio: float,
):
    if img is None or img.size == 0 or len(boxes) < 2:
        return None

    mask = _vertical_foreground_mask(img)
    focus_bbox = _vertical_focus_bbox(mask)
    if focus_bbox is None:
        focus_bbox = _foreground_bbox_from_mask(_vertical_projection_mask(mask), pad=4)
    if focus_bbox is None:
        return None

    fx1, fy1, fx2, fy2 = focus_bbox
    focus_mask = mask[fy1:fy2, fx1:fx2]
    ys, xs = np.where(focus_mask > 0)
    if xs.size < 20 or ys.size < 20:
        return None

    points = np.column_stack((xs.astype(np.float32) + float(fx1), ys.astype(np.float32) + float(fy1)))
    line = cv2.fitLine(points, cv2.DIST_L2, 0, 0.01, 0.01)
    vx, vy, x0, y0 = [float(v) for v in line.flatten()]
    axis_unit = np.array([vx, vy], dtype=np.float32)
    axis_norm = float(np.linalg.norm(axis_unit))
    if axis_norm < 1e-6:
        return None
    axis_unit = axis_unit / axis_norm
    if axis_unit[1] < 0.0:
        axis_unit = -axis_unit
    # For this dataset the column should preserve the original left/right order;
    # using the opposite perpendicular flips the crop horizontally.
    perp_unit = np.array([axis_unit[1], -axis_unit[0]], dtype=np.float32)
    axis_center = np.array([x0, y0], dtype=np.float32)

    rel_points = points - axis_center
    along = rel_points @ axis_unit
    across = rel_points @ perp_unit

    axis_len = max(8.0, float(along.max() - along.min()))
    text_h = max(1.0, float(along.max() - along.min()))
    text_w = max(1.0, float(across.max() - across.min()))
    widths = [float(w) for _x, _y, w, _h in boxes]
    heights = [float(h) for _x, _y, _w, h in boxes]
    median_h = float(np.median(heights)) if heights else max(12.0, axis_len / 11.0)
    median_w = float(np.median(widths)) if widths else text_w

    pad_x = max(6.0, max(text_w, median_w) * pad_x_ratio)
    pad_top = max(10.0, max(median_h * 1.15, text_h * max(pad_top_ratio, 0.10)))
    pad_bottom = max(6.0, max(median_h * 0.9, text_h * pad_bottom_ratio))

    min_along = float(along.min()) - pad_top
    max_along = float(along.max()) + pad_bottom
    min_across = float(across.min()) - pad_x
    max_across = float(across.max()) + pad_x

    dst_h = max(16, int(round(max_along - min_along)))
    dst_w = max(16, int(round(max_across - min_across)))

    top_left = axis_center + (axis_unit * min_along) + (perp_unit * min_across)
    top_right = axis_center + (axis_unit * min_along) + (perp_unit * max_across)
    bottom_right = axis_center + (axis_unit * max_along) + (perp_unit * max_across)
    bottom_left = axis_center + (axis_unit * max_along) + (perp_unit * min_across)

    src = np.array([top_left, top_right, bottom_right, bottom_left], dtype=np.float32)
    dst = np.array(
        [
            [0.0, 0.0],
            [float(dst_w - 1), 0.0],
            [float(dst_w - 1), float(dst_h - 1)],
            [0.0, float(dst_h - 1)],
        ],
        dtype=np.float32,
    )

    matrix = cv2.getPerspectiveTransform(src, dst)
    warped = cv2.warpPerspective(
        img,
        matrix,
        (dst_w, dst_h),
        flags=cv2.INTER_CUBIC,
        borderMode=cv2.BORDER_REPLICATE,
    )
    if warped is None or warped.size == 0:
        return None

    mask = _vertical_make_char_mask(warped)
    bbox = _foreground_bbox_from_mask(mask, pad=3)
    if bbox is not None:
        x1, y1, x2, y2 = bbox
        extra_top = max(6, int(round((y2 - y1) * 0.12)))
        tightened = warped[max(0, y1 - extra_top):y2, x1:x2]
        if tightened is not None and tightened.size:
            warped = tightened
    return warped


def _normalize_vertical_column_crop(
    img,
    config: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    empty = {
        "image": img,
        "applied": False,
        "angle_deg": 0.0,
        "first_width_ratio": 0.0,
        "boxes_before": 0,
        "boxes_after": 0,
        "reason": "not_available",
    }
    if img is None or img.size == 0:
        return empty

    cfg = SPECIALIZED_OCR_SETTINGS["vertical_narrow_boxed"]
    runtime_cfg = dict(config or {})
    straight_threshold = float(runtime_cfg.get("vertical_straight_ratio_threshold", cfg["straight_ratio_threshold"]))
    min_abs_angle = float(runtime_cfg.get("vertical_normalize_min_abs_angle_deg", cfg["normalize_min_abs_angle_deg"]))
    max_abs_angle = float(runtime_cfg.get("vertical_normalize_max_abs_angle_deg", cfg["normalize_max_abs_angle_deg"]))
    pad_x_ratio = float(runtime_cfg.get("vertical_normalize_pad_x_ratio", cfg["normalize_pad_x_ratio"]))
    pad_top_ratio = float(runtime_cfg.get("vertical_normalize_pad_top_ratio", cfg["normalize_pad_top_ratio"]))
    pad_bottom_ratio = float(runtime_cfg.get("vertical_normalize_pad_bottom_ratio", cfg["normalize_pad_bottom_ratio"]))

    h, w = img.shape[:2]
    boxes_before = _vertical_alignment_boxes(img)
    if len(boxes_before) < 2:
        result = dict(empty)
        result["reason"] = "insufficient_boxes_before"
        result["boxes_before"] = len(boxes_before)
        return result

    top_box = min(boxes_before, key=lambda item: (item[1], item[0]))
    bottom_box = max(boxes_before, key=lambda item: (item[1] + item[3], item[0]))
    first_width_ratio = float(top_box[2]) / float(max(1, w))

    if first_width_ratio >= straight_threshold:
        result = dict(empty)
        result["reason"] = "already_straight"
        result["first_width_ratio"] = first_width_ratio
        result["boxes_before"] = len(boxes_before)
        result["boxes_after"] = len(boxes_before)
        return result

    top_center_x = float(top_box[0]) + (float(top_box[2]) * 0.5)
    top_center_y = float(top_box[1]) + (float(top_box[3]) * 0.5)
    bottom_center_x = float(bottom_box[0]) + (float(bottom_box[2]) * 0.5)
    bottom_center_y = float(bottom_box[1]) + (float(bottom_box[3]) * 0.5)
    dy = bottom_center_y - top_center_y
    if abs(dy) < 8.0:
        result = dict(empty)
        result["reason"] = "small_vertical_span"
        result["first_width_ratio"] = first_width_ratio
        result["boxes_before"] = len(boxes_before)
        result["boxes_after"] = len(boxes_before)
        return result

    axis_angle_from_x = math.degrees(math.atan2(dy, bottom_center_x - top_center_x))
    rotate_deg = 90.0 - axis_angle_from_x
    rotate_deg = max(-max_abs_angle, min(max_abs_angle, rotate_deg))

    if abs(rotate_deg) < min_abs_angle:
        result = dict(empty)
        result["reason"] = "angle_too_small"
        result["angle_deg"] = float(rotate_deg)
        result["first_width_ratio"] = first_width_ratio
        result["boxes_before"] = len(boxes_before)
        result["boxes_after"] = len(boxes_before)
        return result

    aligned = _vertical_rotate_bound(img, rotate_deg)
    boxes_after = _vertical_alignment_boxes(aligned)

    crop_x1 = 0
    crop_y1 = 0
    crop_x2 = aligned.shape[1]
    crop_y2 = aligned.shape[0]
    mask = _vertical_make_char_mask(aligned)
    bbox = _vertical_focus_bbox(mask)
    if bbox is None:
        bbox = _foreground_bbox_from_mask(mask, pad=4)
    if bbox is not None:
        x1, y1, x2, y2 = bbox
        text_w = max(1, x2 - x1)
        text_h = max(1, y2 - y1)
        pad_x = max(6, int(round(text_w * pad_x_ratio)))
        pad_top = max(6, int(round(text_h * pad_top_ratio)))
        pad_bottom = max(6, int(round(text_h * pad_bottom_ratio)))
        crop_x1 = max(0, x1 - pad_x)
        crop_y1 = max(0, y1 - pad_top)
        crop_x2 = min(aligned.shape[1], x2 + pad_x)
        crop_y2 = min(aligned.shape[0], y2 + pad_bottom)

    cropped = aligned[crop_y1:crop_y2, crop_x1:crop_x2]

    if cropped is None or cropped.size == 0:
        result = dict(empty)
        result["reason"] = "empty_crop_after_rotate"
        result["angle_deg"] = float(rotate_deg)
        result["first_width_ratio"] = first_width_ratio
        result["boxes_before"] = len(boxes_before)
        result["boxes_after"] = len(boxes_after)
        return result

    return {
        "image": cropped,
        "applied": True,
        "angle_deg": float(rotate_deg),
        "first_width_ratio": first_width_ratio,
        "boxes_before": len(boxes_before),
        "boxes_after": len(boxes_after),
        "reason": "rotated_and_cropped",
    }


def _vertical_find_char_boxes(img, mask) -> list[tuple[int, int, int, int]]:
    if img is None or img.size == 0 or mask is None or mask.size == 0:
        return []

    h, w = mask.shape[:2]
    col_sum = mask.sum(axis=0).astype(np.float32)
    if col_sum.size == 0 or not np.any(col_sum > 0):
        return []
    col_sum = cv2.GaussianBlur(col_sum.reshape(1, -1), (1, 31), 0).reshape(-1)
    x_peak = int(np.argmax(col_sum))

    band_half = max(20, int(w * 0.18))
    x0 = max(0, x_peak - band_half)
    x1 = min(w, x_peak + band_half)
    roi = mask[:, x0:x1]
    if roi.size == 0:
        return []

    num, _labels, stats, _centroids = cv2.connectedComponentsWithStats(roi, 8)
    boxes: list[tuple[int, int, int, int]] = []
    min_area = max(10.0, 0.00018 * h * w)
    min_h = max(10, int(h * 0.018))
    min_w = max(4, int((x1 - x0) * 0.04))

    for i in range(1, num):
        x, y, ww, hh, area = stats[i]
        if area < min_area:
            continue
        if hh < min_h or ww < min_w:
            continue
        if ww > 0.65 * w:
            continue
        boxes.append((int(x + x0), int(y), int(ww), int(hh)))

    boxes.sort(key=lambda item: item[1])
    merged: list[tuple[int, int, int, int]] = []
    same_col_tol = 0.18 * w
    max_gap = max(2, int(0.008 * h))
    max_merged_h = max(48, int(0.16 * h))
    for box in boxes:
        if not merged:
            merged.append(box)
            continue

        px, py, pw, ph = merged[-1]
        x, y, ww, hh = box
        prev_bottom = py + ph
        cur_bottom = y + hh
        overlap = min(prev_bottom, cur_bottom) - max(py, y)
        gap = y - prev_bottom
        prev_cx = px + (pw / 2.0)
        cur_cx = x + (ww / 2.0)
        same_column = abs(prev_cx - cur_cx) < same_col_tol

        candidate_h = max(prev_bottom, cur_bottom) - min(py, y)
        if same_column and candidate_h <= max_merged_h and (overlap > 0 or gap < max_gap):
            nx = min(px, x)
            ny = min(py, y)
            nr = max(px + pw, x + ww)
            nb = max(py + ph, y + hh)
            merged[-1] = (int(nx), int(ny), int(nr - nx), int(nb - ny))
        else:
            merged.append(box)
    return merged


def _vertical_crop_char(img, box: tuple[int, int, int, int]):
    if img is None or img.size == 0:
        return None

    x, y, w, h = box
    H, W = img.shape[:2]
    pad_x = max(4, int(w * 0.25))
    pad_y = max(4, int(h * 0.20))

    x0 = max(0, x - pad_x)
    y0 = max(0, y - pad_y)
    x1 = min(W, x + w + pad_x)
    y1 = min(H, y + h + pad_y)
    patch = img[y0:y1, x0:x1].copy()
    if patch.size == 0:
        return None

    ph, pw = patch.shape[:2]
    max_patch_side = 320
    max_dim = max(ph, pw)
    if max_dim > max_patch_side:
        scale = max_patch_side / float(max_dim)
        patch = cv2.resize(
            patch,
            (max(8, int(round(pw * scale))), max(8, int(round(ph * scale)))),
            interpolation=cv2.INTER_AREA,
        )
        ph, pw = patch.shape[:2]

    side = max(16, int(max(ph, pw) * 1.25))
    canvas = np.full((side, side, 3), 255, dtype=np.uint8)
    oy = (side - ph) // 2
    ox = (side - pw) // 2
    canvas[oy:oy + ph, ox:ox + pw] = patch
    return canvas


def _vertical_recognize_char_roi(roi, pos: int) -> tuple[str, float]:
    if roi is None or roi.size == 0:
        return "", -1.0

    if pos <= 3:
        letter_v, score_v = _paddle_letter_from_roi_vertical(roi)
        letter_f, score_f = _paddle_letter_from_roi(roi)
        if score_v >= score_f:
            return "".join(_TO_LETTER.get(ch, ch) for ch in clean(letter_v)[:1]), float(score_v)
        return "".join(_TO_LETTER.get(ch, ch) for ch in clean(letter_f)[:1]), float(score_f)

    if pos == 10:
        digit, score = _read_digit_from_roi(roi, square_bias=True)
        return "".join(_TO_DIGIT.get(ch, ch) for ch in clean(digit)[:1]), float(score)

    digit, score = _paddle_digit_from_roi(roi)
    return "".join(_TO_DIGIT.get(ch, ch) for ch in clean(digit)[:1]), float(score)


def _ocr_vertical_container_regions_charwise(img) -> dict[str, Any]:
    from . import container_ocr_vertical as vertical

    return vertical.ocr_vertical_container_regions_charwise(img)


def _vertical_foreground_mask(img):
    gray = _ensure_gray(img)
    clahe = cv2.createCLAHE(clipLimit=2.2, tileGridSize=(8, 8))
    gray = clahe.apply(gray)
    _, mask = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    if np.count_nonzero(mask) > (mask.size * 0.5):
        mask = 255 - mask
    kernel = np.ones((2, 2), dtype=np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    mask = cv2.dilate(mask, kernel, iterations=1)
    return mask


def _vertical_projection_mask(mask):
    if mask is None or mask.size == 0:
        return mask
    h, w = mask.shape[:2]
    work = mask.copy()
    border_x = max(2, int(round(w * 0.08)))
    border_y = max(2, int(round(h * 0.01)))
    work[:, :border_x] = 0
    work[:, w - border_x:] = 0
    work[:border_y, :] = 0
    work[h - border_y:, :] = 0
    return work


def _vertical_focus_bbox(mask) -> Optional[tuple[int, int, int, int]]:
    if mask is None or mask.size == 0:
        return None

    h, w = mask.shape[:2]
    work = _vertical_projection_mask(mask)
    if work is None or work.size == 0:
        return None

    col_strength = np.count_nonzero(work, axis=0).astype(np.float32)
    if not np.any(col_strength > 0):
        return None

    col_lo = int(round(w * 0.08))
    col_hi = max(col_lo + 1, int(round(w * 0.92)))
    central_cols = col_strength[col_lo:col_hi]
    col_threshold = max(2.0, float(np.percentile(central_cols, 55)) * 0.55)
    xs = np.where(col_strength >= col_threshold)[0]
    if xs.size == 0:
        return None

    x1 = max(0, int(xs.min()) - 4)
    x2 = min(w, int(xs.max()) + 5)
    if x2 <= x1:
        return None

    row_strength = np.count_nonzero(work[:, x1:x2], axis=1).astype(np.float32)
    if not np.any(row_strength > 0):
        return None
    row_strength = cv2.GaussianBlur(row_strength.reshape(-1, 1), (1, 9), 0).reshape(-1)
    row_threshold = max(2.0, float(np.percentile(row_strength, 30)) * 0.45)
    ys = np.where(row_strength >= row_threshold)[0]
    if ys.size == 0:
        return None

    y1 = max(0, int(ys.min()) - 4)
    y2 = min(h, int(ys.max()) + 5)
    if y2 <= y1:
        return None
    return x1, y1, x2, y2


def _merge_vertical_bands(bands: list[tuple[int, int]], max_gap: int) -> list[tuple[int, int]]:
    if not bands:
        return []
    merged = [bands[0]]
    for start, end in bands[1:]:
        prev_start, prev_end = merged[-1]
        if start - prev_end <= max_gap:
            merged[-1] = (prev_start, end)
        else:
            merged.append((start, end))
    return merged


def _split_vertical_band_by_projection(
    row_strength: np.ndarray,
    start: int,
    end: int,
    parts: int,
) -> list[tuple[int, int]]:
    length = end - start
    if parts <= 1 or length <= 0:
        return [(start, end)]

    segment = row_strength[start:end].astype(np.float32)
    if segment.size == 0:
        return [(start, end)]

    smoothed = cv2.GaussianBlur(segment.reshape(-1, 1), (1, 7), 0).reshape(-1)
    min_part_h = max(10, int(length / max(parts * 2, 2)))
    boundaries = [0]

    for part_idx in range(1, parts):
        target = int(round(length * part_idx / parts))
        window = max(6, int(length / max(parts * 3, 3)))
        lo = max(boundaries[-1] + min_part_h, target - window)
        hi = min(length - ((parts - part_idx) * min_part_h), target + window)
        if hi <= lo:
            cut = target
        else:
            cut = lo + int(np.argmin(smoothed[lo:hi]))
        boundaries.append(cut)

    boundaries.append(length)
    out: list[tuple[int, int]] = []
    for local_start, local_end in zip(boundaries, boundaries[1:]):
        if (local_end - local_start) >= 8:
            out.append((start + local_start, start + local_end))
    return out if len(out) > 1 else [(start, end)]


def _refine_vertical_bands(
    row_strength: np.ndarray,
    bands: list[tuple[int, int]],
    img_h: int,
) -> list[tuple[int, int]]:
    if not bands:
        return []

    min_band_h = max(8, int(img_h * 0.015))
    band_heights = [end - start for start, end in bands if (end - start) >= min_band_h]
    if not band_heights:
        return bands

    short_heights = [height for height in band_heights if height <= np.percentile(band_heights, 70)]
    typical_h = int(np.median(short_heights or band_heights))
    typical_h = max(min_band_h, typical_h)

    refined: list[tuple[int, int]] = []
    for start, end in bands:
        height = end - start
        parts = 1
        if height >= int(typical_h * 1.6):
            parts = max(2, min(6, int(round(height / float(typical_h)))))
        if parts > 1:
            refined.extend(_split_vertical_band_by_projection(row_strength, start, end, parts))
        else:
            refined.append((start, end))
    return refined


def _extract_vertical_symbol_rois(img) -> list[Any]:
    if img is None or img.size == 0:
        return []

    mask = _vertical_foreground_mask(img)
    work_mask = _vertical_projection_mask(mask)
    h, w = work_mask.shape[:2]
    focus_bbox = _vertical_focus_bbox(mask)
    focus_x1 = max(0, int(round(w * 0.16)))
    focus_x2 = min(w, int(round(w * 0.84)))
    if focus_bbox is not None:
        focus_x1 = max(0, focus_bbox[0])
        focus_x2 = min(w, focus_bbox[2])
    if focus_x2 <= focus_x1:
        focus_x1, focus_x2 = 0, w

    row_strength = np.count_nonzero(work_mask[:, focus_x1:focus_x2], axis=1).astype(np.float32)
    if row_strength.size == 0:
        return []
    row_strength = cv2.GaussianBlur(row_strength.reshape(-1, 1), (1, 9), 0).reshape(-1)
    row_threshold = max(
        2.0,
        float(np.percentile(row_strength, 45)) * 0.72,
        float(focus_x2 - focus_x1) * 0.06,
    )

    bands: list[tuple[int, int]] = []
    in_band = False
    start = 0
    for idx, value in enumerate(row_strength):
        if value >= row_threshold and not in_band:
            start = idx
            in_band = True
        elif value < row_threshold and in_band:
            bands.append((start, idx))
            in_band = False
    if in_band:
        bands.append((start, h))

    raw_bands = [(int(y1), int(y2)) for y1, y2 in bands]
    refined_bands = _refine_vertical_bands(row_strength, raw_bands, h)
    merged_bands = _merge_vertical_bands(refined_bands or raw_bands, max_gap=max(1, int(h * 0.004)))

    band_sets = [raw_bands, refined_bands, merged_bands]
    non_empty_band_sets = [candidate for candidate in band_sets if candidate]
    if not non_empty_band_sets:
        return []
    bands = min(
        non_empty_band_sets,
        key=lambda candidate: (
            0 if 10 <= len(candidate) <= 12 else 1,
            abs(len(candidate) - 11),
            -len(candidate),
        ),
    )

    rois: list[Any] = []
    min_band_h = max(8, int(h * 0.015))
    for y1, y2 in bands:
        if (y2 - y1) < min_band_h:
            continue
        band_mask = work_mask[max(0, y1 - 1):min(h, y2 + 1), :]
        cols = np.where(np.count_nonzero(band_mask, axis=0) > 0)[0]
        if cols.size == 0:
            continue
        x1 = max(0, int(cols[0]) - 4)
        x2 = min(w, int(cols[-1]) + 5)
        roi = img[max(0, y1 - 3):min(h, y2 + 3), x1:x2]
        if roi.size == 0:
            continue
        rois.append(roi)
    return rois


def _foreground_bbox_from_mask(mask, pad: int = 2) -> Optional[tuple[int, int, int, int]]:
    if mask is None or mask.size == 0:
        return None
    ys, xs = np.where(mask > 0)
    if ys.size == 0 or xs.size == 0:
        return None
    h, w = mask.shape[:2]
    x1 = max(0, int(xs.min()) - pad)
    y1 = max(0, int(ys.min()) - pad)
    x2 = min(w, int(xs.max()) + pad + 1)
    y2 = min(h, int(ys.max()) + pad + 1)
    if x2 <= x1 or y2 <= y1:
        return None
    return x1, y1, x2, y2


def _tight_foreground_crop(roi, *, square_inner: bool = False, pad: int = 4):
    if roi is None or roi.size == 0:
        return roi

    source = roi
    if square_inner:
        inner = _safe_inner_crop(roi, margin_ratio=0.14)
        if inner is not None and inner.size:
            source = inner

    mask = _vertical_foreground_mask(source)
    bbox = _foreground_bbox_from_mask(mask, pad=max(0, int(pad)))
    if bbox is None:
        return source
    x1, y1, x2, y2 = bbox
    cropped = source[y1:y2, x1:x2]
    return cropped if cropped.size else source


def _compose_symbol_strip(
    rois: list[Any],
    *,
    target_h: int = 92,
    gap: int = 12,
    outer_pad: int = 12,
    square_last: bool = False,
):
    if not rois:
        return None

    prepared: list[Any] = []
    for idx, roi in enumerate(rois):
        cropped = _tight_foreground_crop(roi, square_inner=square_last and idx == len(rois) - 1)
        if cropped is None or cropped.size == 0:
            continue
        h, w = cropped.shape[:2]
        if h <= 0 or w <= 0:
            continue
        scale = target_h / float(h)
        resized = cv2.resize(
            cropped,
            (max(1, int(round(w * scale))), target_h),
            interpolation=cv2.INTER_CUBIC,
        )
        prepared.append(resized)

    if not prepared:
        return None

    canvas_h = target_h + (outer_pad * 2)
    total_w = (outer_pad * 2) + sum(img.shape[1] for img in prepared) + (gap * max(0, len(prepared) - 1))
    canvas = np.zeros((canvas_h, total_w, 3), dtype=np.uint8)

    x = outer_pad
    for img in prepared:
        y = (canvas_h - img.shape[0]) // 2
        canvas[y:y + img.shape[0], x:x + img.shape[1]] = img
        x += img.shape[1] + gap
    return canvas


def _vertical_grid_rois(img, parts: int) -> list[Any]:
    if img is None or img.size == 0 or parts < 10:
        return []

    mask = _vertical_foreground_mask(img)
    bbox = _vertical_focus_bbox(mask)
    if bbox is None:
        bbox = _foreground_bbox_from_mask(_vertical_projection_mask(mask), pad=4)
    if bbox is None:
        return []

    x1, y1, x2, y2 = bbox
    crop = img[y1:y2, x1:x2]
    if crop.size == 0:
        return []

    crop_h = crop.shape[0]
    min_part_h = max(8, int(crop_h * 0.04))
    crop_mask = _vertical_foreground_mask(crop)
    row_strength = np.count_nonzero(crop_mask, axis=1).astype(np.float32)
    if row_strength.size:
        row_strength = cv2.GaussianBlur(row_strength.reshape(-1, 1), (1, 9), 0).reshape(-1)

    def _find_cut(prev_cut: int, target: int, remaining_parts: int, *, lo_limit: int = 0, hi_limit: Optional[int] = None) -> int:
        hi_bound = crop_h if hi_limit is None else min(crop_h, hi_limit)
        window = max(8, int(round(crop_h * 0.035)))
        lo = max(prev_cut + min_part_h, lo_limit, target - window)
        hi = min(hi_bound - (remaining_parts * min_part_h), target + window)
        if hi <= lo or row_strength.size == 0:
            cut = target
        else:
            cut = lo + int(np.argmin(row_strength[lo:hi]))
        return max(prev_cut + min_part_h, cut)

    if parts >= 11:
        owner_end_target = int(round((4.0 * crop_h) / float(parts)))
        check_start_target = int(round((10.0 * crop_h) / float(parts)))
        owner_end = _find_cut(0, owner_end_target, 7)
        check_start = _find_cut(owner_end, check_start_target, 1)
        boundaries = [0]

        # Owner block: keep the existing logic for the first 4 symbols.
        for idx in range(1, 4):
            target = int(round((idx * owner_end) / 4.0))
            cut = _find_cut(boundaries[-1], target, 4 - idx, hi_limit=owner_end)
            boundaries.append(min(owner_end - ((4 - idx) * min_part_h), cut))
        boundaries.append(owner_end)

        # Numeric block: split only inside the 6-digit zone, not across the whole crop.
        numeric_h = max(1, check_start - owner_end)
        for idx in range(1, 6):
            target = owner_end + int(round((idx * numeric_h) / 6.0))
            cut = _find_cut(boundaries[-1], target, 6 - idx, lo_limit=owner_end, hi_limit=check_start)
            boundaries.append(min(check_start - ((6 - idx) * min_part_h), cut))
        boundaries.append(check_start)
        boundaries.append(crop_h)
    else:
        boundaries = [0]
        for idx in range(1, parts):
            target = int(round((idx * crop_h) / float(parts)))
            cut = _find_cut(boundaries[-1], target, parts - idx)
            boundaries.append(cut)
        boundaries.append(crop_h)

    rois: list[Any] = []
    for idx in range(parts):
        local_y1 = int(boundaries[idx])
        local_y2 = int(boundaries[idx + 1])
        if (local_y2 - local_y1) < min_part_h:
            continue
        if idx == 0:
            pad_top = 0
        elif idx == parts - 1:
            pad_top = 4
        else:
            pad_top = 2
        pad_bottom = 4 if idx < (parts - 1) else max(10, int(round(crop_h * 0.012)))
        roi = crop[max(0, local_y1 - pad_top):min(crop_h, local_y2 + pad_bottom), :]
        tight = _tight_foreground_crop(
            roi,
            square_inner=(idx == parts - 1 and parts >= 11),
            pad=6 if idx == parts - 1 else 4,
        )
        if tight is None or tight.size == 0:
            continue
        rois.append(tight)
    return rois


def _extract_vertical_owner_block(img, *, parts: int = 11):
    if img is None or img.size == 0 or parts < 10:
        return None

    mask = _vertical_foreground_mask(img)
    bbox = _vertical_focus_bbox(mask)
    if bbox is None:
        bbox = _foreground_bbox_from_mask(_vertical_projection_mask(mask), pad=4)
    if bbox is None:
        return None

    x1, y1, x2, y2 = bbox
    crop = img[y1:y2, x1:x2]
    if crop is None or crop.size == 0:
        return None

    crop_h = crop.shape[0]
    owner_y2 = max(1, int(round((4.0 * crop_h) / float(parts))))
    pad_bottom = max(8, int(round(crop_h * 0.035)))
    owner_region = crop[:min(crop.shape[0], owner_y2 + pad_bottom), :]
    if owner_region is None or owner_region.size == 0:
        return None

    mask = _vertical_foreground_mask(owner_region)
    bbox = _foreground_bbox_from_mask(mask, pad=0)
    if bbox is not None:
        x1, y1, x2, y2 = bbox
        region_h, region_w = owner_region.shape[:2]
        pad_x = max(4, int(round(region_w * 0.03)))
        extra_bottom = max(12, int(round(region_h * 0.08)))
        x1 = max(0, x1 - pad_x)
        x2 = min(region_w, x2 + pad_x)
        y2 = min(region_h, y2 + extra_bottom)
        padded = owner_region[y1:y2, x1:x2]
        if padded is not None and getattr(padded, "size", 0):
            owner_region = padded
    return owner_region if getattr(owner_region, "size", 0) else None


def _collect_strip_pairs(strip, *, phase_bonus: float = 0.0, profile: str = "full") -> list[tuple[str, float]]:
    if strip is None or strip.size == 0:
        return []

    if profile == "minimal":
        passes = [
            (cv2.resize(strip, None, fx=2.2, fy=2.2, interpolation=cv2.INTER_CUBIC), phase_bonus + 0.03),
        ]
    elif profile == "light":
        passes = [
            (cv2.resize(strip, None, fx=2.2, fy=2.2, interpolation=cv2.INTER_CUBIC), phase_bonus + 0.03),
            (cv2.resize(_preprocess_fast(strip), None, fx=2.4, fy=2.4, interpolation=cv2.INTER_CUBIC), phase_bonus + 0.04),
        ]
    else:
        passes = [
            (cv2.resize(strip, None, fx=2.2, fy=2.2, interpolation=cv2.INTER_CUBIC), phase_bonus + 0.03),
            (cv2.resize(_preprocess_fast(strip), None, fx=2.4, fy=2.4, interpolation=cv2.INTER_CUBIC), phase_bonus + 0.04),
            (cv2.resize(_preprocess_hard(strip), None, fx=2.6, fy=2.6, interpolation=cv2.INTER_CUBIC), phase_bonus + 0.02),
        ]

    merged: list[tuple[str, float]] = []
    for prepared, bonus in passes:
        for text, score in _extract_text_pairs(_run_ocr(prepared)):
            merged.append((text, min(1.0, float(score) + bonus)))
    return merged


def _collect_vertical_strip_pairs(strip, *, phase_bonus: float = 0.0, profile: str = "full") -> list[tuple[str, float]]:
    if strip is None or strip.size == 0:
        return []

    if profile == "minimal":
        passes = [
            (strip, phase_bonus + 0.03),
        ]
    elif profile == "light":
        passes = [
            (strip, phase_bonus + 0.03),
            (_preprocess_fast(strip), phase_bonus + 0.04),
        ]
    else:
        passes = [
            (strip, phase_bonus + 0.03),
            (_preprocess_fast(strip), phase_bonus + 0.04),
            (_preprocess_hard(strip), phase_bonus + 0.02),
        ]

    merged: list[tuple[str, float]] = []
    recognized = _run_text_recognition_batch([prepared for prepared, _ in passes])
    for (_prepared, bonus), (text, score) in zip(passes, recognized):
        if text:
            merged.append((text, min(1.0, float(score) + bonus)))
    return merged


def _collect_compact_strip_pairs(strip, *, phase_bonus: float = 0.0, profile: str = "full") -> list[tuple[str, float]]:
    return _collect_vertical_strip_pairs(strip, phase_bonus=phase_bonus, profile=profile)


def _best_digit_from_strip(strip, *, profile: str = "full") -> tuple[str, float]:
    best_digit = ""
    best_score = -1.0
    for text, score in _collect_strip_pairs(strip, phase_bonus=0.0, profile=profile):
        digit, digit_score = _best_digit_from_pairs([(text, score)])
        if digit and digit_score > best_score:
            best_digit = digit
            best_score = digit_score
    return best_digit, best_score


def _best_vertical_numeric_read(text_pairs: list[tuple[str, float]]) -> tuple[str, str, float, str]:
    best_base6 = ""
    best_check_digit = ""
    best_score = -1.0
    best_raw = ""

    for raw_text, raw_score in text_pairs:
        mapped = "".join(_TO_DIGIT.get(ch, ch) for ch in clean(raw_text))
        for chunk in _DIGIT_CHUNK_RE.findall(mapped):
            if len(chunk) < 6:
                continue
            if len(chunk) >= 7:
                base6 = chunk[:6]
                check_digit = chunk[6]
                score = float(raw_score) + 0.18
            else:
                base6 = chunk[:6]
                check_digit = ""
                score = float(raw_score) + 0.08
            if score > best_score:
                best_base6 = base6
                best_check_digit = check_digit
                best_score = score
                best_raw = chunk

    return best_base6, best_check_digit, best_score, best_raw


def _extract_horizontal_symbol_rois(img) -> list[Any]:
    if img is None or img.size == 0:
        return []

    mask = foreground_mask(img)
    h, w = mask.shape[:2]
    col_strength = np.count_nonzero(mask, axis=0)
    col_threshold = max(2, int(h * 0.14))

    bands: list[tuple[int, int]] = []
    in_band = False
    start = 0
    for idx, value in enumerate(col_strength):
        if value >= col_threshold and not in_band:
            start = idx
            in_band = True
        elif value < col_threshold and in_band:
            bands.append((start, idx))
            in_band = False
    if in_band:
        bands.append((start, w))

    bands = merge_bands(bands, max_gap=max(2, int(w * 0.01)))
    min_band_w = max(5, int(w * 0.018))
    rois: list[Any] = []
    for x1, x2 in bands:
        if (x2 - x1) < min_band_w:
            continue
        band_mask = mask[:, x1:x2]
        rows = np.where(np.count_nonzero(band_mask, axis=1) > 0)[0]
        if rows.size == 0:
            continue
        y1 = max(0, int(rows[0]) - 3)
        y2 = min(h, int(rows[-1]) + 4)
        roi = img[y1:y2, max(0, x1 - 2):min(w, x2 + 3)]
        if roi.size == 0:
            continue
        rois.append(roi)
    return rois


def _light_symbol_mask(img, *, v_min: int = 140, s_max: int = 60):
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(
        hsv,
        np.array([0, 0, v_min], dtype=np.uint8),
        np.array([180, s_max, 255], dtype=np.uint8),
    )
    return mask


def _split_wide_component(mask, rect: tuple[int, int, int, int], *, min_part_w: int) -> list[tuple[int, int, int, int]]:
    x, y, w, h = rect
    if w < max(20, min_part_w * 2):
        return [rect]

    local = mask[y:y + h, x:x + w]
    if local.size == 0:
        return [rect]

    col_strength = np.count_nonzero(local, axis=0).astype(np.float32)
    if col_strength.size < 12:
        return [rect]

    search_from = max(2, int(w * 0.28))
    search_to = min(w - 2, int(w * 0.72))
    if search_to - search_from < 4:
        return [rect]

    window = col_strength[search_from:search_to]
    split_rel = int(np.argmin(window))
    split_x = search_from + split_rel
    valley = float(window[split_rel])
    peak = float(col_strength.max()) if col_strength.size else 0.0
    if peak <= 0.0 or valley > peak * 0.62:
        return [rect]

    left_w = split_x
    right_w = w - split_x
    if left_w < min_part_w or right_w < min_part_w:
        return [rect]

    return [
        (x, y, left_w, h),
        (x + split_x, y, right_w, h),
    ]


def _extract_light_symbol_rects(
    img,
    *,
    expected: int = 0,
    min_h_ratio: float = 0.32,
    min_w_ratio: float = 0.02,
    max_w_ratio: float = 0.42,
    v_min: int = 140,
    s_max: int = 60,
    pad: int = 4,
) -> list[Any]:
    if img is None or img.size == 0:
        return []

    mask = _light_symbol_mask(img, v_min=v_min, s_max=s_max)
    h, w = mask.shape[:2]
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    rects: list[tuple[int, int, int, int]] = []
    min_h = max(12, int(h * min_h_ratio))
    min_w = max(8, int(w * min_w_ratio))
    max_w = max(min_w + 1, int(w * max_w_ratio))

    for contour in contours:
        x, y, bw, bh = cv2.boundingRect(contour)
        if bh < min_h or bw < min_w or bw > max_w:
            continue
        rects.append((x, y, bw, bh))

    rects.sort(key=lambda item: item[0])
    if expected and 1 <= len(rects) < expected:
        widths = [rect[2] for rect in rects]
        median_w = float(np.median(widths)) if widths else 0.0
        expanded: list[tuple[int, int, int, int]] = []
        for rect in rects:
            if median_w > 0 and rect[2] > median_w * 1.35 and len(expanded) + (len(rects) - len(expanded)) < expected:
                expanded.extend(_split_wide_component(mask, rect, min_part_w=min_w))
            else:
                expanded.append(rect)
        rects = sorted(expanded, key=lambda item: item[0])

    return rects


def _extract_light_symbol_rois(
    img,
    *,
    expected: int = 0,
    min_h_ratio: float = 0.32,
    min_w_ratio: float = 0.02,
    max_w_ratio: float = 0.42,
    v_min: int = 140,
    s_max: int = 60,
    pad: int = 4,
) -> list[Any]:
    if img is None or img.size == 0:
        return []

    h, w = img.shape[:2]
    rects = _extract_light_symbol_rects(
        img,
        expected=expected,
        min_h_ratio=min_h_ratio,
        min_w_ratio=min_w_ratio,
        max_w_ratio=max_w_ratio,
        v_min=v_min,
        s_max=s_max,
        pad=pad,
    )
    rois: list[Any] = []
    for x, y, bw, bh in rects:
        x1 = max(0, x - pad)
        y1 = max(0, y - pad)
        x2 = min(w, x + bw + pad)
        y2 = min(h, y + bh + pad)
        roi = img[y1:y2, x1:x2]
        if roi.size == 0:
            continue
        rois.append(roi)
    return rois


def _read_digit_sequence(rois: list[Any], *, limit: int, square_last: bool = False) -> tuple[str, float]:
    digits: list[str] = []
    total_score = 0.0
    selected = rois[:limit]
    for idx, roi in enumerate(selected):
        target_roi = roi
        if square_last and idx == len(selected) - 1:
            inner = _safe_inner_crop(roi, margin_ratio=0.12)
            if inner is not None and inner.size:
                target_roi = inner
        digit, score = _read_digit_from_roi(target_roi, square_bias=square_last and idx == len(selected) - 1)
        if not digit:
            break
        digits.append(digit)
        total_score += max(score, 0.0)
    if len(digits) != len(selected):
        return "", -1.0
    return "".join(digits), total_score / float(max(1, len(digits)))


def _digit_chunks_from_pairs(
    text_pairs: list[tuple[str, float]],
    *,
    min_len: int,
    max_len: int | None = None,
    allow_short_final: bool = False,
) -> list[tuple[str, float, str]]:
    chunks: list[tuple[str, float, str]] = []
    seen: set[tuple[str, int]] = set()
    for raw_text, raw_score in _candidate_groups(text_pairs):
        mapped = "".join(_TO_DIGIT.get(ch, ch) for ch in clean(raw_text))
        for chunk in _DIGIT_CHUNK_RE.findall(mapped):
            if len(chunk) < min_len:
                continue
            trimmed = chunk if max_len is None else chunk[:max_len]
            if max_len is not None and len(trimmed) < min_len:
                continue
            if not allow_short_final and max_len is not None and len(trimmed) != max_len and len(chunk) >= max_len:
                continue
            key = (trimmed, int(round(float(raw_score) * 1000.0)))
            if key in seen:
                continue
            seen.add(key)
            chunks.append((trimmed, float(raw_score), raw_text))
    return chunks


def _split_door_owner_read_hard(top_left) -> tuple[str, float, str]:
    if top_left is None or top_left.size == 0:
        return "", -1.0, ""

    best_owner = ""
    best_score = -1.0
    best_raw = ""

    roi_groups: list[list[Any]] = []
    roi_groups.append(_extract_horizontal_symbol_rois(top_left))
    for params in (
        {"expected": 4, "min_h_ratio": 0.22, "min_w_ratio": 0.012, "max_w_ratio": 0.48, "v_min": 92, "s_max": 155},
        {"expected": 4, "min_h_ratio": 0.26, "min_w_ratio": 0.015, "max_w_ratio": 0.44, "v_min": 104, "s_max": 135},
        {"expected": 4, "min_h_ratio": 0.30, "min_w_ratio": 0.018, "max_w_ratio": 0.42, "v_min": 118, "s_max": 120},
    ):
        roi_groups.append(_extract_light_symbol_rois(top_left, **params))

    seen_shapes: set[tuple[int, int, int]] = set()
    for rois in roi_groups:
        if len(rois) < 3:
            continue
        subset = rois[:4]
        strip = _compose_symbol_strip(subset, target_h=108, gap=18, outer_pad=14)
        if strip is None or strip.size == 0:
            continue
        shape_key = (strip.shape[0], strip.shape[1], len(subset))
        if shape_key in seen_shapes:
            continue
        seen_shapes.add(shape_key)
        for profile, bonus in (("minimal", 0.04), ("light", 0.07), ("full", 0.09)):
            pairs = _collect_strip_pairs(strip, phase_bonus=bonus, profile=profile)
            owner, score, raw = _best_owner_code_from_pairs(pairs)
            if owner and score > best_score:
                best_owner = owner
                best_score = score
                best_raw = raw

    for profile, bonus in (("minimal", 0.01), ("light", 0.03), ("full", 0.04)):
        pairs = _collect_strip_pairs(top_left, phase_bonus=bonus, profile=profile)
        owner, score, raw = _best_owner_code_from_pairs(pairs)
        if owner and score > best_score:
            best_owner = owner
            best_score = score
            best_raw = raw

    return best_owner, best_score, best_raw


def _split_door_numeric_read_hard(bottom_left, bottom_right) -> tuple[str, str, float, str]:
    if bottom_left is None or bottom_left.size == 0 or bottom_right is None or bottom_right.size == 0:
        return "", "", -1.0, ""

    best_base6 = ""
    best_check_digit = ""
    best_score = -1.0
    best_raw = ""

    left_roi_groups: list[list[Any]] = [_extract_horizontal_symbol_rois(bottom_left)]
    right_roi_groups: list[list[Any]] = [_extract_horizontal_symbol_rois(bottom_right)]
    for params in (
        {"expected": 4, "min_h_ratio": 0.22, "min_w_ratio": 0.010, "max_w_ratio": 0.38, "v_min": 92, "s_max": 155},
        {"expected": 4, "min_h_ratio": 0.28, "min_w_ratio": 0.012, "max_w_ratio": 0.42, "v_min": 108, "s_max": 135},
        {"expected": 4, "min_h_ratio": 0.34, "min_w_ratio": 0.014, "max_w_ratio": 0.46, "v_min": 122, "s_max": 120},
    ):
        left_roi_groups.append(_extract_light_symbol_rois(bottom_left, **params))
    for params in (
        {"expected": 3, "min_h_ratio": 0.22, "min_w_ratio": 0.010, "max_w_ratio": 0.44, "v_min": 92, "s_max": 155},
        {"expected": 3, "min_h_ratio": 0.28, "min_w_ratio": 0.012, "max_w_ratio": 0.46, "v_min": 108, "s_max": 135},
        {"expected": 3, "min_h_ratio": 0.34, "min_w_ratio": 0.014, "max_w_ratio": 0.48, "v_min": 122, "s_max": 120},
    ):
        right_roi_groups.append(_extract_light_symbol_rois(bottom_right, **params))

    left_candidates: list[tuple[str, float, str]] = []
    seen_left: set[str] = set()
    for rois in left_roi_groups:
        if len(rois) >= 4:
            seq, seq_score = _read_digit_sequence(rois, limit=4)
            if len(seq) == 4 and seq not in seen_left:
                seen_left.add(seq)
                left_candidates.append((seq, seq_score + 0.10, seq))
            strip = _compose_symbol_strip(rois[:4], target_h=106, gap=14, outer_pad=12)
            if strip is not None and strip.size != 0:
                for profile, bonus in (("minimal", 0.05), ("light", 0.08), ("full", 0.09)):
                    chunks = _digit_chunks_from_pairs(
                        _collect_strip_pairs(strip, phase_bonus=bonus, profile=profile),
                        min_len=4,
                        max_len=4,
                    )
                    for chunk, score, raw in chunks:
                        if chunk in seen_left:
                            continue
                        seen_left.add(chunk)
                        left_candidates.append((chunk, score + 0.05, raw))

    for profile, bonus in (("minimal", 0.01), ("light", 0.03), ("full", 0.04)):
        chunks = _digit_chunks_from_pairs(
            _collect_strip_pairs(bottom_left, phase_bonus=bonus, profile=profile),
            min_len=4,
            max_len=4,
        )
        for chunk, score, raw in chunks:
            if chunk in seen_left:
                continue
            seen_left.add(chunk)
            left_candidates.append((chunk, score, raw))

    tail_candidates: list[tuple[str, str, float, str]] = []
    seen_tail: set[tuple[str, str]] = set()
    for rois in right_roi_groups:
        if len(rois) >= 3:
            seq, seq_score = _read_digit_sequence(rois, limit=3, square_last=True)
            if len(seq) == 3:
                key = (seq[:2], seq[2])
                if key not in seen_tail:
                    seen_tail.add(key)
                    tail_candidates.append((seq[:2], seq[2], seq_score + 0.11, seq))
        if len(rois) >= 2:
            seq2, seq2_score = _read_digit_sequence(rois, limit=2)
            if len(seq2) == 2:
                key = (seq2[:2], "")
                if key not in seen_tail:
                    seen_tail.add(key)
                    tail_candidates.append((seq2[:2], "", seq2_score + 0.05, seq2))
        if len(rois) >= 2:
            strip = _compose_symbol_strip(
                rois[:3] if len(rois) >= 3 else rois[:2],
                target_h=106,
                gap=14,
                outer_pad=12,
                square_last=(len(rois) >= 3),
            )
            if strip is not None and strip.size != 0:
                for profile, bonus in (("minimal", 0.05), ("light", 0.08), ("full", 0.09)):
                    chunks = _digit_chunks_from_pairs(
                        _collect_strip_pairs(strip, phase_bonus=bonus, profile=profile),
                        min_len=2,
                        max_len=3,
                        allow_short_final=True,
                    )
                    for chunk, score, raw in chunks:
                        right2 = chunk[:2]
                        check = chunk[2] if len(chunk) >= 3 else ""
                        if len(right2) < 2:
                            continue
                        key = (right2, check)
                        if key in seen_tail:
                            continue
                        seen_tail.add(key)
                        tail_candidates.append((right2, check, score + 0.05, raw))

    for profile, bonus in (("minimal", 0.01), ("light", 0.03), ("full", 0.04)):
        chunks = _digit_chunks_from_pairs(
            _collect_strip_pairs(bottom_right, phase_bonus=bonus, profile=profile),
            min_len=2,
            max_len=3,
            allow_short_final=True,
        )
        for chunk, score, raw in chunks:
            right2 = chunk[:2]
            check = chunk[2] if len(chunk) >= 3 else ""
            if len(right2) < 2:
                continue
            key = (right2, check)
            if key in seen_tail:
                continue
            seen_tail.add(key)
            tail_candidates.append((right2, check, score, raw))

    square_digit, square_score = _read_right_check_digit(bottom_right)
    if square_digit:
        key = ("", square_digit)
        if key not in seen_tail:
            seen_tail.add(key)
            tail_candidates.append(("", square_digit, square_score + 0.04, square_digit))

    for left_digits, left_score, left_raw in left_candidates:
        for right_digits, check_digit, tail_score, tail_raw in tail_candidates:
            if len(left_digits) != 4 or len(right_digits) < 2:
                continue
            score = (left_score * 0.58) + (tail_score * 0.42)
            if check_digit:
                score += 0.04
            base6 = f"{left_digits[:4]}{right_digits[:2]}"
            raw_text = " ".join(part for part in (left_raw, tail_raw) if part).strip()
            if score > best_score:
                best_base6 = base6
                best_check_digit = check_digit
                best_score = score
                best_raw = raw_text

    if best_base6:
        return best_base6, best_check_digit, best_score, best_raw

    if square_digit:
        return "", square_digit, square_score, square_digit
    return "", "", -1.0, ""


def _ocr_split_door_container_regions_hard(img, config: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    from . import container_ocr_twolines as twolines

    return twolines.ocr_split_door_container_regions_hard(img, config=config)




def _estimate_split_door_seam_x(img, config: Optional[dict[str, Any]] = None) -> Optional[int]:
    if img is None or img.size == 0:
        return None
    gray = _ensure_gray(img)
    _h, w = gray.shape[:2]
    x1 = max(0, int(w * 0.42))
    x2 = min(w, int(w * 0.62))
    if x2 - x1 < 12:
        return None

    roi = gray[:, x1:x2].astype(np.float32)
    col_signal = roi.mean(axis=0)
    col_signal = cv2.GaussianBlur(col_signal.reshape(1, -1), (1, 9), 0).reshape(-1)
    if col_signal.size == 0:
        return None
    return int(x1 + int(np.argmax(col_signal)))


def _estimate_split_door_line_split_y(img, seam_x: int, config: Optional[dict[str, Any]] = None) -> Optional[int]:
    if img is None or img.size == 0:
        return None
    h, w = img.shape[:2]
    left = img[:, :max(8, min(seam_x - 2, w))]
    if left.size == 0:
        return None

    mask = _light_symbol_mask(left, v_min=108, s_max=120)
    row_strength = np.count_nonzero(mask, axis=1).astype(np.float32)
    if row_strength.size < 12:
        return None
    smoothed = cv2.GaussianBlur(row_strength.reshape(-1, 1), (1, 11), 0).reshape(-1)

    y1 = max(0, int(h * 0.30))
    y2 = min(h, int(h * 0.58))
    if y2 - y1 < 10:
        return None
    valley = smoothed[y1:y2]
    if valley.size == 0:
        return None
    return int(y1 + int(np.argmin(valley)))


def _refine_split_door_bottom_right_roi(zone) -> Any:
    if zone is None or zone.size == 0:
        return zone

    selected = _select_rightmost_square_entry(zone)
    if not selected:
        return zone

    (box_x1, box_y1, box_x2, box_y2), _box_roi = selected
    zh, zw = zone.shape[:2]
    box_h = max(1, int(box_y2) - int(box_y1))
    left_limit = max(0, int(box_x1) - 4)
    if left_limit <= 8:
        return zone

    left_zone = zone[:, :left_limit]
    rects: list[tuple[int, int, int, int]] = []
    for params in (
        {"expected": 2, "min_h_ratio": 0.18, "min_w_ratio": 0.018, "max_w_ratio": 0.30, "v_min": 84, "s_max": 170},
        {"expected": 2, "min_h_ratio": 0.22, "min_w_ratio": 0.016, "max_w_ratio": 0.34, "v_min": 100, "s_max": 145},
        {"expected": 2, "min_h_ratio": 0.26, "min_w_ratio": 0.014, "max_w_ratio": 0.38, "v_min": 112, "s_max": 125},
    ):
        for x, y, w, h in _extract_light_symbol_rects(left_zone, **params):
            rects.append((x, y, w, h))

    row_candidates: list[tuple[int, int, int, int]] = []
    cy_min = float(box_y1) - float(box_h) * 0.45
    cy_max = float(box_y2) + float(box_h) * 0.20
    for x, y, w, h in rects:
        cy = float(y) + float(h) * 0.5
        if cy < cy_min or cy > cy_max:
            continue
        row_candidates.append((x, y, w, h))

    row_candidates.sort(key=lambda item: item[0])
    if len(row_candidates) > 2:
        row_candidates = row_candidates[-2:]

    top = int(box_y1)
    bottom = int(box_y2)
    if row_candidates:
        top = min(top, min(y for _x, y, _w, _h in row_candidates))
        bottom = max(bottom, max(y + h for _x, y, _w, h in row_candidates))

    pad_top = max(8, int(box_h * 0.18))
    pad_bottom = max(10, int(box_h * 0.22))
    y1 = max(0, top - pad_top)
    y2 = min(zh, bottom + pad_bottom)
    if y2 - y1 < max(24, int(zh * 0.18)):
        y2 = min(zh, y1 + max(24, int(zh * 0.18)))

    refined = zone[y1:y2, :zw]
    return refined if refined is not None and refined.size else zone


def _extract_split_door_rois_local(img, config: Optional[dict[str, Any]] = None) -> Optional[dict[str, Any]]:
    if img is None or img.size == 0:
        return None
    h, w = img.shape[:2]
    seam_x = _estimate_split_door_seam_x(img, config=config)
    if seam_x is None:
        return None

    split_y = _estimate_split_door_line_split_y(img, seam_x, config=config)
    if split_y is None:
        split_y = int(h * 0.48)

    top_x2 = max(8, min(w, int(seam_x - 6)))
    top_y2 = max(8, min(h, int(split_y + 4)))
    bottom_left_x2 = max(8, min(w, int(seam_x - 8)))
    top_margin = max(12, int(h * 0.04))
    bottom_y1 = max(0, min(h - 1, int(split_y - top_margin)))
    # Keep a safety margin to the LEFT of seam so both right digits are fully visible.
    # On real crops seam detector can drift right by a few px; starting strictly after seam
    # clips the first of the two right digits.
    right_left_margin = max(8, int(w * 0.008))
    bottom_right_x1 = max(0, min(w - 1, int(seam_x - right_left_margin)))
    provisional_bottom_y1 = max(0, min(h - 1, int(split_y - max(top_margin, int(h * 0.08)))))
    provisional_bottom_y2 = min(h, int(split_y + 0.82 * max(0, (h - split_y))))
    min_bottom_h = max(36, int(h * 0.16))
    provisional_bottom_y2 = max(provisional_bottom_y1 + min_bottom_h, min(h, provisional_bottom_y2))

    top_left = img[0:top_y2, 0:top_x2]
    bottom_left = img[bottom_y1:h, 0:bottom_left_x2]
    bottom_right_provisional = img[provisional_bottom_y1:provisional_bottom_y2, bottom_right_x1:w]
    bottom_right = _refine_split_door_bottom_right_roi(bottom_right_provisional)

    if top_left.size == 0 or bottom_left.size == 0 or bottom_right.size == 0:
        return None

    return {
        "seam_x": int(seam_x),
        "split_y": int(split_y),
        "top_left": top_left,
        "bottom_left": bottom_left,
        "bottom_right": bottom_right,
    }


def _split_door_owner_read(top_left) -> tuple[str, float, str]:
    if top_left is None or top_left.size == 0:
        return "", -1.0, ""

    best_owner = ""
    best_score = -1.0
    best_raw = ""

    for owner_input, bonus, profile in (
        (top_left, 0.03, "light"),
        (top_left, 0.01, "minimal"),
    ):
        pairs = _collect_compact_strip_pairs(owner_input, phase_bonus=bonus, profile=profile)
        if not pairs:
            continue
        owner, score, raw = _best_owner_code_from_pairs(pairs)
        if owner and score > best_score:
            best_owner = owner
            best_score = score
            best_raw = raw

    top_symbols = _extract_light_symbol_rois(top_left, expected=4, min_h_ratio=0.45, min_w_ratio=0.025, max_w_ratio=0.38, v_min=118, s_max=105)
    if len(top_symbols) >= 4:
        strip = _compose_symbol_strip(top_symbols[:4], target_h=64, gap=10, outer_pad=8)
        pairs = _collect_compact_strip_pairs(strip, phase_bonus=0.05, profile="minimal")
        owner, score, raw = _best_owner_code_from_pairs(pairs)
        if owner and score > best_score:
            best_owner = owner
            best_score = score
            best_raw = raw

    return best_owner, best_score, best_raw




def _select_rightmost_square_entry(zone) -> Optional[tuple[tuple[int, int, int, int], Any]]:
    if zone is None or zone.size == 0:
        return None
    try:
        entries = _square_like_roi_entries(zone)
    except Exception:
        entries = []
    if not entries:
        return None
    return max(entries, key=lambda item: (item[0][0] + item[0][2]) * 0.5)


def _split_door_right_digits_zone(bottom_right):
    if bottom_right is None or bottom_right.size == 0:
        return bottom_right

    selected = _select_rightmost_square_entry(bottom_right)
    if not selected:
        return bottom_right

    (x1, _y1, x2, y2), _roi = selected
    cut_left = max(0, int(x1) - 6)
    if cut_left <= max(12, int(bottom_right.shape[1] * 0.20)):
        return bottom_right

    cut_bottom = min(
        bottom_right.shape[0],
        max(int(y2) + 4, int(bottom_right.shape[0] * 0.70)),
    )
    # Read right2 from the neighborhood immediately left of the check-digit box,
    # not from the whole left span (which may include extra lower-line digits).
    box_w = max(1, int(x2) - int(x1))
    right2_band_w = max(int(bottom_right.shape[1] * 0.18), int(box_w * 3.0))
    zone_x1 = max(0, int(cut_left) - int(right2_band_w))
    zone = bottom_right[:cut_bottom, zone_x1:cut_left]
    return zone if zone is not None and zone.size else bottom_right

def _read_split_door_box_digit(bottom_right) -> tuple[str, float, str]:
    if bottom_right is None or bottom_right.size == 0:
        return "", -1.0, ""

    selected = _select_rightmost_square_entry(bottom_right)
    if not selected:
        return "", -1.0, ""

    (_rect, roi) = selected
    roi_candidates = []
    inner = _safe_inner_crop(roi, margin_ratio=0.10)
    if inner is not None and inner.size:
        roi_candidates.append(inner)
    roi_candidates.append(roi)

    best_digit = ""
    best_score = -1.0
    for target in roi_candidates:
        digit, score = _read_digit_from_roi(target, square_bias=True)
        if digit and score > best_score:
            best_digit = digit
            best_score = score

    if best_digit:
        return best_digit, best_score, best_digit

    digit, score = _read_right_check_digit(roi)
    if digit:
        return digit, score, digit
    return "", -1.0, ""

def _split_door_numeric_read(bottom_left, bottom_right) -> tuple[str, str, float, str]:
    if bottom_left is None or bottom_left.size == 0 or bottom_right is None or bottom_right.size == 0:
        return "", "", -1.0, ""

    best_left4 = ""
    best_left_score = -1.0
    best_left_raw = ""

    best_right2 = ""
    best_right_score = -1.0
    best_right_raw = ""

    check_digit = ""
    check_score = -1.0
    check_raw = ""

    # -------------------------
    # Left 4 digits
    # -------------------------
    left_light = _extract_light_symbol_rois(
        bottom_left,
        expected=4,
        min_h_ratio=0.34,
        min_w_ratio=0.014,
        max_w_ratio=0.50,
        v_min=108,
        s_max=115,
    )
    left_sets = [left_light, _extract_horizontal_symbol_rois(bottom_left)]

    for left_symbols in left_sets:
        if len(left_symbols) >= 4:
            seq, seq_score = _read_digit_sequence(left_symbols[:4], limit=4)
            if len(seq) == 4:
                best_left4 = seq
                best_left_score = seq_score + 0.10
                best_left_raw = seq
                break

    if len(best_left4) != 4:
        for left_symbols in left_sets:
            if len(left_symbols) >= 4:
                strip = _compose_symbol_strip(left_symbols[:4], target_h=72, gap=8, outer_pad=8)
                if strip is None or strip.size == 0:
                    continue
                for profile, bonus in (("minimal", 0.03), ("light", 0.05)):
                    chunks = _digit_chunks_from_pairs(
                        _collect_strip_pairs(strip, phase_bonus=bonus, profile=profile),
                        min_len=4,
                        max_len=4,
                    )
                    for chunk, score, raw in chunks:
                        if len(chunk) == 4 and score > best_left_score:
                            best_left4 = chunk
                            best_left_score = score
                            best_left_raw = raw

    if len(best_left4) != 4:
        for profile, bonus in (("minimal", 0.01), ("light", 0.03)):
            chunks = _digit_chunks_from_pairs(
                _collect_compact_strip_pairs(bottom_left, phase_bonus=bonus, profile=profile),
                min_len=4,
                max_len=4,
            )
            for chunk, score, raw in chunks:
                if len(chunk) == 4 and score > best_left_score:
                    best_left4 = chunk
                    best_left_score = score
                    best_left_raw = raw

    # -------------------------
    # Check digit from boxed ROI
    # -------------------------
    check_digit, check_score, check_raw = _read_split_door_box_digit(bottom_right)
    backup_check_digit = ""
    backup_check_score = -1.0
    backup_check_raw = ""

    # -------------------------
    # Right 2 digits from area WITHOUT box
    # -------------------------
    right_digits_zone = _split_door_right_digits_zone(bottom_right)
    right_light = _extract_light_symbol_rois(
        right_digits_zone,
        expected=2,
        min_h_ratio=0.28,
        min_w_ratio=0.012,
        max_w_ratio=0.50,
        v_min=108,
        s_max=120,
    )
    right_sets = [right_light, _extract_horizontal_symbol_rois(right_digits_zone)]

    for right_symbols in right_sets:
        if len(right_symbols) >= 2:
            right_pair = right_symbols[-2:]
            seq2, seq2_score = _read_digit_sequence(right_pair, limit=2)
            if len(seq2) == 2:
                best_right2 = seq2
                best_right_score = seq2_score + 0.08
                best_right_raw = seq2
                break

    if len(best_right2) != 2:
        for right_symbols in right_sets:
            if len(right_symbols) >= 2:
                right_pair = right_symbols[-2:]
                strip = _compose_symbol_strip(right_pair, target_h=72, gap=8, outer_pad=8)
                if strip is None or strip.size == 0:
                    continue
                for profile, bonus in (("minimal", 0.03), ("light", 0.05), ("full", 0.06)):
                    chunks = _digit_chunks_from_pairs(
                        _collect_strip_pairs(strip, phase_bonus=bonus, profile=profile),
                        min_len=2,
                        max_len=2,
                    )
                    for chunk, score, raw in chunks:
                        if len(chunk) == 2 and score > best_right_score:
                            best_right2 = chunk
                            best_right_score = score
                            best_right_raw = raw

    if len(best_right2) != 2:
        for profile, bonus in (("minimal", 0.01), ("light", 0.03), ("full", 0.04)):
            chunks = _digit_chunks_from_pairs(
                _collect_strip_pairs(right_digits_zone, phase_bonus=bonus, profile=profile),
                min_len=2,
                max_len=2,
            )
            for chunk, score, raw in chunks:
                if len(chunk) == 2 and score > best_right_score:
                    best_right2 = chunk
                    best_right_score = score
                    best_right_raw = raw

    # Do not decode right2 from the whole bottom-right ROI: it often mixes lower-line noise.
    # Only allow fallback check-digit extraction when boxed ROI failed.
    if not check_digit:
        for profile, bonus in (("minimal", 0.01), ("light", 0.03), ("full", 0.04)):
            chunks = _digit_chunks_from_pairs(
                _collect_strip_pairs(bottom_right, phase_bonus=bonus, profile=profile),
                min_len=2,
                max_len=3,
                allow_short_final=True,
            )
            for chunk, score, raw in chunks:
                candidate_check = chunk[2] if len(chunk) >= 3 else ""
                if candidate_check and score > backup_check_score:
                    backup_check_digit = candidate_check
                    backup_check_score = score
                    backup_check_raw = raw

    if not check_digit:
        fallback_digit, fallback_score = _read_right_check_digit(bottom_right)
        if fallback_digit and fallback_score > backup_check_score:
            backup_check_digit = fallback_digit
            backup_check_score = fallback_score
            backup_check_raw = fallback_digit

    if not check_digit and backup_check_digit:
        check_digit = backup_check_digit
        check_score = backup_check_score
        check_raw = backup_check_raw

    raw_text = " ".join(part for part in (best_left_raw, best_right_raw, check_raw) if part).strip()

    if len(best_left4) == 4 and len(best_right2) == 2:
        base6 = f"{best_left4}{best_right2}"
        total_score = max(best_left_score, 0.0) * 0.56 + max(best_right_score, 0.0) * 0.34
        if check_digit:
            total_score += max(check_score, 0.0) * 0.10
        return base6, check_digit, float(total_score), raw_text

    fallback_score = max(best_left_score, best_right_score, check_score)
    return "", check_digit, float(fallback_score), raw_text

def _ocr_split_door_container_regions(img, config: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    from . import container_ocr_twolines as twolines

    return twolines.ocr_split_door_container_regions(img, config=config)

def _best_letter_from_pairs(text_pairs: list[tuple[str, float]]) -> tuple[str, float]:
    best_letter = ""
    best_score = -1.0
    for text, score in text_pairs:
        mapped = "".join(_TO_LETTER.get(ch, ch) for ch in clean(text))
        letters = [(idx, ch) for idx, ch in enumerate(mapped) if ch.isalpha()]
        if not letters:
            continue
        for idx, letter in letters:
            candidate_score = float(score)
            if len(letters) == 1:
                candidate_score += 0.12
            if len(mapped) <= 2:
                candidate_score += 0.05
            if idx == 0 or idx == len(mapped) - 1:
                candidate_score += 0.02
            if len(letters) > 1:
                candidate_score -= 0.03 * float(len(letters) - 1)
            if candidate_score > best_score:
                best_letter = letter
                best_score = candidate_score
    return best_letter, best_score


def _paddle_letter_from_roi(roi) -> tuple[str, float]:
    if roi is None or roi.size == 0:
        return "", -1.0

    best_letter = ""
    best_score = -1.0
    variants = _digit_preprocess_variants(roi)
    for variant_idx in (1, 0, 3):
        if variant_idx >= len(variants):
            continue
        prepared = variants[variant_idx]
        up = cv2.resize(prepared, None, fx=2.8, fy=2.8, interpolation=cv2.INTER_CUBIC)
        pairs = _extract_text_pairs(_run_ocr(up))
        letter, score = _best_letter_from_pairs(pairs)
        if letter and score > best_score:
            best_letter = letter
            best_score = score
    return best_letter, best_score


def _vertical_symbol_sequence(rois: list[Any]) -> tuple[list[tuple[str, float]], str]:
    symbols: list[tuple[str, float]] = []
    raw_parts: list[str] = []
    for idx, roi in enumerate(rois):
        is_last = idx == len(rois) - 1
        h, w = roi.shape[:2]
        ratio = w / float(max(1, h))
        if idx < 4:
            symbol, score = _paddle_letter_from_roi(roi)
            if symbol:
                raw_parts.append(symbol)
                symbols.append((symbol, score))
            continue

        target_roi = roi
        if is_last and 0.55 <= ratio <= 1.35:
            inner = _safe_inner_crop(roi, margin_ratio=0.12)
            if inner is not None and inner.size:
                target_roi = inner
        symbol, score = _paddle_digit_from_roi(target_roi)
        if symbol:
                raw_parts.append(symbol)
                symbols.append((symbol, score))
    return symbols, "".join(raw_parts)


def _paddle_letter_from_roi_vertical(roi) -> tuple[str, float]:
    if roi is None or roi.size == 0:
        return "", -1.0

    best_letter = ""
    best_score = -1.0
    variants = _digit_preprocess_variants(roi)
    prepared_batch: list[Any] = []
    variant_order: list[int] = []
    for variant_idx in (1, 0, 3):
        if variant_idx < len(variants):
            prepared_batch.append(variants[variant_idx])
            variant_order.append(variant_idx)

    for _variant_idx, (text, score) in zip(variant_order, _run_text_recognition_batch(prepared_batch)):
        pairs = [(text, score)] if text else []
        letter, local_score = _best_letter_from_pairs(pairs)
        if letter and local_score > best_score:
            best_letter = letter
            best_score = local_score
    return best_letter, best_score


def _best_vertical_letter_from_roi(roi) -> tuple[str, float]:
    if roi is None or roi.size == 0:
        return "", -1.0

    candidates: list[Any] = []
    tight = _tight_foreground_crop(roi)
    if tight is not None and getattr(tight, "size", 0):
        candidates.append(tight)
        inner = _safe_inner_crop(tight, margin_ratio=0.08)
        if inner is not None and getattr(inner, "size", 0):
            candidates.append(inner)
    inner_raw = _safe_inner_crop(roi, margin_ratio=0.08)
    if inner_raw is not None and getattr(inner_raw, "size", 0):
        candidates.append(inner_raw)
    candidates.append(roi)

    best_letter = ""
    best_score = -1.0
    seen_shapes: set[tuple[int, int]] = set()
    for candidate in candidates:
        shape = tuple(candidate.shape[:2])
        if shape in seen_shapes:
            continue
        seen_shapes.add(shape)
        for fn in (_paddle_letter_from_roi_vertical, _paddle_letter_from_roi):
            letter, score = fn(candidate)
            if letter and score > best_score:
                best_letter = letter
                best_score = score
    return best_letter, best_score


def _best_vertical_owner_from_block(owner_block) -> tuple[str, float, str]:
    if owner_block is None or owner_block.size == 0:
        return "", -1.0, ""

    candidates: list[Any] = []
    tight = _tight_foreground_crop(owner_block)
    if tight is not None and getattr(tight, "size", 0):
        candidates.append(tight)
        inner = _safe_inner_crop(tight, margin_ratio=0.05)
        if inner is not None and getattr(inner, "size", 0):
            candidates.append(inner)
    inner_raw = _safe_inner_crop(owner_block, margin_ratio=0.04)
    if inner_raw is not None and getattr(inner_raw, "size", 0):
        candidates.append(inner_raw)
    candidates.append(owner_block)

    best_owner = ""
    best_score = -1.0
    best_raw = ""
    seen_shapes: set[tuple[int, int]] = set()

    for candidate in candidates:
        shape = tuple(candidate.shape[:2])
        if shape in seen_shapes:
            continue
        seen_shapes.add(shape)
        for rotate_code, rotate_bonus in (
            (cv2.ROTATE_90_COUNTERCLOCKWISE, 0.08),
            (cv2.ROTATE_90_CLOCKWISE, 0.06),
        ):
            rotated = cv2.rotate(candidate, rotate_code)
            for profile, bonus in (("light", 0.05), ("full", 0.03)):
                pairs = _collect_strip_pairs(rotated, phase_bonus=rotate_bonus + bonus, profile=profile)
                owner, score, raw = _best_owner_code_from_pairs(pairs)
                if owner and score > best_score:
                    best_owner = owner
                    best_score = score
                    best_raw = raw
    return best_owner, best_score, best_raw


def _best_vertical_owner_from_rois(letter_rois: list[Any], *, owner_block=None) -> tuple[str, float, str]:
    if len(letter_rois) < 4:
        return "", -1.0, ""

    rois = letter_rois[:4]
    best_owner = ""
    best_score = -1.0
    best_raw = ""

    if owner_block is not None and getattr(owner_block, "size", 0):
        block_owner, block_score, block_raw = _best_vertical_owner_from_block(owner_block)
        if block_owner and block_score > best_score:
            best_owner = block_owner
            best_score = block_score
            best_raw = block_raw

    direct_chars: list[str] = []
    direct_scores: list[float] = []
    for roi in rois:
        letter, score = _best_vertical_letter_from_roi(roi)
        if not letter:
            direct_chars = []
            direct_scores = []
            break
        direct_chars.append(letter)
        direct_scores.append(float(score))

    if len(direct_chars) == 4:
        owner_raw = "".join(direct_chars)
        owner = _force_owner_category_u(owner_raw)
        score = (sum(direct_scores) / 4.0) + 0.06
        best_owner = owner
        best_score = score
        best_raw = owner_raw

    strip = _compose_symbol_strip(rois, target_h=64, gap=10, outer_pad=8)
    if strip is not None and strip.size:
        for profile, bonus in (("light", 0.02), ("full", 0.01)):
            pairs = _collect_vertical_strip_pairs(strip, phase_bonus=bonus, profile=profile)
            owner, score, raw = _best_owner_code_from_pairs(pairs)
            if owner and score > best_score:
                best_owner = owner
                best_score = score
                best_raw = raw
        for profile, bonus in (("light", 0.03), ("full", 0.02)):
            pairs = _collect_strip_pairs(strip, phase_bonus=bonus, profile=profile)
            owner, score, raw = _best_owner_code_from_pairs(pairs)
            if owner and score > best_score:
                best_owner = owner
                best_score = score
                best_raw = raw

    return best_owner, best_score, best_raw


def _decode_vertical_rois_direct(rois: list[Any], *, owner_block=None) -> tuple[str, float, str, str, float, str]:
    if len(rois) < 10:
        return "", -1.0, "", "", -1.0, ""

    owner, owner_score, owner_raw = _best_vertical_owner_from_rois(rois[:4], owner_block=owner_block)
    if len(owner) != 4:
        return "", -1.0, "", "", -1.0, ""

    base_chars: list[str] = []
    base_scores: list[float] = []
    for roi in rois[4:10]:
        digit, score = _paddle_digit_from_roi(roi)
        if not digit:
            return "", -1.0, "", "", -1.0, ""
        base_chars.append(digit)
        base_scores.append(float(score))

    check_digit = ""
    check_scores: list[float] = []
    if len(rois) >= 11:
        digit, score = _read_digit_from_roi(rois[10], square_bias=True)
        if digit:
            check_digit = digit
            check_scores.append(float(score))

    base6 = "".join(base_chars)
    numeric_score = sum(base_scores) / float(max(1, len(base_scores)))
    if check_scores:
        numeric_score = max(numeric_score, sum(check_scores) / float(len(check_scores)))

    raw_text = f"{owner_raw}{base6}{check_digit}".strip()
    return owner, float(owner_score), base6, check_digit, float(numeric_score), raw_text


def _decode_vertical_rois(rois: list[Any], *, effort: str = "full", source_img=None) -> dict[str, Any]:
    if len(rois) < 10:
        return {
            "raw_text": "",
            "base10": "",
            "check_digit": "",
            "full_code": "",
            "score": -1.0,
            "is_valid_iso": False,
            "status": "NOT_FOUND",
        }

    rois = rois[:11]
    letter_rois = rois[:4]
    base_rois = rois[4:10]
    check_roi = rois[10] if len(rois) >= 11 else None

    symbol_h = 64 if effort == "full" else 44
    letter_gap = 10 if effort == "full" else 5
    digit_gap = 8 if effort == "full" else 4
    outer_pad = 8 if effort == "full" else 5
    owner_block = _extract_vertical_owner_block(
        source_img,
        parts=(11 if len(rois) >= 11 else 10),
    )

    letters_strip = _compose_symbol_strip(letter_rois, target_h=symbol_h, gap=letter_gap, outer_pad=outer_pad)
    digits6_strip = _compose_symbol_strip(base_rois, target_h=symbol_h, gap=digit_gap, outer_pad=outer_pad)
    check_strip = (
        _compose_symbol_strip([check_roi], target_h=symbol_h, gap=0, outer_pad=outer_pad + 2, square_last=True)
        if check_roi is not None
        else None
    )

    owner = ""
    owner_score = -1.0
    owner_raw = ""
    letter_pairs = _collect_vertical_strip_pairs(letters_strip, phase_bonus=0.02, profile="light")
    if letter_pairs:
        owner, owner_score, owner_raw = _best_owner_code_from_pairs(letter_pairs)
    if not owner and effort == "full":
        letter_pairs = _collect_vertical_strip_pairs(letters_strip, phase_bonus=0.01, profile="full")
        if letter_pairs:
            owner, owner_score, owner_raw = _best_owner_code_from_pairs(letter_pairs)

    direct_owner, direct_owner_score, direct_owner_raw = _best_vertical_owner_from_rois(
        letter_rois,
        owner_block=owner_block,
    )
    if direct_owner and direct_owner_score > owner_score:
        owner = direct_owner
        owner_score = direct_owner_score
        owner_raw = direct_owner_raw

    numeric_raw = ""
    base6 = ""
    check_digit = ""
    numeric_score = -1.0

    digits6_pairs = _collect_vertical_strip_pairs(digits6_strip, phase_bonus=0.02, profile="light")
    local_base6, local_check, local_score, local_raw = _best_vertical_numeric_read(digits6_pairs)
    if local_score > numeric_score:
        base6 = local_base6
        check_digit = local_check
        numeric_score = local_score
        numeric_raw = local_raw

    if not base6 and effort == "full":
        digits6_pairs = _collect_vertical_strip_pairs(digits6_strip, phase_bonus=0.0, profile="full")
        local_base6, local_check, local_score, local_raw = _best_vertical_numeric_read(digits6_pairs)
        if local_score > numeric_score:
            base6 = local_base6
            check_digit = local_check
            numeric_score = local_score
            numeric_raw = local_raw

    if base6 and not check_digit and check_strip is not None:
        square_digit, square_score = _best_digit_from_strip(check_strip, profile="minimal")
        if square_digit:
            check_digit = square_digit
            numeric_score = max(numeric_score, square_score)

    raw_text = " ".join(part for part in (owner_raw, numeric_raw) if part).strip()
    if len(owner) != 4 or len(base6) != 6:
        return {
            "raw_text": raw_text,
            "base10": "",
            "check_digit": "",
            "full_code": "",
            "score": -1.0,
            "is_valid_iso": False,
            "status": "RAW_ONLY" if raw_text else "NOT_FOUND",
        }

    base10 = f"{owner}{base6}"
    if len(check_digit) != 1 or not _is_valid_iso6346(f"{base10}{check_digit}"):
        check_digit = str(_iso6346_check_digit(base10))
    full_code = f"{base10}{check_digit}" if check_digit else base10
    return {
        "raw_text": raw_text,
        "base10": base10,
        "check_digit": check_digit,
        "full_code": full_code,
        "score": float(max(owner_score, 0.0) + max(numeric_score, 0.0)),
        "is_valid_iso": bool(len(full_code) == 11 and _is_valid_iso6346(full_code)),
        "status": "FULL_11" if len(full_code) == 11 else "PARTIAL_10",
    }


def _vertical_result_rank(result: dict[str, Any]) -> float:
    status = str(result.get("status") or "")
    rank = float(result.get("score", -1.0))
    if result.get("raw_text"):
        rank += 1.0
    if result.get("base10"):
        rank += 10.0
    if status == "PARTIAL_10":
        rank += 2.0
    elif status in {"FULL_11", "FULL_11_CONFIRMED"}:
        rank += 4.0
    elif status == "FULL_11_GUESSED_CHECK":
        rank += 3.5
    if result.get("is_valid_iso"):
        rank += 3.0
    return rank


def _should_try_vertical_grid10(result: dict[str, Any]) -> bool:
    if result.get("base10"):
        return False
    raw = clean(str(result.get("raw_text") or ""))
    if not raw:
        return False
    digit_count = sum(ch.isdigit() for ch in raw)
    letter_count = sum(ch.isalpha() for ch in raw)
    return letter_count == 0 and digit_count == 6


def _ocr_vertical_container_regions(img) -> dict[str, Any]:
    from . import container_ocr_vertical as vertical

    return vertical.ocr_vertical_container_regions(img)


def _ocr_twoline_container_regions(img, config: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    from . import container_ocr_twolines as twolines

    return twolines.ocr_twoline_container_regions(img, config=config)


def _extract_oneline_3zone_rois(img) -> Optional[dict[str, Any]]:
    if img is None or img.size == 0:
        return None

    left = _extract_zone(img, 0.02, 0.42, 0.02, 0.98)
    center = _extract_zone(img, 0.32, 0.92, 0.02, 0.98)
    right = _extract_zone(img, 0.84, 1.00, 0.02, 0.98)
    if left is None or center is None or right is None:
        return None
    if not left.size or not center.size or not right.size:
        return None

    return {
        "left_letters": left,
        "center_digits": center,
        "right_check": right,
        "left_symbols": _extract_horizontal_symbol_rois(left),
        "center_symbols": _extract_horizontal_symbol_rois(center),
        "right_symbols": _extract_horizontal_symbol_rois(right),
    }


def _ocr_oneline_3zone_regions(expanded) -> dict[str, Any]:
    split = _extract_oneline_3zone_rois(expanded)
    if not split:
        return {
            "raw_text": "",
            "base10": "",
            "check_digit": "",
            "full_code": "",
            "score": -1.0,
            "is_valid_iso": False,
            "status": "NOT_FOUND",
        }

    left = split["left_letters"]
    center = split["center_digits"]
    right = split["right_check"]

    left_symbols = split["left_symbols"]
    center_symbols = split["center_symbols"]
    right_symbols = split["right_symbols"]

    owner_input = (
        _compose_symbol_strip(left_symbols[:4], target_h=64, gap=10, outer_pad=8)
        if len(left_symbols) >= 4
        else left
    )

    owner = ""
    owner_score = -1.0
    owner_raw = ""
    for bonus, profile in ((0.04, "light"), (0.02, "full")):
        pairs = _collect_compact_strip_pairs(owner_input, phase_bonus=bonus, profile=profile)
        local_owner, local_score, local_raw = _best_owner_code_from_pairs(pairs)
        if local_owner and local_score > owner_score:
            owner = local_owner
            owner_score = local_score
            owner_raw = local_raw

    center6 = (
        _compose_symbol_strip(center_symbols[:6], target_h=64, gap=8, outer_pad=8)
        if len(center_symbols) >= 6
        else center
    )
    center7 = (
        _compose_symbol_strip(center_symbols[:7], target_h=64, gap=8, outer_pad=8)
        if len(center_symbols) >= 7
        else center6
    )
    right_input = (
        _compose_symbol_strip([right_symbols[-1]], target_h=64, gap=0, outer_pad=10, square_last=True)
        if right_symbols
        else right
    )

    numeric_candidates: list[dict[str, Any]] = []
    numeric_raw = ""
    for strip, bonus, profile in (
        (center7, 0.08, "light"),
        (center6, 0.05, "light"),
        (center, 0.02, "minimal"),
    ):
        pairs = _collect_compact_strip_pairs(strip, phase_bonus=bonus, profile=profile)
        if pairs and len(" ".join(text for text, _ in pairs)) > len(numeric_raw):
            numeric_raw = " ".join(text for text, _ in pairs).strip()
        numeric_candidates.extend(_numeric_region_candidates(pairs, phase_bonus=bonus))

    base6, check_digit, numeric_score, numeric_best_raw, _meta = _pick_best_numeric_candidate(numeric_candidates)
    if numeric_best_raw and len(numeric_best_raw) > len(numeric_raw):
        numeric_raw = numeric_best_raw

    right_digit = ""
    right_score = -1.0
    if right_input is not None and getattr(right_input, "size", 0):
        right_digit, right_score = _best_digit_from_strip(right_input, profile="minimal")
    if not right_digit:
        right_digit, right_score = _read_right_check_digit(expanded)
    if right_digit and (not check_digit or right_score > numeric_score):
        check_digit = right_digit
        numeric_score = max(numeric_score, right_score)

    raw_text = " ".join(part for part in (owner_raw, numeric_raw) if part).strip()
    if len(owner) != 4 or len(base6) != 6:
        return {
            "raw_text": raw_text,
            "base10": "",
            "check_digit": "",
            "full_code": "",
            "score": -1.0,
            "is_valid_iso": False,
            "status": "RAW_ONLY" if raw_text else "NOT_FOUND",
        }

    base10 = f"{owner}{base6}"
    full_code = f"{base10}{check_digit}" if check_digit else base10
    return {
        "raw_text": raw_text,
        "base10": base10,
        "check_digit": check_digit if len(full_code) == 11 else "",
        "full_code": full_code,
        "score": float(max(owner_score, 0.0) + max(numeric_score, 0.0)),
        "is_valid_iso": bool(len(full_code) == 11 and _is_valid_iso6346(full_code)),
        "status": "FULL_11" if len(full_code) == 11 else "PARTIAL_10",
    }


def _owner_code_candidates(raw: str) -> list[tuple[str, float]]:
    part = clean(raw)
    if not part:
        return []

    mapped = "".join(_TO_LETTER.get(ch, ch) for ch in part)
    letters_only = "".join(ch for ch in mapped if ch.isalpha())
    if len(letters_only) < 4:
        return []

    out: list[tuple[str, float]] = []
    seen: set[str] = set()

    def add(candidate: str, bonus: float) -> None:
        candidate = _force_owner_category_u(candidate)
        if len(candidate) != 4 or not candidate.isalpha() or candidate in seen:
            return
        seen.add(candidate)
        out.append((candidate, bonus))

    if len(letters_only) == 4:
        add(letters_only, 0.12)
    if len(letters_only) == 5:
        for idx in range(5):
            add(letters_only[:idx] + letters_only[idx + 1 :], 0.07)
    for idx in range(len(letters_only) - 3):
        add(letters_only[idx : idx + 4], 0.03)

    return out


def _best_owner_code_from_pairs(text_pairs: list[tuple[str, float]]) -> tuple[str, float, str]:
    best_code = ""
    best_score = -1.0
    best_raw = ""

    for raw_text, raw_score in _candidate_groups(text_pairs):
        for candidate, bonus in _owner_code_candidates(raw_text):
            final = float(raw_score) + bonus
            if len(clean(raw_text)) == 4:
                final += 0.03
            if final > best_score:
                best_code = candidate
                best_score = final
                best_raw = raw_text

    return best_code, best_score, best_raw


def _numeric_region_candidates(
    text_pairs: list[tuple[str, float]],
    *,
    phase_bonus: float = 0.0,
) -> list[dict[str, Any]]:
    candidates: list[dict[str, Any]] = []
    six_chunks: list[tuple[int, str, float]] = []
    check_chunks: list[tuple[int, str, float]] = []

    def add_candidate(
        base6: str,
        check_digit: str,
        score: float,
        raw: str,
        *,
        direct: bool = False,
        source: str = "unknown",
    ) -> None:
        if not base6 or len(base6) != 6 or not base6.isdigit():
            return
        if check_digit and (len(check_digit) != 1 or not check_digit.isdigit()):
            return
        candidates.append(
            {
                "base6": base6,
                "check_digit": check_digit,
                "score": float(score),
                "raw": raw,
                "direct": direct,
                "source": source,
            }
        )

    for idx, (raw_text, raw_score) in enumerate(text_pairs):
        mapped = "".join(_TO_DIGIT.get(ch, ch) for ch in clean(raw_text))
        chunks = _DIGIT_CHUNK_RE.findall(mapped)
        for chunk in chunks:
            score = float(raw_score) + phase_bonus
            if len(chunk) == 7:
                add_candidate(chunk[:6], chunk[6], score + 0.14, chunk, direct=True, source="direct7")
            elif len(chunk) == 6:
                six_chunks.append((idx, chunk, score))
                add_candidate(chunk, "", score + 0.04, chunk, direct=False, source="base6")
            elif len(chunk) == 1:
                check_chunks.append((idx, chunk, score + 0.03))
            elif len(chunk) == 2:
                check_chunks.append((idx, chunk[0], score - 0.05))
                check_chunks.append((idx, chunk[-1], score - 0.03))
            elif len(chunk) > 7:
                add_candidate(chunk[:6], chunk[-1], score - 0.02, chunk, direct=False, source="long")

    for six_idx, base6, six_score in six_chunks:
        for check_idx, check_digit, check_score in check_chunks:
            combo = (0.82 * six_score) + (0.18 * max(check_score, 0.0)) + 0.05
            if check_idx > six_idx:
                combo += 0.02
            add_candidate(base6, check_digit, combo, f"{base6}{check_digit}", direct=False, source="combo")

    return candidates


def _pick_best_numeric_candidate(candidates: list[dict[str, Any]]) -> tuple[str, str, float, str, dict[str, Any]]:
    if not candidates:
        return "", "", -1.0, "", {
            "has_direct_full": False,
            "check_vote_count": 0,
            "check_margin": 0.0,
        }

    base_votes: dict[str, float] = {}
    base_best: dict[str, tuple[float, str]] = {}
    check_votes: dict[tuple[str, str], float] = {}
    has_direct_full = False

    for item in candidates:
        base6 = item["base6"]
        score = float(item["score"])
        raw = str(item["raw"])
        base_votes[base6] = base_votes.get(base6, 0.0) + score
        best_score, _best_raw = base_best.get(base6, (-1.0, ""))
        if score > best_score:
            base_best[base6] = (score, raw)
        if item["check_digit"]:
            check_key = (base6, item["check_digit"])
            vote_bonus = 0.10 if item.get("direct") else 0.0
            check_votes[check_key] = check_votes.get(check_key, 0.0) + score + vote_bonus
            if item.get("direct"):
                has_direct_full = True

    best_base6 = max(base_votes.items(), key=lambda kv: kv[1])[0]
    best_raw = base_best.get(best_base6, (-1.0, ""))[1]

    per_base_digit_votes = [
        (digit, vote)
        for (base6, digit), vote in check_votes.items()
        if base6 == best_base6 and digit
    ]
    per_base_digit_votes.sort(key=lambda item: item[1], reverse=True)

    best_digit = ""
    best_score = base_votes[best_base6]
    if per_base_digit_votes:
        best_digit = per_base_digit_votes[0][0]
        best_score = per_base_digit_votes[0][1]

    margin = 0.0
    if len(per_base_digit_votes) >= 2:
        margin = per_base_digit_votes[0][1] - per_base_digit_votes[1][1]
    elif per_base_digit_votes:
        margin = per_base_digit_votes[0][1]

    meta = {
        "has_direct_full": has_direct_full,
        "check_vote_count": len(per_base_digit_votes),
        "check_margin": float(margin),
    }
    return best_base6, best_digit, float(best_score), best_raw, meta


def _collect_right_check_digit_votes(img, *, include_zone: bool = False) -> list[dict[str, Any]]:
    if img is None or img.size == 0:
        return []

    votes: list[dict[str, Any]] = []
    zones = [
        ("primary", _extract_zone(img, 0.72, 1.00, 0.03, 0.97)),
        ("mid", _extract_zone(img, 0.76, 1.00, 0.05, 0.95)),
        ("tight", _extract_zone(img, 0.84, 1.00, 0.02, 0.98)),
    ]

    for zone_name, zone in zones:
        if zone is None or not zone.size:
            continue

        for square_idx, (_rect, square_roi) in enumerate(_square_like_roi_entries(zone)[:2]):
            roi_candidates = [("square", square_roi)]
            inner = _safe_inner_crop(square_roi, margin_ratio=0.06)
            if inner is not None and inner.size:
                roi_candidates.append(("square_inner", inner))
            for roi_kind, roi in roi_candidates:
                digit, score = _read_digit_from_roi(roi, square_bias=True)
                if digit:
                    votes.append(
                        {
                            "digit": digit,
                            "score": float(score),
                            "source": roi_kind,
                            "zone": zone_name,
                            "order": square_idx,
                        }
                    )

        if include_zone:
            digit, score = _paddle_digit_from_roi(zone)
            if digit:
                votes.append(
                    {
                        "digit": digit,
                        "score": float(score),
                        "source": "zone",
                        "zone": zone_name,
                        "order": 99,
                    }
                )

    return votes


def _resolve_check_digit_for_base(
    base6: str,
    numeric_candidates: list[dict[str, Any]],
    right_side_votes: list[dict[str, Any]],
) -> tuple[str, float, dict[str, Any]]:
    if not base6:
        return "", -1.0, {"vote_count": 0, "margin": 0.0, "direct_count": 0, "square_count": 0}

    digit_votes: dict[str, float] = {}
    direct_count = 0
    square_count = 0
    numeric_digits_seen: set[str] = set()

    for item in numeric_candidates:
        if item.get("base6") != base6 or not item.get("check_digit"):
            continue
        digit = str(item["check_digit"])
        numeric_digits_seen.add(digit)
        score = float(item["score"])
        source = str(item.get("source") or "")
        if source == "direct7":
            weight = score + 0.34
            direct_count += 1
        elif source == "long":
            weight = score + 0.10
        elif source == "combo":
            weight = max(0.0, score * 0.74)
        else:
            weight = max(0.0, score * 0.66)
        digit_votes[digit] = digit_votes.get(digit, 0.0) + weight

    if right_side_votes:
        direct_digits = {
            str(item["check_digit"])
            for item in numeric_candidates
            if item.get("base6") == base6 and item.get("source") == "direct7" and item.get("check_digit")
        }
        for vote in right_side_votes:
            digit = str(vote["digit"])
            if numeric_digits_seen and digit not in numeric_digits_seen:
                continue
            score = float(vote["score"])
            source = str(vote.get("source") or "")
            if source.startswith("square"):
                weight = score + 0.18
                square_count += 1
            else:
                weight = max(0.0, score - 0.12)
            if direct_digits and digit in direct_digits:
                weight += 0.08
            digit_votes[digit] = digit_votes.get(digit, 0.0) + weight

    if not digit_votes:
        return "", -1.0, {"vote_count": 0, "margin": 0.0, "direct_count": direct_count, "square_count": square_count}

    ranked = sorted(digit_votes.items(), key=lambda item: item[1], reverse=True)
    best_digit, best_score = ranked[0]
    margin = ranked[0][1] - ranked[1][1] if len(ranked) >= 2 else ranked[0][1]
    meta = {
        "vote_count": len(ranked),
        "margin": float(margin),
        "direct_count": direct_count,
        "square_count": square_count,
    }
    return best_digit, float(best_score), meta


def _ocr_horizontal_container_regions(
    expanded,
    *,
    enable_resize_digit_pass: bool = True,
    enable_oneline_slow_fallback: bool = True,
) -> dict[str, Any]:
    from . import container_ocr_oneline as oneline

    return oneline.ocr_horizontal_container_regions(
        expanded,
        enable_resize_digit_pass=enable_resize_digit_pass,
        enable_oneline_slow_fallback=enable_oneline_slow_fallback,
    )


def _expand_crop(img, left_ratio: float = 0.10, right_ratio: float = 0.12, top_ratio: float = 0.07, bottom_ratio: float = 0.07):
    h, w = img.shape[:2]
    left = max(1, int(w * left_ratio))
    right = max(1, int(w * right_ratio))
    top = max(1, int(h * top_ratio))
    bottom = max(1, int(h * bottom_ratio))
    return cv2.copyMakeBorder(img, top, bottom, left, right, cv2.BORDER_REPLICATE)


def _rotate_image(img, angle_deg: float):
    if img is None or img.size == 0:
        return img
    h, w = img.shape[:2]
    center = (w * 0.5, h * 0.5)
    matrix = cv2.getRotationMatrix2D(center, angle_deg, 1.0)
    return cv2.warpAffine(
        img,
        matrix,
        (w, h),
        flags=cv2.INTER_CUBIC,
        borderMode=cv2.BORDER_REPLICATE,
    )


def _best_digit_from_pairs(text_pairs: list[tuple[str, float]]) -> tuple[str, float]:
    best_digit = ""
    best_score = -1.0
    for text, score in text_pairs:
        s = clean(text)
        mapped = "".join(_TO_DIGIT.get(ch, ch) for ch in s)
        digits = [(idx, ch) for idx, ch in enumerate(mapped) if ch.isdigit()]
        if not digits:
            continue

        for idx, digit in digits:
            candidate_score = float(score)
            if len(digits) == 1:
                candidate_score += 0.12
            if idx == len(mapped) - 1:
                candidate_score += 0.04
            if len(mapped) <= 2:
                candidate_score += 0.04
            if len(digits) > 1:
                candidate_score -= 0.03 * float(len(digits) - 1)

            if candidate_score > best_score:
                best_digit = digit
                best_score = candidate_score
    return best_digit, best_score


def _gray_to_bgr(gray):
    return cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)


def _digit_preprocess_variants(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.bilateralFilter(gray, 5, 40, 40)
    clahe = cv2.createCLAHE(clipLimit=2.4, tileGridSize=(8, 8))
    gray = clahe.apply(gray)
    _, otsu_inv = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    adaptive = cv2.adaptiveThreshold(
        gray,
        255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY_INV,
        31,
        3,
    )
    return [img, _gray_to_bgr(gray), _gray_to_bgr(otsu_inv), _gray_to_bgr(adaptive)]


def _extract_zone(img, x_from: float, x_to: float, y_from: float, y_to: float):
    h, w = img.shape[:2]
    x1 = max(0, int(w * x_from))
    x2 = min(w, int(w * x_to))
    y1 = max(0, int(h * y_from))
    y2 = min(h, int(h * y_to))
    if x2 <= x1 or y2 <= y1:
        return None
    zone = img[y1:y2, x1:x2]
    if zone.size == 0:
        return None
    return zone


def _safe_inner_crop(img, margin_ratio: float = 0.16):
    h, w = img.shape[:2]
    if h < 8 or w < 8:
        return None
    dx = max(1, int(w * margin_ratio))
    dy = max(1, int(h * margin_ratio))
    if dx * 2 >= w or dy * 2 >= h:
        return None
    cropped = img[dy:h - dy, dx:w - dx]
    if cropped.size == 0:
        return None
    return cropped


def _rect_iou(a: tuple[int, int, int, int], b: tuple[int, int, int, int]) -> float:
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    ix1 = max(ax1, bx1)
    iy1 = max(ay1, by1)
    ix2 = min(ax2, bx2)
    iy2 = min(ay2, by2)
    if ix2 <= ix1 or iy2 <= iy1:
        return 0.0
    inter = float((ix2 - ix1) * (iy2 - iy1))
    area_a = float(max(1, (ax2 - ax1) * (ay2 - ay1)))
    area_b = float(max(1, (bx2 - bx1) * (by2 - by1)))
    return inter / max(1.0, area_a + area_b - inter)


def _square_like_roi_entries(zone) -> list[tuple[tuple[int, int, int, int], Any]]:
    gray = cv2.cvtColor(zone, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (3, 3), 0)
    edges = cv2.Canny(blur, 60, 180)
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    zh, zw = zone.shape[:2]
    zone_area = float(max(1, zh * zw))
    raw_entries: list[tuple[float, tuple[int, int, int, int], Any]] = []
    for c in contours:
        x, y, w, h = cv2.boundingRect(c)
        if w <= 2 or h <= 2:
            continue
        area = float(w * h)
        ratio = w / float(h)
        if area < zone_area * 0.01 or area > zone_area * 0.45:
            continue
        if ratio < 0.62 or ratio > 1.45:
            continue
        if x < int(zw * 0.08):
            continue

        pad = int(max(w, h) * 0.14)
        x1 = max(0, x - pad)
        y1 = max(0, y - pad)
        x2 = min(zw, x + w + pad)
        y2 = min(zh, y + h + pad)
        roi = zone[y1:y2, x1:x2]
        if roi.size == 0:
            continue
        raw_entries.append((area, (x1, y1, x2, y2), roi))

    raw_entries.sort(key=lambda it: it[0], reverse=True)
    deduped: list[tuple[tuple[int, int, int, int], Any]] = []
    for _area, rect, roi in raw_entries:
        if any(_rect_iou(rect, kept_rect) >= 0.72 for kept_rect, _ in deduped):
            continue
        deduped.append((rect, roi))
        if len(deduped) >= 2:
            break
    return deduped


def _square_like_rois(zone):
    return [roi for _, roi in _square_like_roi_entries(zone)]


def _tesseract_digit_from_image(img, *, psm: int = 10) -> str:
    exe = _resolve_tesseract_executable()
    if not exe or img is None or img.size == 0:
        return ""

    temp_path = None
    try:
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
            temp_path = tmp.name
        cv2.imwrite(temp_path, img)
        completed = subprocess.run(
            [
                exe,
                temp_path,
                "stdout",
                "--psm",
                str(psm),
                "--oem",
                "1",
                "-c",
                "tessedit_char_whitelist=0123456789",
            ],
            capture_output=True,
            text=True,
            timeout=15,
        )
    except Exception:
        return ""
    finally:
        if temp_path:
            try:
                os.remove(temp_path)
            except OSError:
                pass

    text = "".join(ch for ch in completed.stdout if ch.isdigit())
    return text if len(text) == 1 else ""


def _tesseract_vote_digit(
    roi,
    *,
    base_weight: float,
    preprocess_indices: tuple[int, ...],
    scales: tuple[float, ...],
) -> tuple[str, float]:
    votes: dict[str, float] = {}
    variants = _digit_preprocess_variants(roi)
    for variant_idx in preprocess_indices:
        if variant_idx >= len(variants):
            continue
        prepared = variants[variant_idx]
        for scale in scales:
            up = cv2.resize(prepared, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
            digit = _tesseract_digit_from_image(up, psm=10)
            if not digit:
                continue
            weight = base_weight
            if variant_idx in (1, 2):
                weight += 0.45
            elif variant_idx == 3:
                weight += 0.15
            votes[digit] = votes.get(digit, 0.0) + weight

    if not votes:
        return "", -1.0
    return max(votes.items(), key=lambda kv: kv[1])


def _paddle_digit_from_roi(roi) -> tuple[str, float]:
    if roi is None or roi.size == 0:
        return "", -1.0

    best_digit = ""
    best_score = -1.0
    variants = _digit_preprocess_variants(roi)
    # Limit digit OCR to the most useful variants to keep latency reasonable.
    for variant_idx in (1, 3, 0):
        if variant_idx >= len(variants):
            continue
        prepared = variants[variant_idx]
        up = cv2.resize(prepared, None, fx=2.8, fy=2.8, interpolation=cv2.INTER_CUBIC)
        pairs = _extract_text_pairs(_run_ocr(up))
        digit, score = _best_digit_from_pairs(pairs)
        if digit and score > best_score:
            best_digit = digit
            best_score = score
    return best_digit, best_score


def _paddle_digit_from_square_roi(roi) -> tuple[str, float]:
    if roi is None or roi.size == 0:
        return "", -1.0

    best_digit = ""
    best_score = -1.0
    variants = _digit_preprocess_variants(roi)
    # For boxed check-digits adaptive/inverted variants often deform "4" into "7".
    for variant_idx in (0, 1):
        if variant_idx >= len(variants):
            continue
        prepared = variants[variant_idx]
        for scale, bonus in ((3.0, 0.03), (3.6, 0.05)):
            up = cv2.resize(prepared, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
            pairs = _extract_text_pairs(_run_ocr(up))
            digit, score = _best_digit_from_pairs(pairs)
            if digit and (score + bonus) > best_score:
                best_digit = digit
                best_score = score + bonus
    return best_digit, best_score


def _read_digit_from_roi(roi, *, square_bias: bool = False) -> tuple[str, float]:
    if square_bias:
        digit, score = _paddle_digit_from_square_roi(roi)
    else:
        digit, score = _paddle_digit_from_roi(roi)
    if not digit:
        return "", -1.0
    adjusted = score + (0.03 if square_bias else 0.0)
    return digit, adjusted


def _read_right_check_digit(img) -> tuple[str, float]:
    votes = _collect_right_check_digit_votes(img, include_zone=True)
    if not votes:
        return "", -1.0
    digit_totals: dict[str, float] = {}
    for vote in votes:
        digit = str(vote["digit"])
        score = float(vote["score"])
        source = str(vote.get("source") or "")
        weight = score + 0.08 if source.startswith("square") else max(0.0, score - 0.12)
        digit_totals[digit] = digit_totals.get(digit, 0.0) + weight
    return max(digit_totals.items(), key=lambda item: item[1])


def _best_container_from_result(result) -> tuple[str, float, bool, dict[str, Any]]:
    text_pairs = _extract_text_pairs(result)
    debug: dict[str, Any] = {
        "text_pair_count": len(text_pairs),
        "text_pairs": _text_pair_preview(text_pairs),
    }
    if not text_pairs:
        debug["reason"] = "ocr_no_text_pairs"
        return "", -1.0, False, debug

    best_code = ""
    best_final = -1.0
    best_valid = False
    candidate_groups = _candidate_groups(text_pairs)
    debug["candidate_group_count"] = len(candidate_groups)
    debug["candidate_groups"] = [raw for raw, _score in candidate_groups[:8]]
    normalized_hits: list[str] = []

    for raw_candidate, raw_score in candidate_groups:
        for normalized in _normalized_candidates(raw_candidate):
            if normalized not in normalized_hits and len(normalized_hits) < 8:
                normalized_hits.append(normalized)
            quality = _container_text_quality(normalized)
            final = 0.75 * float(raw_score) + 0.25 * quality
            is_valid = _is_valid_iso6346(normalized)
            if is_valid:
                final += 0.10
            if final > best_final:
                best_code = normalized
                best_final = final
                best_valid = is_valid

    debug["normalized_candidate_count"] = len(normalized_hits)
    debug["normalized_candidates"] = normalized_hits
    if best_code:
        debug["reason"] = "ok"
        debug["best_code"] = best_code
        debug["best_score"] = round(float(best_final), 4)
        debug["best_valid"] = bool(best_valid)
    else:
        debug["reason"] = "ocr_text_pairs_no_container_candidate"
    return best_code, best_final, best_valid, debug


def _predict_image(img) -> tuple[str, float, bool, dict[str, Any]]:
    result = _run_ocr(img)
    return _best_container_from_result(result)


def _cache_key(img) -> str:
    h, w = img.shape[:2]
    digest = hashlib.blake2b(img.tobytes(), digest_size=16).hexdigest()
    return f"{h}x{w}:{digest}"


def _cache_get(key: str):
    value = _CACHE.get(key)
    if value is None:
        return None
    _CACHE.move_to_end(key)
    return value


def _cache_set(key: str, value):
    _CACHE[key] = value
    _CACHE.move_to_end(key)
    while len(_CACHE) > CACHE_SIZE:
        _CACHE.popitem(last=False)


def ocr_container_best_details(img) -> dict[str, Any]:
    if img is None:
        return {
            "text": "",
            "score": -1.0,
            "is_valid": False,
            "ocr_debug": {"reason": "image_none"},
        }

    key = _cache_key(img)
    cached = _cache_get(key)
    if cached is not None:
        text, score, is_valid, ocr_debug = cached
        return {
            "text": text,
            "score": score,
            "is_valid": is_valid,
            "ocr_debug": dict(ocr_debug),
        }

    best_text = ""
    best_score = -1.0
    best_valid = False
    best_debug: dict[str, Any] = {"reason": "uninitialized"}

    img_fast = _preprocess_fast(img)
    text, score, is_valid, ocr_debug = _predict_image(img_fast)
    ocr_debug = dict(ocr_debug)
    ocr_debug["variant"] = "fast"
    if score > best_score:
        best_text, best_score, best_valid, best_debug = text, score, is_valid, ocr_debug

    if best_valid and best_score >= EARLY_OK:
        result = (best_text, best_score, best_valid, best_debug)
        _cache_set(key, result)
        return {
            "text": best_text,
            "score": best_score,
            "is_valid": best_valid,
            "ocr_debug": dict(best_debug),
        }

    img_hard = _preprocess_hard(img)
    text, score, is_valid, ocr_debug = _predict_image(img_hard)
    ocr_debug = dict(ocr_debug)
    ocr_debug["variant"] = "hard"
    if score > best_score:
        best_text, best_score, best_valid, best_debug = text, score, is_valid, ocr_debug

    result = (best_text, best_score, best_valid, best_debug)
    _cache_set(key, result)
    return {
        "text": best_text,
        "score": best_score,
        "is_valid": best_valid,
        "ocr_debug": dict(best_debug),
    }


def ocr_container_best(img):
    details = ocr_container_best_details(img)
    return (
        str(details.get("text") or ""),
        float(details.get("score") or -1.0),
        bool(details.get("is_valid")),
    )


def _ocr_container_from_crop_generic(img) -> dict[str, Any]:
    if img is None:
        return {
            "raw_text": "",
            "base10": "",
            "check_digit": "",
            "full_code": "",
            "score": -1.0,
            "is_valid_iso": False,
            "status": "NOT_FOUND",
        }

    best_raw = ""
    best_norm = ""
    best_base10 = ""
    best_pairs: list[tuple[str, float]] = []
    best_score = -1.0
    best_valid = False

    def _evaluate_variant(base_img):
        nonlocal best_raw, best_norm, best_base10, best_pairs, best_score, best_valid
        for prepared in (_preprocess_fast(base_img), _preprocess_hard(base_img)):
            result = _run_ocr(prepared)
            text_pairs = _extract_text_pairs(result)
            raw_text = " ".join(text for text, _ in text_pairs).strip()

            local_best_norm = ""
            local_best_base10 = ""
            local_score = -1.0
            local_valid = False

            for raw_candidate, raw_score in _candidate_groups(text_pairs):
                for normalized in _normalized_candidates(raw_candidate):
                    quality = _container_text_quality(normalized)
                    final = 0.8 * float(raw_score) + 0.2 * quality
                    is_valid = _is_valid_iso6346(normalized)
                    if final > local_score:
                        local_best_norm = normalized
                        local_best_base10 = normalized[:10]
                        local_score = final
                        local_valid = is_valid

                for base10 in _normalized_base_candidates(raw_candidate):
                    quality10 = _container_base_quality(base10)
                    final10 = 0.8 * float(raw_score) + 0.2 * quality10 - 0.02
                    if final10 > local_score:
                        local_best_norm = ""
                        local_best_base10 = base10
                        local_score = final10
                        local_valid = False

            rank = local_score
            if rank <= -1.0 and text_pairs:
                # Keep strongest raw pass even without normalized candidate.
                rank = max(float(s) for _, s in text_pairs) * 0.5

            if rank > best_score:
                best_raw = raw_text
                best_norm = local_best_norm
                best_base10 = local_best_base10
                best_pairs = list(text_pairs)
                best_score = rank
                best_valid = local_valid

    expanded = _expand_crop(img)
    variants = [img, expanded]
    if img.shape[1] > 0:
        variants.append(cv2.resize(expanded, None, fx=1.35, fy=1.35, interpolation=cv2.INTER_CUBIC))
    for base_img in variants:
        _evaluate_variant(base_img)

    # Hard fallback: tiny skew often kills first letters on already-cropped images.
    if not best_base10 and not best_norm:
        for angle in (-3.0, 3.0):
            _evaluate_variant(_rotate_image(expanded, angle))
            if best_base10 or best_norm:
                break

    if best_base10:
        # Always prefer the specialized right-side digit reader over a full-code guess
        # produced by the general OCR stream.
        digit, digit_score = _read_right_check_digit(expanded)
        if digit:
            best_norm = f"{best_base10}{digit}"
            best_score = max(best_score, digit_score)

    result = best_norm or best_base10
    base10 = ""
    check_digit = ""
    if result and len(result) >= 10 and result[:4].isalpha() and result[4:10].isdigit():
        base10 = result[:10]
    if result and len(result) == 11 and result[-1].isdigit():
        check_digit = result[-1]

    if len(result) == 11:
        status = "FULL_11"
    elif len(result) == 10:
        status = "PARTIAL_10"
    elif best_raw:
        status = "RAW_ONLY"
    else:
        status = "NOT_FOUND"

    return {
        "raw_text": best_raw,
        "base10": base10,
        "check_digit": check_digit,
        "full_code": result if result else "",
        "score": float(best_score),
        "is_valid_iso": bool(best_valid),
        "status": status,
    }


def ocr_container_from_crop_details(img, config: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    """
    OCR for already-cropped container region.
    Returns:
      raw_text, base10, check_digit, full_code, score, is_valid_iso, status
    """
    if img is None:
        return {
            "raw_text": "",
            "base10": "",
            "check_digit": "",
            "full_code": "",
            "score": -1.0,
            "is_valid_iso": False,
            "status": "NOT_FOUND",
        }

    runtime_config = dict(config or {})
    recognition_mode = str(runtime_config.get("recognition_mode", "accurate") or "accurate").strip().lower()
    if recognition_mode == "fast":
        runtime_config["enable_resize_digit_pass"] = False
        runtime_config["enable_oneline_slow_fallback"] = False
    use_specialized = bool(SPECIALIZED_OCR_SETTINGS["routing"]["enable_specialized_routes"])
    is_low_res_video_like = bool(SPECIALIZED_OCR_SETTINGS["routing"]["auto_low_res_video_like"]) and _looks_like_low_res_video_frame(img, config=runtime_config)

    if is_low_res_video_like:
        low_res_cfg = SPECIALIZED_OCR_SETTINGS["low_res_video_like"]
        expanded = _expand_crop(
            img,
            left_ratio=float(low_res_cfg["expand_left_ratio"]),
            right_ratio=float(low_res_cfg["expand_right_ratio"]),
            top_ratio=float(low_res_cfg["expand_top_ratio"]),
            bottom_ratio=float(low_res_cfg["expand_bottom_ratio"]),
        )
    else:
        expanded = _expand_crop(img)

    h, w = img.shape[:2]
    enable_resize_digit_pass = bool(runtime_config.get("enable_resize_digit_pass", False))
    enable_oneline_slow_fallback = bool(runtime_config.get("enable_oneline_slow_fallback", True))
    twolines_max_ratio = float(runtime_config.get("layout_twolines_max_ratio", 3.0))
    layout_type = "unknown"
    if _is_vertical_crop(img):
        layout_type = "vertical"
    elif (w / float(max(1, h))) <= twolines_max_ratio:
        # Layout classifier is used only for likely two-line crops.
        layout_type = classify_container_layout(img, runtime_config)
    else:
        layout_type = "oneline"
    ratio = w / float(max(1, h))
    logger.info(
        "route: layout h=%d w=%d ratio=%.3f layout=%s low_res_video_like=%s",
        h,
        w,
        ratio,
        layout_type,
        is_low_res_video_like,
    )

    if layout_type == "twolines":
        has_split_geometry = _detect_split_door_4_2_box(img, config=runtime_config)
        if has_split_geometry:
            logger.info("route: twolines(split geometry) -> split_door_4_2_box")
            return _ocr_split_door_4_2_box(img, config=runtime_config)

        logger.info("route: twolines(no split geometry) -> _ocr_twoline_container_regions")
        twoline = _ocr_twoline_container_regions(img, config=runtime_config)
        if bool(twoline.get("is_valid_iso")) and str(twoline.get("status") or "") == "FULL_11":
            return twoline

        logger.info("route: twolines fallback compare -> _ocr_split_door_container_regions")
        split_candidate = _ocr_split_door_container_regions(img, config=runtime_config)
        twoline_rank = _result_structure_rank(twoline)
        split_rank = _result_structure_rank(split_candidate)
        if split_rank > twoline_rank:
            return split_candidate
        if twoline.get("base10") or twoline.get("raw_text"):
            return twoline

    if use_specialized and _detect_split_door_4_2_box(img, config=runtime_config):
        logger.info("route: specialized -> split_door_4_2_box")
        specialized = _ocr_split_door_4_2_box(img, config=runtime_config)
        if specialized.get("base10") or specialized.get("raw_text"):
            return specialized

    if layout_type == "oneline" or _is_horizontal_crop(img):
        logger.info("route: oneline -> _ocr_horizontal_container_regions")
        horizontal = _ocr_horizontal_container_regions(
            expanded,
            enable_resize_digit_pass=enable_resize_digit_pass,
            enable_oneline_slow_fallback=enable_oneline_slow_fallback,
        )
        if horizontal.get("base10"):
            return horizontal

    if layout_type == "vertical" or _is_vertical_crop(img):
        logger.info("route: vertical -> vertical_narrow_boxed")
        vertical = _ocr_vertical_narrow_boxed(img, config=runtime_config)
        if vertical.get("base10"):
            return vertical
        if vertical.get("raw_text") and layout_type != "oneline":
            return vertical

    if use_specialized and _detect_vertical_narrow_boxed(img, config=runtime_config):
        logger.info("route: specialized -> vertical_narrow_boxed")
        specialized = _ocr_vertical_narrow_boxed(img, config=runtime_config)
        if specialized.get("base10") or specialized.get("raw_text"):
            return specialized

    generic = _ocr_container_from_crop_generic(img)
    if str(generic.get("status") or "") == "PARTIAL_10" and len(str(generic.get("base10") or "")) == 10:
        split_candidate = _ocr_split_door_container_regions(img, config=runtime_config)
        if _result_structure_rank(split_candidate) > _result_structure_rank(generic):
            return split_candidate
    return generic

def ocr_container_from_crop(img) -> tuple[str, str, float, bool]:
    details = ocr_container_from_crop_details(img)
    return (
        details.get("raw_text", ""),
        details.get("full_code", ""),
        float(details.get("score", -1.0)),
        bool(details.get("is_valid_iso", False)),
    )
