from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_CONFIG_PATH = PROJECT_ROOT / "app" / "config" / "admin_ui_config.json"

_CONFIG: dict[str, Any] = {}


def _resolve_config_path() -> Path:
    raw = os.getenv("ADMIN_UI_CONFIG_PATH", "").strip()
    if not raw:
        return DEFAULT_CONFIG_PATH
    path = Path(raw).expanduser()
    if path.is_absolute():
        return path
    return PROJECT_ROOT / path


def reload_admin_ui_config() -> None:
    global _CONFIG
    path = _resolve_config_path()
    if not path.exists():
        _CONFIG = {}
        return
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        _CONFIG = {}
        return
    _CONFIG = data if isinstance(data, dict) else {}


def _lookup(path: str) -> Any:
    current: Any = _CONFIG
    for part in path.split("."):
        if not isinstance(current, dict):
            return None
        if part not in current:
            return None
        current = current[part]
    return current


def _parse_csv(value: str) -> list[str]:
    out: list[str] = []
    for part in value.replace(";", ",").split(","):
        item = part.strip().lower()
        if item:
            out.append(item)
    return out


def _coerce_bool(value: Any) -> bool | None:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
    return None


def _coerce_int(value: Any) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    if isinstance(value, str):
        try:
            return int(value.strip())
        except ValueError:
            return None
    return None


def get_bool(path: str, default: bool, *, env_var: str | None = None) -> bool:
    reload_admin_ui_config()
    if env_var:
        raw = os.getenv(env_var)
        if raw is not None:
            env_value = _coerce_bool(raw)
            if env_value is not None:
                return env_value
    cfg_value = _coerce_bool(_lookup(path))
    if cfg_value is not None:
        return cfg_value
    return default


def get_int(path: str, default: int, *, env_var: str | None = None) -> int:
    reload_admin_ui_config()
    if env_var:
        raw = os.getenv(env_var)
        if raw is not None:
            env_value = _coerce_int(raw)
            if env_value is not None:
                return env_value
    cfg_value = _coerce_int(_lookup(path))
    if cfg_value is not None:
        return cfg_value
    return default


def _sanitize_tabs(raw_tabs: list[str], allowed_tabs: tuple[str, ...]) -> list[str]:
    picked: list[str] = []
    seen: set[str] = set()
    for tab in raw_tabs:
        if tab not in allowed_tabs or tab in seen:
            continue
        seen.add(tab)
        picked.append(tab)
    return picked


def get_visible_tabs(allowed_tabs: tuple[str, ...]) -> list[str]:
    reload_admin_ui_config()

    raw_env = os.getenv("ADMIN_UI_VISIBLE_TABS", "").strip()
    if raw_env:
        env_tabs = _sanitize_tabs(_parse_csv(raw_env), allowed_tabs)
        if env_tabs:
            return env_tabs

    cfg_value = _lookup("ui.visible_tabs")
    if isinstance(cfg_value, list):
        cfg_tabs = _sanitize_tabs(
            [str(item).strip().lower() for item in cfg_value if str(item).strip()],
            allowed_tabs,
        )
        if cfg_tabs:
            return cfg_tabs
    if isinstance(cfg_value, str):
        cfg_tabs = _sanitize_tabs(_parse_csv(cfg_value), allowed_tabs)
        if cfg_tabs:
            return cfg_tabs

    return list(allowed_tabs)
