from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Optional, Sequence

import cv2
import numpy as np

from . import container_ocr as core

Box = tuple[int, int, int, int]

STATUS_FULL_CONFIRMED = "FULL_11_CONFIRMED"
STATUS_FULL_GUESSED = "FULL_11_GUESSED_CHECK"
STATUS_PARTIAL_10 = "PARTIAL_10"
STATUS_RAW_ONLY = "RAW_ONLY"
STATUS_NOT_FOUND = "NOT_FOUND"

VERTICAL_CFG_DEFAULTS: dict[str, Any] = {
    "vertical_target_height": 1600,
    "vertical_min_abs_angle_deg": 0.15,
    "vertical_max_abs_angle_deg": 18.0,
    "vertical_pad_x_ratio": 0.10,
    "vertical_pad_top_ratio": 0.03,
    "vertical_pad_bottom_ratio": 0.10,
    "vertical_mask_close_kernel_y": 5,
    "vertical_mask_open_kernel": 2,
    "vertical_mask_min_component_area_ratio": 0.00010,
    "vertical_column_col_threshold_scale": 0.52,
    "vertical_column_row_threshold_scale": 0.42,
    "vertical_profile_smooth_ksize": 11,
    "vertical_profile_threshold_scale": 0.58,
    "vertical_profile_width_threshold_scale": 0.04,
    "vertical_profile_x_margin_ratio": 0.05,
    "vertical_profile_threshold_scales": [0.92, 1.0, 1.08],
    "vertical_min_foreground_ratio": 0.030,
    "vertical_empty_box_foreground_ratio": 0.014,
    "vertical_min_box_height_ratio": 0.030,
    "vertical_max_box_height_ratio": 0.180,
    "vertical_expected_symbol_tolerance": 0.45,
    "vertical_min_valley_depth": 0.18,
    "vertical_split_min_height_factor": 1.55,
    "vertical_split_max_parts": 8,
    "vertical_max_overlap": 0.12,
    "vertical_max_gap": 1.05,
    "vertical_repair_max_iterations": 3,
    "vertical_keep_min_boxes": 8,
    "vertical_candidate_limit": 3,
    "vertical_segmentation_mask_variants": ["current", "bright_lab", "gray_adaptive", "strict_light"],
    "vertical_use_iso_guess_for_check_digit": True,
    "vertical_debug": False,
    "vertical_debug_dir": "debug_runs",
    "vertical_debug_name": "",
}

_VERTICAL_GLOBAL_BOUNDARY_RATIOS: list[float] = [
    0.0096,
    0.0984,
    0.1876,
    0.2734,
    0.3798,
    0.4840,
    0.5651,
    0.6483,
    0.7296,
    0.8084,
    0.9063,
    1.0,
]


def _cfg(config: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    merged = dict(VERTICAL_CFG_DEFAULTS)
    if config:
        for key in list(merged.keys()):
            if key in config:
                merged[key] = config[key]
    scales = merged.get("vertical_profile_threshold_scales", [1.0])
    if isinstance(scales, (int, float)):
        scales = [float(scales)]
    elif isinstance(scales, str):
        try:
            loaded = json.loads(scales)
            scales = loaded if isinstance(loaded, list) else [float(loaded)]
        except Exception:
            scales = [1.0]
    merged["vertical_profile_threshold_scales"] = [
        float(item) for item in scales if float(item) > 0.0
    ] or [1.0]
    mask_variants = merged.get("vertical_segmentation_mask_variants", ["current"])
    if isinstance(mask_variants, str):
        try:
            loaded = json.loads(mask_variants)
            mask_variants = loaded if isinstance(loaded, list) else [mask_variants]
        except Exception:
            mask_variants = [item.strip() for item in mask_variants.split(",") if item.strip()]
    merged["vertical_segmentation_mask_variants"] = [str(item) for item in mask_variants] or ["current"]
    return merged


def _empty_result(status: str = STATUS_NOT_FOUND) -> dict[str, Any]:
    return {
        "raw_text": "",
        "base10": "",
        "check_digit": "",
        "full_code": "",
        "score": -1.0,
        "is_valid_iso": False,
        "status": status,
        "check_digit_source": "",
        "guessed_check_digit": False,
        "segmentation_score": 0.0,
        "segmentation_method": "",
        "debug_dir": "",
    }


def _is_full_status(status: str) -> bool:
    return status in {STATUS_FULL_CONFIRMED, STATUS_FULL_GUESSED, "FULL_11"}


def _vertical_result_rank(result: dict[str, Any]) -> float:
    status = str(result.get("status") or "")
    rank = float(result.get("score", -1.0))
    rank += float(result.get("segmentation_score", 0.0)) * 0.45
    if result.get("raw_text"):
        rank += 0.8
    if result.get("base10"):
        rank += 8.0
    if status == STATUS_PARTIAL_10:
        rank += 2.0
    elif status == STATUS_FULL_GUESSED:
        rank += 4.5
    elif status == STATUS_FULL_CONFIRMED or status == "FULL_11":
        rank += 6.0
    if result.get("is_valid_iso"):
        rank += 2.5
    return rank


def _box_w(box: Box) -> int:
    return max(0, int(box[2] - box[0]))


def _box_h(box: Box) -> int:
    return max(0, int(box[3] - box[1]))


def _clip_box(box: Box, width: int, height: int) -> Optional[Box]:
    x1, y1, x2, y2 = [int(v) for v in box]
    x1 = max(0, min(width - 1, x1))
    x2 = max(0, min(width, x2))
    y1 = max(0, min(height - 1, y1))
    y2 = max(0, min(height, y2))
    if x2 <= x1 or y2 <= y1:
        return None
    return x1, y1, x2, y2


def _serialize_box(box: Box) -> list[int]:
    return [int(box[0]), int(box[1]), int(box[2]), int(box[3])]


def _crop_box(img: np.ndarray, box: Box, *, pad_x: int = 3, pad_y: int = 3) -> Optional[np.ndarray]:
    if img is None or img.size == 0:
        return None
    h, w = img.shape[:2]
    clipped = _clip_box((box[0] - pad_x, box[1] - pad_y, box[2] + pad_x, box[3] + pad_y), w, h)
    if clipped is None:
        return None
    x1, y1, x2, y2 = clipped
    roi = img[y1:y2, x1:x2]
    return roi if roi is not None and roi.size else None


def _profile_peek(values: np.ndarray, start: int, end: int) -> float:
    if end <= start:
        return 0.0
    segment = values[start:end]
    if segment.size == 0:
        return 0.0
    return float(np.max(segment))


def _vertical_cleanup_mask(
    mask: np.ndarray,
    config: Optional[dict[str, Any]] = None,
    *,
    close_y: Optional[int] = None,
    open_k: Optional[int] = None,
    min_area_ratio: Optional[float] = None,
) -> np.ndarray:
    cfg = _cfg(config)
    if mask is None or getattr(mask, "size", 0) == 0:
        return np.zeros((1, 1), dtype=np.uint8)

    work = (mask > 0).astype(np.uint8) * 255
    close_h = max(3, int(close_y if close_y is not None else cfg["vertical_mask_close_kernel_y"]))
    open_size = max(1, int(open_k if open_k is not None else cfg["vertical_mask_open_kernel"]))
    work = cv2.morphologyEx(
        work,
        cv2.MORPH_CLOSE,
        cv2.getStructuringElement(cv2.MORPH_RECT, (3, close_h)),
        iterations=1,
    )
    work = cv2.morphologyEx(
        work,
        cv2.MORPH_OPEN,
        cv2.getStructuringElement(cv2.MORPH_RECT, (open_size, open_size)),
        iterations=1,
    )

    h, w = work.shape[:2]
    area_ratio = float(min_area_ratio if min_area_ratio is not None else cfg["vertical_mask_min_component_area_ratio"])
    min_area = max(8, int(round(h * w * area_ratio)))
    num, labels, stats, _centroids = cv2.connectedComponentsWithStats(work, 8)
    cleaned = np.zeros_like(work)
    for idx in range(1, num):
        area = int(stats[idx, cv2.CC_STAT_AREA])
        if area < min_area:
            continue
        cleaned[labels == idx] = 255
    return cleaned if np.count_nonzero(cleaned) else work


def _vertical_text_whiteness_mask(img, config: Optional[dict[str, Any]] = None) -> np.ndarray:
    if img is None or getattr(img, "size", 0) == 0:
        return np.zeros((1, 1), dtype=np.uint8)

    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    l = cv2.createCLAHE(clipLimit=2.5, tileGridSize=(8, 8)).apply(l)
    local = cv2.subtract(l, cv2.GaussianBlur(l, (0, 0), 9))
    chroma = (
        cv2.absdiff(a, np.full_like(a, 128)).astype(np.float32)
        + cv2.absdiff(b, np.full_like(b, 128)).astype(np.float32)
    ) * 0.5
    score = (l.astype(np.float32) * 0.55) + (local.astype(np.float32) * 2.10) - (0.62 * chroma)
    score = np.clip(score, 0, 255).astype(np.uint8)

    h, w = score.shape[:2]
    x1 = max(0, int(round(w * 0.18)))
    x2 = min(w, max(x1 + 1, int(round(w * 0.82))))
    center = score[:, x1:x2]
    if center is None or center.size == 0:
        return np.zeros_like(score)

    _thr, center_mask = cv2.threshold(center, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    white_ratio = float(np.count_nonzero(center_mask)) / float(max(center_mask.size, 1))
    if white_ratio > 0.72:
        center_mask = 255 - center_mask

    mask = np.zeros_like(score)
    mask[:, x1:x2] = center_mask
    cleaned = _vertical_cleanup_mask(mask, config, close_y=7, open_k=1, min_area_ratio=0.00004)
    num, labels, stats, _centroids = cv2.connectedComponentsWithStats(cleaned, 8)
    filtered = np.zeros_like(cleaned)
    for idx in range(1, num):
        x, y, comp_w, comp_h, area = [int(stats[idx, j]) for j in range(5)]
        density = float(area) / float(max(1, comp_w * comp_h))
        if comp_h >= int(round(h * 0.55)) and comp_w <= int(round(w * 0.17)) and density < 0.72:
            continue
        if comp_h >= int(round(h * 0.88)) and comp_w <= int(round(w * 0.30)) and density < 0.50:
            continue
        filtered[labels == idx] = 255
    return filtered if np.count_nonzero(filtered) else cleaned


def _vertical_bright_lab_mask(img, config: Optional[dict[str, Any]] = None) -> np.ndarray:
    if img is None or getattr(img, "size", 0) == 0:
        return np.zeros((1, 1), dtype=np.uint8)
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    l = cv2.createCLAHE(clipLimit=2.5, tileGridSize=(8, 8)).apply(l)
    chroma = (
        cv2.absdiff(a, np.full_like(a, 128)).astype(np.float32)
        + cv2.absdiff(b, np.full_like(b, 128)).astype(np.float32)
    ) * 0.5
    score = np.clip(l.astype(np.float32) - (0.70 * chroma), 0, 255).astype(np.uint8)
    h, w = score.shape[:2]
    x1 = max(0, int(round(w * 0.12)))
    x2 = min(w, max(x1 + 1, int(round(w * 0.88))))
    center = score[:, x1:x2]
    if center is None or center.size == 0:
        return np.zeros_like(score)
    _thr, center_mask = cv2.threshold(center, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    ratio = float(np.count_nonzero(center_mask)) / float(max(center_mask.size, 1))
    if ratio > 0.78:
        center_mask = 255 - center_mask
    mask = np.zeros_like(score)
    mask[:, x1:x2] = center_mask
    return _vertical_cleanup_mask(mask, config, close_y=9, open_k=1, min_area_ratio=0.00005)


def _vertical_gray_adaptive_mask(img, config: Optional[dict[str, Any]] = None) -> np.ndarray:
    if img is None or getattr(img, "size", 0) == 0:
        return np.zeros((1, 1), dtype=np.uint8)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.createCLAHE(clipLimit=2.4, tileGridSize=(8, 8)).apply(gray)
    blur = cv2.GaussianBlur(gray, (3, 3), 0)
    mask = cv2.adaptiveThreshold(blur, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 41, -7)
    ratio = float(np.count_nonzero(mask)) / float(max(mask.size, 1))
    if ratio > 0.60:
        mask = 255 - mask
    h, w = mask.shape[:2]
    x1 = max(0, int(round(w * 0.16)))
    x2 = min(w, max(x1 + 1, int(round(w * 0.84))))
    centered = np.zeros_like(mask)
    centered[:, x1:x2] = mask[:, x1:x2]
    return _vertical_cleanup_mask(centered, config, close_y=7, open_k=1, min_area_ratio=0.00004)


def _vertical_strict_light_mask(img, config: Optional[dict[str, Any]] = None) -> np.ndarray:
    if img is None or getattr(img, "size", 0) == 0:
        return np.zeros((1, 1), dtype=np.uint8)

    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    l = cv2.createCLAHE(clipLimit=2.5, tileGridSize=(8, 8)).apply(l)
    local = cv2.subtract(l, cv2.GaussianBlur(l, (0, 0), 9))
    chroma = (
        cv2.absdiff(a, np.full_like(a, 128)).astype(np.float32)
        + cv2.absdiff(b, np.full_like(b, 128)).astype(np.float32)
    ) * 0.5
    score = np.clip((l.astype(np.float32) * 0.45) + (local.astype(np.float32) * 2.60) - (0.55 * chroma), 0, 255).astype(np.uint8)

    h, w = score.shape[:2]
    x1 = max(0, int(round(w * 0.08)))
    x2 = min(w, max(x1 + 1, int(round(w * 0.92))))
    center = score[:, x1:x2]
    if center is None or center.size == 0:
        return np.zeros_like(score)

    otsu, _center_mask = cv2.threshold(center, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    threshold = max(float(otsu), float(np.percentile(center, 86)))
    mask = np.zeros_like(score)
    mask[:, x1:x2] = (center >= threshold).astype(np.uint8) * 255
    return mask


def _vertical_legacy_or_mask(img, config: Optional[dict[str, Any]] = None) -> np.ndarray:
    if img is None or getattr(img, "size", 0) == 0:
        return np.zeros((1, 1), dtype=np.uint8)
    base = core._vertical_make_char_mask(img)
    legacy = core._vertical_foreground_mask(img)
    if base is None or getattr(base, "size", 0) == 0:
        return _vertical_cleanup_mask(legacy, config, close_y=5, open_k=2, min_area_ratio=0.00008)
    if legacy is None or getattr(legacy, "size", 0) == 0:
        return _vertical_cleanup_mask(base, config, close_y=5, open_k=2, min_area_ratio=0.00008)
    return _vertical_cleanup_mask(cv2.bitwise_or(base, legacy), config, close_y=5, open_k=2, min_area_ratio=0.00008)


def _vertical_build_symbol_mask(img, config: Optional[dict[str, Any]] = None):
    cfg = _cfg(config)
    text_mask = _vertical_text_whiteness_mask(img, cfg)
    text_ratio = float(np.count_nonzero(text_mask)) / float(max(text_mask.size, 1))
    text_bbox = _vertical_column_bbox_from_mask(text_mask, cfg)
    if text_bbox is not None and 0.004 <= text_ratio <= 0.60:
        return text_mask

    base = core._vertical_make_char_mask(img)
    legacy = core._vertical_foreground_mask(img)
    if base is None or base.size == 0:
        return legacy
    if legacy is None or legacy.size == 0:
        return base

    mask = cv2.bitwise_or(base, legacy)
    return _vertical_cleanup_mask(mask, cfg)


def _vertical_column_bbox_from_mask(mask, config: Optional[dict[str, Any]] = None) -> Optional[Box]:
    if mask is None or mask.size == 0:
        return None

    cfg = _cfg(config)
    work = core._vertical_projection_mask(mask)
    if work is None or work.size == 0:
        return None

    h, w = work.shape[:2]
    col_strength = np.count_nonzero(work, axis=0).astype(np.float32)
    if not np.any(col_strength > 0):
        return None

    col_strength = cv2.GaussianBlur(col_strength.reshape(1, -1), (1, 31), 0).reshape(-1)
    positive_cols = col_strength[col_strength > 0]
    if positive_cols.size == 0:
        return None
    col_threshold = max(2.0, float(np.percentile(positive_cols, 45)) * float(cfg["vertical_column_col_threshold_scale"]))
    xs = np.where(col_strength >= col_threshold)[0]
    if xs.size == 0:
        return None
    x1 = max(0, int(xs.min()))
    x2 = min(w, int(xs.max()) + 1)
    if x2 <= x1:
        return None

    row_strength = np.count_nonzero(work[:, x1:x2], axis=1).astype(np.float32)
    if not np.any(row_strength > 0):
        return None
    row_strength = cv2.GaussianBlur(row_strength.reshape(-1, 1), (1, 11), 0).reshape(-1)
    positive_rows = row_strength[row_strength > 0]
    if positive_rows.size == 0:
        return None
    row_threshold = max(2.0, float(np.percentile(positive_rows, 30)) * float(cfg["vertical_column_row_threshold_scale"]))
    ys = np.where(row_strength >= row_threshold)[0]
    if ys.size == 0:
        return None
    y1 = max(0, int(ys.min()))
    y2 = min(h, int(ys.max()) + 1)
    if y2 <= y1:
        return None
    return x1, y1, x2, y2


def _vertical_estimate_pre_rotation_angle(
    img: np.ndarray,
    base_mask: np.ndarray,
    config: Optional[dict[str, Any]] = None,
) -> tuple[float, list[dict[str, float]]]:
    cfg = _cfg(config)
    min_abs = float(cfg["vertical_min_abs_angle_deg"])
    max_abs = float(cfg["vertical_max_abs_angle_deg"])
    candidates: list[tuple[str, float]] = []

    def _add(name: str, angle: float) -> None:
        if not np.isfinite(angle):
            return
        angle = float(angle)
        candidates.append((name, angle))

    _add("base", float(core._vertical_estimate_column_rotation(base_mask)) if base_mask is not None and base_mask.size else 0.0)
    strict = _vertical_strict_light_mask(img, cfg)
    if strict is not None and strict.size and np.count_nonzero(strict):
        _add("strict_light", float(core._vertical_estimate_column_rotation(strict)))
    gray = _vertical_gray_adaptive_mask(img, cfg)
    if gray is not None and gray.size and np.count_nonzero(gray):
        _add("gray_adaptive", float(core._vertical_estimate_column_rotation(gray)))

    debug = [{"source": name, "angle": round(float(angle), 4)} for name, angle in candidates]

    def _usable(angle: float, *, fallback: bool = False) -> bool:
        abs_angle = abs(float(angle))
        if abs_angle < min_abs or abs_angle > max_abs:
            return False
        # The legacy estimator clamps failed fits at 20 degrees. Treat near-clamp
        # outputs as invalid instead of rotating the crop into a bad position.
        if abs_angle >= 19.0:
            return False
        if fallback and abs_angle > 3.0:
            return False
        return True

    primary = candidates[0][1] if candidates else 0.0
    if _usable(primary):
        return float(primary), debug

    for name, angle in candidates[1:]:
        if name == "strict_light" and _usable(angle, fallback=True):
            return float(angle), debug
    for name, angle in candidates[1:]:
        if name == "gray_adaptive" and _usable(angle, fallback=True):
            return float(angle), debug
    return 0.0, debug


def _vertical_prepare_aligned_column(img, config: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    cfg = _cfg(config)
    result: dict[str, Any] = {
        "aligned_image": img,
        "mask": None,
        "angle": 0.0,
        "column_bbox": None,
        "debug": {},
    }
    if img is None or img.size == 0:
        return result

    work = core._vertical_resize_keep(img, target_h=int(cfg["vertical_target_height"]))
    mask0 = _vertical_build_symbol_mask(work, cfg)
    angle, angle_candidates = _vertical_estimate_pre_rotation_angle(work, mask0, cfg)

    aligned_full = core._vertical_rotate_bound(work, angle) if abs(angle) > 0.01 else work.copy()
    mask1 = _vertical_build_symbol_mask(aligned_full, cfg)
    bbox = _vertical_column_bbox_from_mask(mask1, cfg)
    if bbox is None:
        bbox = core._foreground_bbox_from_mask(mask1, pad=4)
    if bbox is None:
        result["aligned_image"] = aligned_full
        result["mask"] = mask1
        result["angle"] = angle
        result["debug"] = {"reason": "no_bbox", "angle": round(angle, 4), "angle_candidates": angle_candidates}
        return result

    x1, y1, x2, y2 = bbox
    pad_x = max(6, int(round((x2 - x1) * float(cfg["vertical_pad_x_ratio"]))))
    pad_top = max(4, int(round((y2 - y1) * float(cfg["vertical_pad_top_ratio"]))))
    pad_bottom = max(8, int(round((y2 - y1) * float(cfg["vertical_pad_bottom_ratio"]))))
    crop_box = _clip_box((x1 - pad_x, y1 - pad_top, x2 + pad_x, y2 + pad_bottom), aligned_full.shape[1], aligned_full.shape[0])
    if crop_box is None:
        crop_box = bbox
    cx1, cy1, cx2, cy2 = crop_box
    aligned = aligned_full[cy1:cy2, cx1:cx2].copy()
    mask = _vertical_build_symbol_mask(aligned, cfg)

    inner_bbox = _vertical_column_bbox_from_mask(mask, cfg)
    if inner_bbox is not None:
        ix1, iy1, ix2, iy2 = inner_bbox
        inner_pad_x = max(4, int(round((ix2 - ix1) * 0.06)))
        inner_pad_top = max(2, int(round((iy2 - iy1) * 0.02)))
        inner_pad_bottom = max(6, int(round((iy2 - iy1) * 0.06)))
        reclipped = _clip_box((ix1 - inner_pad_x, iy1 - inner_pad_top, ix2 + inner_pad_x, iy2 + inner_pad_bottom), aligned.shape[1], aligned.shape[0])
        if reclipped is not None:
            rx1, ry1, rx2, ry2 = reclipped
            aligned = aligned[ry1:ry2, rx1:rx2].copy()
            mask = _vertical_build_symbol_mask(aligned, cfg)

    result["aligned_image"] = aligned
    result["mask"] = mask
    result["angle"] = angle
    result["column_bbox"] = crop_box
    result["debug"] = {
        "initial_shape": [int(work.shape[0]), int(work.shape[1])],
        "aligned_full_shape": [int(aligned_full.shape[0]), int(aligned_full.shape[1])],
        "final_shape": [int(aligned.shape[0]), int(aligned.shape[1])],
        "initial_bbox": _serialize_box(bbox),
        "crop_bbox": _serialize_box(crop_box),
        "angle": round(angle, 4),
        "angle_candidates": angle_candidates,
    }
    return result


def _vertical_y_projection_profile(aligned_img, mask, config: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    cfg = _cfg(config)
    if mask is None or mask.size == 0:
        return {
            "raw": np.zeros((0,), dtype=np.float32),
            "smooth": np.zeros((0,), dtype=np.float32),
            "threshold": 0.0,
            "expected_h": 0,
            "focus_x": (0, 0),
        }

    h, w = mask.shape[:2]
    x_margin = max(1, int(round(w * float(cfg["vertical_profile_x_margin_ratio"]))))
    x1 = min(max(0, x_margin), max(0, w - 1))
    x2 = max(x1 + 1, w - x_margin)
    focus = mask[:, x1:x2]
    raw = np.count_nonzero(focus, axis=1).astype(np.float32)
    ksize = max(3, int(cfg["vertical_profile_smooth_ksize"]))
    if ksize % 2 == 0:
        ksize += 1
    smooth = cv2.GaussianBlur(raw.reshape(-1, 1), (1, ksize), 0).reshape(-1) if raw.size else raw
    positive = smooth[smooth > 0]
    threshold = 0.0
    if positive.size:
        threshold = max(
            1.0,
            float(np.percentile(positive, 35)) * float(cfg["vertical_profile_threshold_scale"]),
            float(focus.shape[1]) * float(cfg["vertical_profile_width_threshold_scale"]),
        )
    active = np.where(smooth >= max(1.0, threshold * 0.82))[0]
    if active.size:
        span = int(active.max() - active.min() + 1)
    else:
        span = h
    expected_h = max(int(round(h * float(cfg["vertical_min_box_height_ratio"]))), int(round(span / 11.0)))
    return {
        "raw": raw,
        "smooth": smooth,
        "threshold": float(threshold),
        "expected_h": int(expected_h),
        "focus_x": (int(x1), int(x2)),
    }


def _vertical_find_split_candidates(profile: dict[str, Any], config: Optional[dict[str, Any]] = None) -> list[int]:
    cfg = _cfg(config)
    smooth = profile.get("smooth")
    if smooth is None or getattr(smooth, "size", 0) == 0:
        return []

    expected_h = max(8, int(profile.get("expected_h") or 8))
    window = max(3, int(round(expected_h * 0.28)))
    minima: list[int] = []
    for idx in range(window, len(smooth) - window):
        center = float(smooth[idx])
        left = smooth[idx - window:idx]
        right = smooth[idx + 1:idx + 1 + window]
        if left.size == 0 or right.size == 0:
            continue
        if center > float(left.min()) or center > float(right.min()):
            continue
        peak = max(float(left.max()), float(right.max()))
        if peak <= 0.0:
            continue
        depth = (peak - center) / peak
        if depth < float(cfg["vertical_min_valley_depth"]):
            continue
        minima.append(int(idx))
    return minima


def _vertical_snap_boundaries_to_profile(
    boundaries: Sequence[int],
    profile: dict[str, Any],
    config: Optional[dict[str, Any]] = None,
) -> list[int]:
    if len(boundaries) < 2:
        return [int(item) for item in boundaries]

    cfg = _cfg(config)
    smooth_src = profile.get("smooth")
    smooth = np.asarray(smooth_src if smooth_src is not None else np.zeros((0,), dtype=np.float32), dtype=np.float32)
    if smooth.size == 0:
        return [int(item) for item in boundaries]

    ordered = [int(item) for item in boundaries]
    minima = _vertical_find_split_candidates(profile, cfg)
    part_count = max(1, len(ordered) - 1)
    expected_h = max(8, int(profile.get("expected_h") or max(8, (ordered[-1] - ordered[0]) / float(part_count))))
    window = max(14, int(round(expected_h * 0.24)))
    close_limit = max(10, int(round(expected_h * 0.18)))
    min_part_h = max(8, int(round(expected_h * 0.55)))

    snapped = [ordered[0]]
    for idx, target in enumerate(ordered[1:-1], start=1):
        remaining_parts = part_count - idx
        lo_hard = snapped[-1] + min_part_h
        hi_hard = ordered[-1] - (remaining_parts * min_part_h)
        if hi_hard <= lo_hard:
            snapped.append(max(lo_hard, min(target, hi_hard if hi_hard > 0 else target)))
            continue

        base_target = max(lo_hard, min(int(target), hi_hard))
        lo = max(lo_hard, base_target - window)
        hi = min(hi_hard, base_target + window)
        chosen = base_target
        baseline = float(smooth[base_target]) if 0 <= base_target < smooth.size else float("inf")
        candidates = [minimum for minimum in minima if lo <= int(minimum) <= hi]
        if candidates:
            best = min(candidates, key=lambda minimum: (float(smooth[minimum]), abs(int(minimum) - base_target)))
            best_score = float(smooth[best])
            if abs(int(best) - base_target) <= close_limit or best_score <= (baseline * 0.88):
                chosen = int(best)

        chosen = max(lo_hard, min(int(chosen), hi_hard))
        snapped.append(chosen)

    snapped.append(ordered[-1])
    return snapped


def _vertical_bands_from_profile(profile: dict[str, Any], config: Optional[dict[str, Any]] = None) -> list[tuple[int, int]]:
    cfg = _cfg(config)
    smooth = profile.get("smooth")
    if smooth is None or getattr(smooth, "size", 0) == 0:
        return []
    threshold = float(profile.get("threshold") or 0.0)
    expected_h = max(8, int(profile.get("expected_h") or 8))
    min_band_h = max(int(round(expected_h * 0.45)), int(round(len(smooth) * float(cfg["vertical_min_box_height_ratio"]))))
    high_threshold = max(1.0, threshold * 1.18)
    low_threshold = max(1.0, threshold * 0.72)
    max_peak_gap = max(2, int(round(expected_h * 0.18)))
    peak_rows = np.where(smooth >= high_threshold)[0]

    peak_groups: list[tuple[int, int]] = []
    if peak_rows.size:
        start = int(peak_rows[0])
        prev = int(peak_rows[0])
        for raw_idx in peak_rows[1:]:
            idx = int(raw_idx)
            if idx - prev <= max_peak_gap:
                prev = idx
                continue
            peak_groups.append((start, prev + 1))
            start = idx
            prev = idx
        peak_groups.append((start, prev + 1))

    bands: list[tuple[int, int]] = []
    for peak_start, peak_end in peak_groups:
        start = peak_start
        end = peak_end
        while start > 0 and smooth[start - 1] >= low_threshold:
            start -= 1
        while end < len(smooth) and smooth[end] >= low_threshold:
            end += 1
        if (end - start) >= min_band_h:
            bands.append((start, end))

    if not bands:
        active = smooth >= max(1.0, threshold)
        in_band = False
        start = 0
        for idx, is_active in enumerate(active):
            if is_active and not in_band:
                start = idx
                in_band = True
            elif not is_active and in_band:
                if (idx - start) >= min_band_h:
                    bands.append((start, idx))
                in_band = False
        if in_band and (len(active) - start) >= min_band_h:
            bands.append((start, len(active)))

    bands = core._merge_vertical_bands(bands, max_gap=max(1, int(round(expected_h * 0.12))))
    minima = _vertical_find_split_candidates(profile, cfg)
    split_bands: list[tuple[int, int]] = []
    min_split_part_h = max(6, int(round(expected_h * 0.52)))
    min_minima_gap = max(6, int(round(expected_h * 0.55)))

    for start, end in bands:
        height = end - start
        if height < int(round(expected_h * 1.70)):
            split_bands.append((start, end))
            continue

        inner_minima = [
            int(m) for m in minima
            if (start + min_split_part_h) <= int(m) <= (end - min_split_part_h)
        ]
        if not inner_minima:
            split_bands.append((start, end))
            continue

        estimated_parts = max(2, min(int(cfg["vertical_split_max_parts"]), int(round(height / float(max(expected_h, 1))))))
        ranked_minima = sorted(inner_minima, key=lambda m: float(smooth[m]))
        chosen: list[int] = []
        for minimum in ranked_minima:
            if any(abs(minimum - existing) < min_minima_gap for existing in chosen):
                continue
            chosen.append(minimum)
            if len(chosen) >= (estimated_parts - 1):
                break
        chosen.sort()

        boundaries = [start, *chosen, end]
        extra_cuts: list[int] = []
        max_gap_before_fill = max(int(round(expected_h * 1.75)), min_split_part_h * 2)
        fill_window = max(8, int(round(expected_h * 0.42)))
        for left, right in zip(boundaries, boundaries[1:]):
            gap_h = right - left
            if gap_h <= max_gap_before_fill:
                continue
            target_parts = max(2, int(round(gap_h / float(max(expected_h, 1)))))
            for part_idx in range(1, target_parts):
                target = left + int(round((gap_h * part_idx) / float(target_parts)))
                lo = max(left + min_split_part_h, target - fill_window)
                hi = min(right - min_split_part_h, target + fill_window)
                if hi <= lo:
                    continue
                rel = smooth[lo:hi]
                if rel.size == 0:
                    continue
                cut = lo + int(np.argmin(rel))
                if any(abs(cut - existing) < min_minima_gap for existing in [*chosen, *extra_cuts]):
                    continue
                extra_cuts.append(cut)

        if extra_cuts:
            chosen = sorted([*chosen, *extra_cuts])
            if len(chosen) > (estimated_parts - 1):
                chosen = chosen[: estimated_parts - 1]

        if not chosen:
            split_bands.append((start, end))
            continue

        boundaries = [start, *chosen, end]
        valid_parts = True
        for left, right in zip(boundaries, boundaries[1:]):
            if (right - left) < min_split_part_h:
                valid_parts = False
                break
        if not valid_parts:
            split_bands.append((start, end))
            continue
        split_bands.extend((left, right) for left, right in zip(boundaries, boundaries[1:]))

    split_bands = core._merge_vertical_bands(split_bands, max_gap=max(1, int(round(expected_h * 0.08))))
    return split_bands


def _vertical_box_from_band(aligned_img, mask, band: tuple[int, int], config: Optional[dict[str, Any]] = None) -> Optional[Box]:
    cfg = _cfg(config)
    if mask is None or mask.size == 0:
        return None
    h, w = mask.shape[:2]
    y1, y2 = int(band[0]), int(band[1])
    y1 = max(0, min(h - 1, y1))
    y2 = max(y1 + 1, min(h, y2))
    band_mask = mask[y1:y2, :]
    if band_mask.size == 0:
        return None
    col_strength = np.count_nonzero(band_mask, axis=0)
    xs = np.where(col_strength > 0)[0]
    if xs.size == 0:
        return None
    pad_x = max(3, int(round((xs.max() - xs.min() + 1) * 0.08)))
    x1 = max(0, int(xs.min()) - pad_x)
    x2 = min(w, int(xs.max()) + pad_x + 1)
    pad_y = max(2, int(round((y2 - y1) * 0.08)))
    return _clip_box((x1, y1 - pad_y, x2, y2 + pad_y), w, h)


def _vertical_validate_box(
    aligned_img,
    mask,
    box: Box,
    index: int,
    config: Optional[dict[str, Any]] = None,
    expected_h: Optional[int] = None,
) -> dict[str, Any]:
    cfg = _cfg(config)
    if mask is None or mask.size == 0:
        return {"valid": False, "reason": "empty_mask"}

    h_img, _w_img = mask.shape[:2]
    x1, y1, x2, y2 = box
    roi_mask = mask[y1:y2, x1:x2]
    area = float(max(1, roi_mask.size))
    fg = float(np.count_nonzero(roi_mask))
    height = float(_box_h(box))
    width = float(max(1, _box_w(box)))
    fg_ratio = fg / area
    aspect = height / width
    if expected_h is None or expected_h <= 0:
        expected_h = max(int(round(h_img / 11.0)), 1)

    min_h = max(int(round(h_img * float(cfg["vertical_min_box_height_ratio"]))), int(round(expected_h * 0.45)))
    max_h = min(int(round(h_img * float(cfg["vertical_max_box_height_ratio"]))), int(round(expected_h * 2.2)))
    valid = True
    reason = "ok"
    if height < min_h:
        valid = False
        reason = "too_short"
    elif height > max_h:
        valid = False
        reason = "too_tall"
    elif fg_ratio < float(cfg["vertical_min_foreground_ratio"]):
        valid = False
        reason = "low_foreground"
    elif aspect < 0.7:
        valid = False
        reason = "too_wide"
    elif index == 10 and aspect < 0.55:
        valid = False
        reason = "check_too_wide"

    return {
        "valid": bool(valid),
        "reason": reason,
        "height": int(round(height)),
        "width": int(round(width)),
        "foreground_ratio": float(fg_ratio),
        "aspect": float(aspect),
    }


def _vertical_split_merged_box(
    aligned_img,
    mask,
    profile: dict[str, Any],
    box: Box,
    config: Optional[dict[str, Any]] = None,
    expected_h: Optional[int] = None,
) -> list[Box]:
    cfg = _cfg(config)
    if expected_h is None or expected_h <= 0:
        expected_h = max(8, int(profile.get("expected_h") or 8))
    height = _box_h(box)
    if height < int(round(expected_h * float(cfg["vertical_split_min_height_factor"]))):
        return [box]

    smooth = profile.get("smooth")
    if smooth is None or getattr(smooth, "size", 0) == 0:
        return [box]

    y1, y2 = int(box[1]), int(box[3])
    local = smooth[y1:y2]
    if getattr(local, "size", 0) < max(6, expected_h):
        return [box]

    approx_parts = max(2, int(round(height / float(max(expected_h, 1)))))
    if height < (expected_h * 2.6):
        parts = 2
    elif height >= (expected_h * 5.0):
        parts = max(3, min(int(cfg["vertical_split_max_parts"]), approx_parts))
    else:
        parts = max(2, min(max(4, int(cfg["vertical_split_max_parts"])), approx_parts))
    min_part_h = max(6, int(round(expected_h * 0.45)))
    boundaries = [0]
    min_valley_depth = float(cfg["vertical_min_valley_depth"])

    for part_idx in range(1, parts):
        target = int(round((len(local) * part_idx) / float(parts)))
        window = max(4, int(round(expected_h * 0.45)))
        lo = max(boundaries[-1] + min_part_h, target - window)
        hi = min(len(local) - ((parts - part_idx) * min_part_h), target + window)
        if hi <= lo:
            return [box]
        rel = local[lo:hi]
        if rel.size == 0:
            return [box]
        cut = lo + int(np.argmin(rel))
        left_peak = _profile_peek(local, max(0, cut - window), cut)
        right_peak = _profile_peek(local, cut + 1, min(len(local), cut + 1 + window))
        peak = max(left_peak, right_peak)
        valley = float(local[cut])
        if peak <= 0.0:
            return [box]
        depth = (peak - valley) / peak
        if depth < min_valley_depth:
            if height < (expected_h * 2.0):
                return [box]
            soft_window = max(window, int(round(expected_h * 0.65)))
            soft_lo = max(boundaries[-1] + min_part_h, target - soft_window)
            soft_hi = min(len(local) - ((parts - part_idx) * min_part_h), target + soft_window)
            if soft_hi <= soft_lo:
                return [box]
            soft_rel = local[soft_lo:soft_hi]
            if soft_rel.size == 0:
                return [box]
            cut = soft_lo + int(np.argmin(soft_rel))
        boundaries.append(cut)

    boundaries.append(len(local))
    out: list[Box] = []
    for local_y1, local_y2 in zip(boundaries, boundaries[1:]):
        if (local_y2 - local_y1) < min_part_h:
            return [box]
        child = _vertical_box_from_band(aligned_img, mask, (y1 + local_y1, y1 + local_y2), cfg)
        if child is None:
            return [box]
        out.append(child)
    return out if len(out) > 1 else [box]


def _vertical_drop_empty_boxes(
    aligned_img,
    mask,
    boxes: Sequence[Box],
    config: Optional[dict[str, Any]] = None,
    expected_h: Optional[int] = None,
) -> list[Box]:
    cfg = _cfg(config)
    kept: list[Box] = []
    for index, box in enumerate(sorted(boxes, key=lambda item: item[1])):
        meta = _vertical_validate_box(aligned_img, mask, box, index, cfg, expected_h=expected_h)
        fg_ratio = float(meta.get("foreground_ratio", 0.0))
        box_h = _box_h(box)
        drop_low_fg = fg_ratio < float(cfg["vertical_empty_box_foreground_ratio"])
        if fg_ratio <= max(0.002, float(cfg["vertical_empty_box_foreground_ratio"]) * 0.25):
            continue
        # After force-splitting a tall merged band, some valid skinny digits can have
        # weak fill ratio. Drop only windows that are both weak and too short.
        if drop_low_fg and box_h < int(round(max(expected_h or 1, 1) * 0.82)):
            continue
        if meta.get("reason") == "too_short" and len(boxes) > int(cfg["vertical_keep_min_boxes"]):
            continue
        kept.append(box)
    return kept


def _vertical_normalize_box_gaps(boxes: Sequence[Box], config: Optional[dict[str, Any]] = None) -> list[Box]:
    if not boxes:
        return []
    ordered = [tuple(map(int, box)) for box in sorted(boxes, key=lambda item: item[1])]
    out: list[Box] = [ordered[0]]
    for current in ordered[1:]:
        prev = out[-1]
        if prev[3] > current[1]:
            mid = int(round((prev[3] + current[1]) / 2.0))
            prev = (prev[0], prev[1], prev[2], max(prev[1] + 1, mid))
            current = (current[0], min(current[3] - 1, max(mid, current[1])), current[2], current[3])
            out[-1] = prev
        out.append(current)
    return out


def _vertical_refine_box_boundaries(
    boxes: Sequence[Box],
    profile: dict[str, Any],
    *,
    expected_h: int,
) -> list[Box]:
    if not boxes:
        return []
    smooth_src = profile.get("smooth")
    smooth = np.asarray(smooth_src if smooth_src is not None else np.zeros((0,), dtype=np.float32), dtype=np.float32)
    if smooth.size == 0:
        return list(sorted(boxes, key=lambda item: item[1]))

    ordered = [tuple(map(int, box)) for box in sorted(boxes, key=lambda item: item[1])]
    out: list[Box] = [ordered[0]]
    min_part_h = max(8, int(round(expected_h * 0.58)))
    search_window = max(12, int(round(expected_h * 0.32)))

    for current in ordered[1:]:
        prev = out[-1]
        left_h = _box_h(prev)
        right_h = _box_h(current)
        boundary = int(round((prev[3] + current[1]) / 2.0))
        lo = max(prev[1] + min_part_h, current[1] - search_window, boundary - search_window)
        hi = min(current[3] - min_part_h, prev[3] + search_window, boundary + search_window)
        if hi > lo:
            rel = smooth[lo:hi]
            if rel.size:
                cut = lo + int(np.argmin(rel))
                if (cut - prev[1]) >= min_part_h and (current[3] - cut) >= min_part_h:
                    prev = (prev[0], prev[1], prev[2], cut)
                    current = (current[0], cut, current[2], current[3])
                    out[-1] = prev

        # If one side is still much taller than expected, bias the boundary toward balancing both heights.
        left_h = _box_h(prev)
        right_h = _box_h(current)
        if max(left_h, right_h) > int(round(expected_h * 1.35)):
            target = prev[1] + int(round((left_h + right_h) * 0.5))
            lo = max(prev[1] + min_part_h, target - search_window)
            hi = min(current[3] - min_part_h, target + search_window)
            if hi > lo:
                rel = smooth[lo:hi]
                if rel.size:
                    cut = lo + int(np.argmin(rel))
                    if (cut - prev[1]) >= min_part_h and (current[3] - cut) >= min_part_h:
                        prev = (prev[0], prev[1], prev[2], cut)
                        current = (current[0], cut, current[2], current[3])
                        out[-1] = prev

        out.append(current)

    return out


def _vertical_align_group_x(
    boxes: Sequence[Box],
    *,
    start_idx: int,
    count: int,
) -> list[Box]:
    ordered = [tuple(map(int, box)) for box in sorted(boxes, key=lambda item: item[1])]
    if len(ordered) < (start_idx + count):
        return ordered
    group = ordered[start_idx:start_idx + count]
    gx1 = min(box[0] for box in group)
    gx2 = max(box[2] for box in group)
    aligned = [*ordered]
    for idx in range(start_idx, start_idx + count):
        box = aligned[idx]
        aligned[idx] = (gx1, box[1], gx2, box[3])
    return aligned


def _vertical_expand_group_x(
    aligned_img,
    boxes: Sequence[Box],
    *,
    start_idx: int,
    count: int,
) -> list[Box]:
    ordered = [tuple(map(int, box)) for box in sorted(boxes, key=lambda item: item[1])]
    if len(ordered) < (start_idx + count) or aligned_img is None or getattr(aligned_img, "size", 0) == 0:
        return ordered
    _h, w = aligned_img.shape[:2]
    group = ordered[start_idx:start_idx + count]
    gx1 = min(box[0] for box in group)
    gx2 = max(box[2] for box in group)
    pad = max(8, int(round(w * 0.18)))
    expanded = _clip_box((gx1 - pad, group[0][1], gx2 + pad, group[-1][3]), w, aligned_img.shape[0])
    if expanded is None:
        return ordered
    x1, _y1, x2, _y2 = expanded
    out = [*ordered]
    for idx in range(start_idx, start_idx + count):
        box = out[idx]
        out[idx] = (x1, box[1], x2, box[3])
    return out


def _vertical_expand_check_box_x(aligned_img, boxes: Sequence[Box]) -> list[Box]:
    ordered = [tuple(map(int, box)) for box in sorted(boxes, key=lambda item: item[1])]
    if len(ordered) < 11 or aligned_img is None or getattr(aligned_img, "size", 0) == 0:
        return ordered
    h, w = aligned_img.shape[:2]
    prev = ordered[9]
    last = ordered[10]
    pad = max(8, int(round(w * 0.18)))
    pad_top = max(14, int(round(_box_h(last) * 0.34)), int(round(h * 0.025)))
    candidate_y1 = max(0, int(last[1]) - pad_top)
    heights = np.asarray([_box_h(box) for box in ordered[:10]], dtype=np.float32)
    typical_h = float(np.median(heights)) if heights.size else float(_box_h(prev))
    min_prev_h = max(20, int(round(typical_h * 0.79)))

    check_y1 = int(last[1])
    if candidate_y1 < int(last[1]) and (candidate_y1 - int(prev[1])) >= min_prev_h:
        strict = _vertical_strict_light_mask(aligned_img)
        if strict is not None and strict.size:
            x1 = max(0, int(round(w * 0.08)))
            x2 = min(w, max(x1 + 1, int(round(w * 0.92))))
            row = np.count_nonzero(strict[:, x1:x2], axis=1).astype(np.float32)
            if row.size:
                row = cv2.GaussianBlur(row.reshape(-1, 1), (1, 9), 0).reshape(-1)
                local = row[max(0, candidate_y1 - 10):min(h, candidate_y1 + 11)]
                original = float(row[min(max(0, int(last[1])), h - 1)])
                candidate = float(row[min(max(0, candidate_y1), h - 1)])
                local_min = float(np.min(local)) if local.size else candidate
                if local_min <= max(2.0, original * 0.55):
                    check_y1 = candidate_y1
    if check_y1 < int(prev[3]):
        ordered[9] = (prev[0], prev[1], prev[2], check_y1)
    else:
        check_y1 = int(prev[3])

    expanded = _clip_box((last[0] - pad, check_y1, last[2] + pad, last[3]), w, h)
    if expanded is None:
        return ordered
    ordered[10] = expanded
    return ordered


def _vertical_refine_tail_number_boundaries(aligned_img, boxes: Sequence[Box]) -> list[Box]:
    ordered = [tuple(map(int, box)) for box in sorted(boxes, key=lambda item: item[1])]
    if len(ordered) != 11 or aligned_img is None or getattr(aligned_img, "size", 0) == 0:
        return ordered

    h, w = aligned_img.shape[:2]
    tail_start_idx = 6
    tail_start = int(ordered[tail_start_idx][1])
    check_start = int(ordered[10][1])
    if check_start <= tail_start:
        return ordered

    count = 4
    span = check_start - tail_start
    expected_h = max(24, int(round(span / float(count))))
    min_h = max(20, int(round(expected_h * 0.72)))

    strict = _vertical_strict_light_mask(aligned_img)
    if strict is None or getattr(strict, "size", 0) == 0 or np.count_nonzero(strict) == 0:
        return ordered

    x1 = max(0, int(round(w * 0.08)))
    x2 = min(w, max(x1 + 1, int(round(w * 0.92))))
    row = np.count_nonzero(strict[:, x1:x2], axis=1).astype(np.float32)
    if row.size == 0:
        return ordered
    row = cv2.GaussianBlur(row.reshape(-1, 1), (1, 9), 0).reshape(-1)

    boundaries = [tail_start]
    search_window = max(18, int(round(expected_h * 0.33)))
    for idx in range(1, count):
        target = tail_start + int(round((span * idx) / float(count)))
        lo = max(boundaries[-1] + min_h, target - search_window)
        hi = min(check_start - ((count - idx) * min_h), target + search_window)
        if hi <= lo:
            return ordered
        rel = row[lo:hi]
        if rel.size == 0:
            return ordered
        cut = lo + int(np.argmin(rel))
        current_cut = int(ordered[tail_start_idx + idx - 1][3])
        current_value = float(row[min(max(0, current_cut), h - 1)])
        cut_value = float(row[min(max(0, cut), h - 1)])
        # Move only when the new boundary is a materially cleaner separator.
        if cut_value > max(3.0, current_value * 0.75):
            cut = current_cut
        if (cut - boundaries[-1]) < min_h or (check_start - cut) < ((count - idx) * min_h):
            return ordered
        boundaries.append(int(cut))
    boundaries.append(check_start)

    current_internal = [int(ordered[tail_start_idx + idx][3]) for idx in range(count - 1)]
    proposed_internal = boundaries[1:-1]
    moves_are_consistent = all(proposed <= current + 8 for proposed, current in zip(proposed_internal, current_internal))
    has_material_late_boundary = any((current - proposed) >= 20 for proposed, current in zip(proposed_internal, current_internal))
    if not moves_are_consistent or not has_material_late_boundary:
        return ordered

    refined = [*ordered]
    for local_idx in range(count):
        box_idx = tail_start_idx + local_idx
        box = refined[box_idx]
        refined[box_idx] = (box[0], boundaries[local_idx], box[2], boundaries[local_idx + 1])
    return refined


def _vertical_repartition_group(
    boxes: Sequence[Box],
    profile: dict[str, Any],
    *,
    start_idx: int,
    count: int,
    width_mode: str = "union",
) -> list[Box]:
    ordered = [tuple(map(int, box)) for box in sorted(boxes, key=lambda item: item[1])]
    if len(ordered) < (start_idx + count):
        return ordered
    smooth_src = profile.get("smooth")
    smooth = np.asarray(smooth_src if smooth_src is not None else np.zeros((0,), dtype=np.float32), dtype=np.float32)
    if smooth.size == 0:
        return ordered

    group = ordered[start_idx:start_idx + count]
    group_y1 = group[0][1]
    group_y2 = group[-1][3]
    span = group_y2 - group_y1
    if span <= 0:
        return ordered
    expected_h = max(8, int(round(span / float(count))))
    search_window = max(10, int(round(expected_h * 0.32)))
    min_part_h = max(8, int(round(expected_h * 0.60)))
    boundaries = [group_y1]
    for idx in range(1, count):
        target = group_y1 + int(round((span * idx) / float(count)))
        lo = max(boundaries[-1] + min_part_h, target - search_window)
        hi = min(group_y2 - ((count - idx) * min_part_h), target + search_window)
        if hi <= lo:
            cut = target
        else:
            rel = smooth[lo:hi]
            cut = lo + int(np.argmin(rel)) if rel.size else target
        cut = max(boundaries[-1] + min_part_h, cut)
        cut = min(group_y2 - ((count - idx) * min_part_h), cut)
        boundaries.append(cut)
    boundaries.append(group_y2)

    if width_mode == "union":
        gx1 = min(box[0] for box in group)
        gx2 = max(box[2] for box in group)
    out_group: list[Box] = []
    for idx, (y1, y2) in enumerate(zip(boundaries, boundaries[1:])):
        if width_mode == "per-box":
            src = group[idx]
            x1, x2 = src[0], src[2]
        else:
            x1, x2 = gx1, gx2
        out_group.append((x1, y1, x2, y2))

    return [*ordered[:start_idx], *out_group, *ordered[start_idx + count:]]


def _vertical_group_layout_score(
    aligned_img,
    mask,
    boxes: Sequence[Box],
    *,
    start_idx: int,
    count: int,
    config: Optional[dict[str, Any]] = None,
) -> float:
    cfg = _cfg(config)
    ordered = [tuple(map(int, box)) for box in sorted(boxes, key=lambda item: item[1])]
    if len(ordered) < (start_idx + count):
        return -999.0
    group = ordered[start_idx:start_idx + count]
    span = max(1, group[-1][3] - group[0][1])
    expected_h = max(8, int(round(span / float(max(count, 1)))))
    heights = np.asarray([_box_h(box) for box in group], dtype=np.float32)
    valid_count = 0
    weak_count = 0
    tall_count = 0
    for local_idx, box in enumerate(group, start=start_idx):
        meta = _vertical_validate_box(aligned_img, mask, box, local_idx, cfg, expected_h=expected_h)
        if meta.get("valid"):
            valid_count += 1
        if float(meta.get("foreground_ratio", 0.0)) < float(cfg["vertical_empty_box_foreground_ratio"]):
            weak_count += 1
        if float(meta.get("height", _box_h(box))) > (expected_h * 1.35):
            tall_count += 1
    spread = float(np.std(heights) / float(max(expected_h, 1))) if heights.size else 0.0
    return (valid_count * 1.1) - (weak_count * 0.9) - (tall_count * 0.55) - (spread * 1.35)


def _vertical_repartition_group_by_center_signal(
    aligned_img,
    mask,
    boxes: Sequence[Box],
    *,
    start_idx: int,
    count: int,
    config: Optional[dict[str, Any]] = None,
) -> list[Box]:
    ordered = [tuple(map(int, box)) for box in sorted(boxes, key=lambda item: item[1])]
    if len(ordered) < (start_idx + count):
        return ordered
    if aligned_img is None or getattr(aligned_img, "size", 0) == 0 or aligned_img.shape[0] < 800:
        return ordered

    group = ordered[start_idx:start_idx + count]
    group_y1 = int(group[0][1])
    group_y2 = int(group[-1][3])
    group_x1 = int(min(box[0] for box in group))
    group_x2 = int(max(box[2] for box in group))
    span = group_y2 - group_y1
    if span <= 0:
        return ordered

    roi = aligned_img[group_y1:group_y2, group_x1:group_x2]
    if roi is None or roi.size == 0:
        return ordered

    gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
    gray = cv2.createCLAHE(clipLimit=2.2, tileGridSize=(8, 8)).apply(gray)
    w = gray.shape[1]
    cx1 = max(0, int(round(w * 0.25)))
    cx2 = min(w, max(cx1 + 1, int(round(w * 0.75))))
    center = gray[:, cx1:cx2]
    if center is None or center.size == 0:
        return ordered

    _thr, bright = cv2.threshold(center, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    row_strength = np.count_nonzero(bright, axis=1).astype(np.float32)
    if row_strength.size == 0:
        return ordered
    row_strength = cv2.GaussianBlur(row_strength.reshape(-1, 1), (1, 9), 0).reshape(-1)

    expected_h = max(8, int(round(span / float(count))))
    min_h = max(18, int(round(expected_h * 0.45)))
    search_window = max(18, int(round(expected_h * 0.40)))
    boundaries = [0]
    for idx in range(1, count):
        target = int(round((idx * span) / float(count)))
        lo = max(boundaries[-1] + min_h, target - search_window)
        hi = min(span - ((count - idx) * min_h), target + search_window)
        if hi <= lo:
            cut = target
        else:
            rel = row_strength[lo:hi]
            cut = lo + int(np.argmin(rel)) if rel.size else target
        cut = max(boundaries[-1] + min_h, cut)
        cut = min(span - ((count - idx) * min_h), cut)
        boundaries.append(cut)
    boundaries.append(span)

    repartitioned: list[Box] = []
    for local_y1, local_y2 in zip(boundaries, boundaries[1:]):
        band = (group_y1 + int(local_y1), group_y1 + int(local_y2))
        box = _vertical_box_from_band(aligned_img, mask, band, config)
        if box is None:
            return ordered
        repartitioned.append(box)

    candidate = [*ordered[:start_idx], *repartitioned, *ordered[start_idx + count:]]
    old_score = _vertical_group_layout_score(aligned_img, mask, ordered, start_idx=start_idx, count=count, config=config)
    new_score = _vertical_group_layout_score(aligned_img, mask, candidate, start_idx=start_idx, count=count, config=config)
    return candidate if new_score > (old_score + 0.10) else ordered


def _vertical_structure_layout(mask, config: Optional[dict[str, Any]] = None) -> Optional[dict[str, Any]]:
    if mask is None or getattr(mask, "size", 0) == 0:
        return None
    cfg = _cfg(config)
    bbox = _vertical_column_bbox_from_mask(mask, cfg)
    if bbox is None:
        bbox = core._vertical_focus_bbox(mask)
    if bbox is None:
        bbox = core._foreground_bbox_from_mask(core._vertical_projection_mask(mask), pad=4)
    if bbox is None:
        return None

    x1, y1, x2, y2 = bbox
    crop_mask = mask[y1:y2, x1:x2]
    if crop_mask is None or crop_mask.size == 0:
        return None

    crop_h = crop_mask.shape[0]
    min_part_h = max(8, int(crop_h * 0.04))
    row_strength = np.count_nonzero(crop_mask, axis=1).astype(np.float32)
    if row_strength.size:
        row_strength = cv2.GaussianBlur(row_strength.reshape(-1, 1), (1, 9), 0).reshape(-1)

    def _find_cut(
        prev_cut: int,
        target: int,
        remaining_parts: int,
        *,
        lo_limit: int = 0,
        hi_limit: Optional[int] = None,
    ) -> int:
        hi_bound = crop_h if hi_limit is None else min(crop_h, int(hi_limit))
        window = max(8, int(round(crop_h * 0.035)))
        lo = max(prev_cut + min_part_h, lo_limit, target - window)
        hi = min(hi_bound - (remaining_parts * min_part_h), target + window)
        if hi <= lo or row_strength.size == 0:
            cut = target
        else:
            cut = lo + int(np.argmin(row_strength[lo:hi]))
        return max(prev_cut + min_part_h, cut)

    owner_end_target = int(round((4.0 * crop_h) / 11.0))
    check_start_target = int(round((10.0 * crop_h) / 11.0))
    owner_end = _find_cut(0, owner_end_target, 7)
    check_start = _find_cut(owner_end, check_start_target, 1)
    boundaries = [0]
    for idx in range(1, 4):
        target = int(round((idx * owner_end) / 4.0))
        cut = _find_cut(boundaries[-1], target, 4 - idx, hi_limit=owner_end)
        boundaries.append(min(owner_end - ((4 - idx) * min_part_h), cut))
    boundaries.append(owner_end)

    numeric_h = max(1, check_start - owner_end)
    for idx in range(1, 6):
        target = owner_end + int(round((idx * numeric_h) / 6.0))
        cut = _find_cut(boundaries[-1], target, 6 - idx, lo_limit=owner_end, hi_limit=check_start)
        boundaries.append(min(check_start - ((6 - idx) * min_part_h), cut))
    boundaries.append(check_start)
    boundaries.append(crop_h)
    return {
        "bbox": bbox,
        "boundaries": [y1 + int(item) for item in boundaries],
        "row_strength": row_strength,
        "crop_mask": crop_mask,
        "min_part_h": int(min_part_h),
    }


def _vertical_band_density(mask: np.ndarray, start: int, end: int) -> float:
    band = mask[max(0, start):min(mask.shape[0], end), :]
    if band is None or band.size == 0:
        return 0.0
    fg = float(np.count_nonzero(band))
    area = float(max(1, band.shape[0] * band.shape[1]))
    return fg / area


def _vertical_split_band_by_valley(
    row_strength: np.ndarray,
    start: int,
    end: int,
    *,
    min_h: int,
) -> Optional[tuple[tuple[int, int], tuple[int, int]]]:
    length = int(end - start)
    if length < max(min_h * 2, 18):
        return None
    if row_strength is None or getattr(row_strength, "size", 0) == 0:
        return None
    window = max(4, int(round(length * 0.24)))
    lo = start + window
    hi = end - window
    if hi <= lo:
        return None
    cut = lo + int(np.argmin(row_strength[lo:hi]))
    if (cut - start) < min_h or (end - cut) < min_h:
        return None
    return (start, cut), (cut, end)


def _vertical_zone_bands_from_mask(
    zone_img: np.ndarray,
    zone_mask: np.ndarray,
    *,
    threshold_scale: float = 0.58,
    density_threshold: float = 0.012,
) -> tuple[list[tuple[int, int]], np.ndarray, int]:
    zone_h = int(zone_mask.shape[0])
    min_h = max(10, int(zone_h * 0.035))

    def _bands_from_strength(row_strength: np.ndarray, *, percentile: float, scale: float) -> list[tuple[int, int]]:
        nz = row_strength[row_strength > 0]
        if nz.size == 0:
            return []
        threshold = max(1.0, float(np.percentile(nz, percentile)) * scale)
        out: list[tuple[int, int]] = []
        in_band = False
        start = 0
        for idx, value in enumerate(row_strength):
            if value >= threshold and not in_band:
                start = idx
                in_band = True
            elif value < threshold and in_band:
                out.append((start, idx))
                in_band = False
        if in_band:
            out.append((start, zone_h))
        out = core._merge_vertical_bands(out, max_gap=max(1, int(zone_h * 0.012)))
        return [
            band
            for band in out
            if (band[1] - band[0]) >= min_h and _vertical_band_density(zone_mask, band[0], band[1]) >= density_threshold
        ]

    row_strength = np.zeros((zone_h,), dtype=np.float32)
    if zone_img is not None and getattr(zone_img, "size", 0):
        gray = cv2.cvtColor(zone_img, cv2.COLOR_BGR2GRAY)
        gray = cv2.createCLAHE(clipLimit=2.2, tileGridSize=(8, 8)).apply(gray)
        w = gray.shape[1]
        cx1 = max(0, int(round(w * 0.22)))
        cx2 = min(w, max(cx1 + 1, int(round(w * 0.78))))
        center = gray[:, cx1:cx2]
        if center is not None and center.size:
            _, bright = cv2.threshold(center, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            row_strength = np.count_nonzero(bright, axis=1).astype(np.float32)
            if row_strength.size:
                row_strength = cv2.GaussianBlur(row_strength.reshape(-1, 1), (1, 9), 0).reshape(-1)
            bands = _bands_from_strength(row_strength, percentile=35, scale=0.70)
            if bands:
                return bands, row_strength, min_h

    row_strength = np.count_nonzero(zone_mask, axis=1).astype(np.float32)
    if row_strength.size:
        row_strength = cv2.GaussianBlur(row_strength.reshape(-1, 1), (1, 9), 0).reshape(-1)
    bands = _bands_from_strength(row_strength, percentile=30, scale=float(threshold_scale))
    return bands, row_strength, min_h


def _vertical_repair_zone_bands_to_count(
    bands: Sequence[tuple[int, int]],
    row_strength: np.ndarray,
    zone_mask: np.ndarray,
    *,
    target_count: int,
    min_h: int,
) -> tuple[list[tuple[int, int]], list[dict[str, Any]]]:
    work = list(sorted((int(start), int(end)) for start, end in bands))
    repairs: list[dict[str, Any]] = []
    if not work:
        return work, repairs

    heights = [end - start for start, end in work]
    typical = max(min_h, int(np.median(np.asarray(heights, dtype=np.float32)))) if heights else min_h

    while len(work) < target_count:
        split_idx = max(range(len(work)), key=lambda idx: work[idx][1] - work[idx][0])
        start, end = work[split_idx]
        split = _vertical_split_band_by_valley(row_strength, start, end, min_h=max(min_h, int(round(typical * 0.72))))
        if split is None:
            mid = (start + end) // 2
            if (mid - start) < min_h or (end - mid) < min_h:
                break
            split = ((start, mid), (mid, end))
        work = [*work[:split_idx], split[0], split[1], *work[split_idx + 1 :]]
        repairs.append(
            {
                "action": "zone_split",
                "band": [int(start), int(end)],
                "into": [[int(split[0][0]), int(split[0][1])], [int(split[1][0]), int(split[1][1])]],
            }
        )

    while len(work) > target_count:
        weakest_idx = -1
        weakest_score = None
        for idx, (start, end) in enumerate(work):
            height = end - start
            density = _vertical_band_density(zone_mask, start, end)
            score = height * max(density, 1e-4)
            if weakest_score is None or score < weakest_score:
                weakest_score = score
                weakest_idx = idx
        if weakest_idx >= 0 and (work[weakest_idx][1] - work[weakest_idx][0]) < int(round(typical * 0.65)):
            removed = work.pop(weakest_idx)
            repairs.append({"action": "zone_drop", "band": [int(removed[0]), int(removed[1])]})
            continue
        gaps: list[tuple[int, int]] = []
        for idx in range(len(work) - 1):
            gap = work[idx + 1][0] - work[idx][1]
            gaps.append((int(gap), idx))
        if not gaps:
            break
        _gap, merge_idx = min(gaps, key=lambda item: item[0])
        merged = (work[merge_idx][0], work[merge_idx + 1][1])
        repairs.append(
            {
                "action": "zone_merge",
                "bands": [
                    [int(work[merge_idx][0]), int(work[merge_idx][1])],
                    [int(work[merge_idx + 1][0]), int(work[merge_idx + 1][1])],
                ],
                "into": [int(merged[0]), int(merged[1])],
            }
        )
        work = [*work[:merge_idx], merged, *work[merge_idx + 2 :]]

    return list(sorted(work)), repairs


def _vertical_structured_candidate(
    aligned_img,
    mask,
    config: Optional[dict[str, Any]] = None,
) -> Optional[dict[str, Any]]:
    if aligned_img is None or getattr(aligned_img, "size", 0) == 0 or mask is None or getattr(mask, "size", 0) == 0:
        return None
    cfg = _cfg(config)
    h = int(aligned_img.shape[0])
    if h <= 0:
        return None
    profile = _vertical_y_projection_profile(aligned_img, mask, cfg)
    boundaries = [max(0, min(h, int(round(ratio * h)))) for ratio in _VERTICAL_GLOBAL_BOUNDARY_RATIOS]
    if len(boundaries) != 12:
        return None
    boundaries[0] = max(0, boundaries[0])
    boundaries[-1] = h
    for idx in range(1, len(boundaries)):
        boundaries[idx] = max(boundaries[idx], boundaries[idx - 1] + 4)
    boundaries[-1] = h
    boundaries = _vertical_snap_boundaries_to_profile(boundaries, profile, cfg)

    raw_bands = [(boundaries[idx], boundaries[idx + 1]) for idx in range(11)]
    raw_boxes: list[Box] = []
    for band in raw_bands:
        box = _vertical_box_from_band(aligned_img, mask, band, cfg)
        if box is None:
            box = _clip_box((0, int(band[0]), aligned_img.shape[1], int(band[1])), aligned_img.shape[1], aligned_img.shape[0])
        else:
            box = _clip_box((box[0], int(band[0]), box[2], int(band[1])), aligned_img.shape[1], aligned_img.shape[0])
        if box is not None:
            raw_boxes.append(box)
    if len(raw_boxes) != 11:
        return None

    boxes = _vertical_normalize_box_gaps(raw_boxes, cfg)
    boxes = _vertical_align_group_x(boxes, start_idx=0, count=4)
    boxes = _vertical_align_group_x(boxes, start_idx=4, count=6)
    boxes = _vertical_expand_group_x(aligned_img, boxes, start_idx=0, count=4)
    boxes = _vertical_expand_group_x(aligned_img, boxes, start_idx=4, count=6)
    boxes = _vertical_expand_check_box_x(aligned_img, boxes)
    boxes = _vertical_refine_tail_number_boundaries(aligned_img, boxes)
    score = _vertical_score_segmentation(aligned_img, mask, boxes, profile, cfg) + 2.0
    return {
        "name": "structured_global",
        "profile": profile,
        "minima": _vertical_find_split_candidates(profile, cfg),
        "raw_bands": raw_bands,
        "raw_boxes": raw_boxes,
        "boxes": boxes,
        "repairs": [{"action": "global_structure"}],
        "segmentation_score": score,
    }


def _vertical_prune_boxes(
    aligned_img,
    mask,
    boxes: Sequence[Box],
    expected_h: int,
    config: Optional[dict[str, Any]] = None,
    keep_count: int = 11,
) -> list[Box]:
    scored: list[tuple[float, Box]] = []
    for idx, box in enumerate(boxes):
        meta = _vertical_validate_box(aligned_img, mask, box, idx, config, expected_h=expected_h)
        height = _box_h(box)
        closeness = 1.0 - min(1.0, abs(height - expected_h) / float(max(expected_h, 1)))
        score = float(meta.get("foreground_ratio", 0.0)) * 2.0 + closeness
        if meta.get("valid"):
            score += 0.6
        scored.append((score, box))
    scored.sort(key=lambda item: item[0], reverse=True)
    kept = [box for _score, box in scored[:keep_count]]
    kept.sort(key=lambda item: item[1])
    return kept


def _vertical_insert_missing_boxes(
    aligned_img,
    mask,
    profile: dict[str, Any],
    boxes: Sequence[Box],
    config: Optional[dict[str, Any]] = None,
    expected_h: Optional[int] = None,
) -> list[Box]:
    cfg = _cfg(config)
    if expected_h is None or expected_h <= 0:
        expected_h = max(8, int(profile.get("expected_h") or 8))
    if not boxes or len(boxes) >= 11:
        return list(sorted(boxes, key=lambda item: item[1]))

    smooth = profile.get("smooth")
    threshold = float(profile.get("threshold") or 0.0)
    if smooth is None or getattr(smooth, "size", 0) == 0:
        return list(sorted(boxes, key=lambda item: item[1]))

    ordered = list(sorted(boxes, key=lambda item: item[1]))
    candidates: list[Box] = []
    segments: list[tuple[int, int]] = []
    prev_end = 0
    for box in ordered:
        if box[1] > prev_end:
            segments.append((prev_end, box[1]))
        prev_end = box[3]
    if prev_end < len(smooth):
        segments.append((prev_end, len(smooth)))

    max_gap_h = int(round(expected_h * float(cfg["vertical_max_gap"])))
    for gap_start, gap_end in segments:
        gap_h = gap_end - gap_start
        if gap_h < max_gap_h:
            continue
        local = smooth[gap_start:gap_end]
        active = np.where(local >= max(1.0, threshold * 0.70))[0]
        if active.size == 0:
            continue
        band = (gap_start + int(active.min()), gap_start + int(active.max()) + 1)
        candidate = _vertical_box_from_band(aligned_img, mask, band, cfg)
        if candidate is None:
            continue
        meta = _vertical_validate_box(aligned_img, mask, candidate, 0, cfg, expected_h=expected_h)
        if meta.get("foreground_ratio", 0.0) < float(cfg["vertical_empty_box_foreground_ratio"]):
            continue
        candidates.append(candidate)

    merged = list(ordered)
    for candidate in candidates:
        merged.append(candidate)
        merged = _vertical_normalize_box_gaps(sorted(merged, key=lambda item: item[1]), cfg)
        if len(merged) >= 11:
            break
    return merged


def _vertical_force_split_to_count(
    aligned_img,
    mask,
    profile: dict[str, Any],
    boxes: Sequence[Box],
    target_count: int,
    config: Optional[dict[str, Any]] = None,
) -> tuple[list[Box], list[dict[str, Any]]]:
    cfg = _cfg(config)
    work = list(sorted(boxes, key=lambda item: item[1]))
    repairs: list[dict[str, Any]] = []
    if not work or len(work) >= target_count:
        return work, repairs

    smooth = profile.get("smooth")
    if smooth is None or getattr(smooth, "size", 0) == 0:
        return work, repairs

    expected_h = max(8, int(profile.get("expected_h") or 8))
    min_part_h = max(6, int(round(expected_h * 0.42)))
    while len(work) < target_count:
        split_idx = -1
        split_box: Optional[Box] = None
        split_height = 0
        for idx, box in enumerate(work):
            height = _box_h(box)
            if height > split_height and height >= int(round(expected_h * 1.35)):
                split_idx = idx
                split_box = box
                split_height = height
        if split_box is None or split_idx < 0:
            break

        x1, y1, x2, y2 = split_box
        local = smooth[y1:y2]
        if getattr(local, "size", 0) < (min_part_h * 2):
            break

        target_parts = max(2, int(round(split_height / float(max(expected_h, 1)))))
        target_parts = min(target_parts, 1 + (target_count - len(work) + 1))
        target = int(round(len(local) / float(target_parts)))
        window = max(10, int(round(expected_h * 0.55)))
        lo = max(min_part_h, target - window)
        hi = min(len(local) - min_part_h, target + window)
        if hi <= lo:
            break
        rel = local[lo:hi]
        if rel.size == 0:
            break
        cut = lo + int(np.argmin(rel))
        if cut <= min_part_h or (len(local) - cut) <= min_part_h:
            cut = target
        if cut <= min_part_h or (len(local) - cut) <= min_part_h:
            break

        left_box = _vertical_box_from_band(aligned_img, mask, (y1, y1 + cut), cfg)
        right_box = _vertical_box_from_band(aligned_img, mask, (y1 + cut, y2), cfg)
        if left_box is None or right_box is None:
            break

        work = [*work[:split_idx], left_box, right_box, *work[split_idx + 1 :]]
        work = _vertical_normalize_box_gaps(work, cfg)
        repairs.append(
            {
                "action": "force_split",
                "box": _serialize_box(split_box),
                "into": [_serialize_box(left_box), _serialize_box(right_box)],
            }
        )
    return work, repairs


def _vertical_repair_box_sequence(
    aligned_img,
    mask,
    profile: dict[str, Any],
    boxes: Sequence[Box],
    config: Optional[dict[str, Any]] = None,
) -> tuple[list[Box], list[dict[str, Any]]]:
    cfg = _cfg(config)
    work = list(sorted(boxes, key=lambda item: item[1]))
    repairs: list[dict[str, Any]] = []
    if not work:
        return work, repairs

    profile_expected_h = max(8, int(profile.get("expected_h") or 8))
    for _iteration in range(int(cfg["vertical_repair_max_iterations"])):
        changed = False
        span = max(work[-1][3] - work[0][1], 1)
        expected_h = max(
            profile_expected_h,
            min(int(round(span / 3.0)), int(round(profile_expected_h * 2.2))),
        )

        split_pass: list[Box] = []
        for box in work:
            split = _vertical_split_merged_box(aligned_img, mask, profile, box, cfg, expected_h=expected_h)
            if len(split) > 1:
                repairs.append({"action": "split", "box": _serialize_box(box), "into": [_serialize_box(item) for item in split]})
                changed = True
            split_pass.extend(split)
        work = _vertical_normalize_box_gaps(split_pass, cfg)

        if len(work) < 11:
            inserted = _vertical_insert_missing_boxes(aligned_img, mask, profile, work, cfg, expected_h=expected_h)
            if len(inserted) != len(work):
                changed = True
                repairs.append({"action": "insert_missing", "before": len(work), "after": len(inserted)})
            work = inserted

        if len(work) < 11:
            forced, force_repairs = _vertical_force_split_to_count(aligned_img, mask, profile, work, 11, cfg)
            if len(forced) != len(work):
                changed = True
                repairs.extend(force_repairs)
            work = forced

        # Drop obviously empty windows only after we have tried to recover the full
        # sequence; otherwise we destroy a partly-correct 11-box chain too early.
        if len(work) > 11 or _iteration == int(cfg["vertical_repair_max_iterations"]) - 1:
            filtered = _vertical_drop_empty_boxes(aligned_img, mask, work, cfg, expected_h=expected_h)
            if len(filtered) != len(work):
                changed = True
                repairs.append({"action": "drop_empty", "before": len(work), "after": len(filtered)})
            work = filtered

        if len(work) > 11:
            pruned = _vertical_prune_boxes(aligned_img, mask, work, expected_h, cfg, keep_count=11)
            if len(pruned) != len(work):
                changed = True
                repairs.append({"action": "prune", "before": len(work), "after": len(pruned)})
            work = pruned

        work = _vertical_normalize_box_gaps(work, cfg)
        refined = _vertical_refine_box_boundaries(work, profile, expected_h=expected_h)
        if refined != work:
            changed = True
            repairs.append({"action": "refine_boundaries"})
            work = refined
        if len(work) >= 11:
            grouped = _vertical_repartition_group(work, profile, start_idx=0, count=4, width_mode="union")
            grouped = _vertical_repartition_group(grouped, profile, start_idx=4, count=6, width_mode="union")
            centered_numeric = _vertical_repartition_group_by_center_signal(
                aligned_img,
                mask,
                grouped,
                start_idx=4,
                count=6,
                config=cfg,
            )
            if centered_numeric != grouped:
                changed = True
                repairs.append({"action": "repartition_numeric_center"})
                grouped = centered_numeric
            grouped = _vertical_normalize_box_gaps(grouped, cfg)
            if grouped != work:
                changed = True
                repairs.append({"action": "repartition_groups"})
                work = grouped
        if not changed:
            break
    return work, repairs


def _vertical_boxes_to_rois(aligned_img, boxes: Sequence[Box]) -> list[np.ndarray]:
    rois: list[np.ndarray] = []
    for idx, box in enumerate(sorted(boxes, key=lambda item: item[1])):
        roi = _crop_box(aligned_img, box, pad_x=3, pad_y=(4 if idx == 10 else 3))
        if roi is None or roi.size == 0:
            continue
        if idx == 10:
            rois.append(roi)
            continue
        tight = core._tight_foreground_crop(roi, square_inner=(idx == 10), pad=(6 if idx == 10 else 4))
        if tight is None or tight.size == 0:
            tight = roi
        rois.append(tight)
    return rois


def _boxes_signature(boxes: Sequence[Box]) -> tuple[tuple[int, int, int, int], ...]:
    return tuple(tuple(map(int, box)) for box in sorted(boxes, key=lambda item: item[1]))


def _boxes_nearly_equal(
    left: Sequence[Box],
    right: Sequence[Box],
    *,
    tolerance: int = 10,
) -> bool:
    left_sig = _boxes_signature(left)
    right_sig = _boxes_signature(right)
    if len(left_sig) != len(right_sig):
        return False
    for l_box, r_box in zip(left_sig, right_sig):
        if any(abs(int(a) - int(b)) > tolerance for a, b in zip(l_box, r_box)):
            return False
    return True


def _vertical_score_segmentation(
    aligned_img,
    mask,
    boxes: Sequence[Box],
    profile: dict[str, Any],
    config: Optional[dict[str, Any]] = None,
) -> float:
    if not boxes:
        return -10.0
    cfg = _cfg(config)
    ordered = list(sorted(boxes, key=lambda item: item[1]))
    expected_h = max(8, int(profile.get("expected_h") or 8))
    overlaps = 0.0
    large_gaps = 0.0
    heights: list[float] = []
    fg_ratios: list[float] = []
    valid_count = 0
    invalid_count = 0
    weak_boxes = 0

    for idx, box in enumerate(ordered):
        meta = _vertical_validate_box(aligned_img, mask, box, idx, cfg, expected_h=expected_h)
        if meta.get("valid"):
            valid_count += 1
        else:
            invalid_count += 1
        heights.append(float(meta.get("height", _box_h(box))))
        fg_ratios.append(float(meta.get("foreground_ratio", 0.0)))
        if float(meta.get("foreground_ratio", 0.0)) < float(cfg["vertical_empty_box_foreground_ratio"]):
            weak_boxes += 1
        if idx > 0:
            prev = ordered[idx - 1]
            overlap = max(0, prev[3] - box[1])
            gap = max(0, box[1] - prev[3])
            overlaps += overlap / float(max(expected_h, 1))
            if gap > expected_h * float(cfg["vertical_max_gap"]):
                large_gaps += gap / float(max(expected_h, 1))

    height_var = float(np.std(np.asarray(heights, dtype=np.float32))) / float(max(expected_h, 1)) if heights else 1.0
    mean_fg = float(np.mean(np.asarray(fg_ratios, dtype=np.float32))) if fg_ratios else 0.0
    count_penalty = abs(len(ordered) - 11) * 1.8
    valid_bonus = (valid_count / float(max(len(ordered), 1))) * 3.2
    invalid_penalty = (invalid_count * 0.95) + (weak_boxes * 0.70)
    group_penalty = 0.0
    group_bonus = 0.0
    if len(ordered) >= 11:
        owner_heights = np.asarray([_box_h(box) for box in ordered[:4]], dtype=np.float32)
        numeric_heights = np.asarray([_box_h(box) for box in ordered[4:10]], dtype=np.float32)
        check_meta = _vertical_validate_box(aligned_img, mask, ordered[10], 10, cfg, expected_h=expected_h)
        owner_med = float(np.median(owner_heights)) if owner_heights.size else 0.0
        numeric_med = float(np.median(numeric_heights)) if numeric_heights.size else 0.0
        if owner_med > 0.0:
            group_penalty += float(np.std(owner_heights) / owner_med) * 0.70
        if numeric_med > 0.0:
            group_penalty += float(np.std(numeric_heights) / numeric_med) * 1.00
            tall_numeric = sum(1 for value in numeric_heights if value > (numeric_med * 1.42))
            group_penalty += tall_numeric * 0.45
        if check_meta.get("valid"):
            group_bonus += 0.55
        else:
            group_penalty += 1.10
    score = (
        valid_bonus
        + (mean_fg * 8.0)
        + group_bonus
        - (height_var * 1.8)
        - (overlaps * 1.35)
        - (large_gaps * 1.55)
        - count_penalty
        - invalid_penalty
        - group_penalty
    )
    if len(ordered) == 11:
        score += 1.0
    return float(score)


def _vertical_segment_by_y_profile(aligned_img, mask, config: Optional[dict[str, Any]] = None) -> list[Box]:
    details = _vertical_segment_by_y_profile_details(aligned_img, mask, config=config)
    return list(details.get("boxes") or [])


def _vertical_segment_by_y_profile_details(aligned_img, mask, config: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    profile = _vertical_y_projection_profile(aligned_img, mask, config)
    raw_bands = _vertical_bands_from_profile(profile, config)
    raw_boxes = [box for box in (_vertical_box_from_band(aligned_img, mask, band, config) for band in raw_bands) if box is not None]
    repaired_boxes, repairs = _vertical_repair_box_sequence(aligned_img, mask, profile, raw_boxes, config)
    score = _vertical_score_segmentation(aligned_img, mask, repaired_boxes, profile, config)
    return {
        "profile": profile,
        "minima": _vertical_find_split_candidates(profile, config),
        "raw_bands": raw_bands,
        "raw_boxes": raw_boxes,
        "boxes": repaired_boxes,
        "repairs": repairs,
        "segmentation_score": score,
    }


def _vertical_owner_block_from_boxes(aligned_img, boxes: Sequence[Box]) -> Optional[np.ndarray]:
    if aligned_img is None or aligned_img.size == 0 or len(boxes) < 4:
        return None
    ordered = list(sorted(boxes[:4], key=lambda item: item[1]))
    x1 = min(box[0] for box in ordered)
    y1 = min(box[1] for box in ordered)
    x2 = max(box[2] for box in ordered)
    y2 = max(box[3] for box in ordered)
    median_h = int(np.median(np.asarray([_box_h(box) for box in ordered], dtype=np.float32))) if ordered else 0
    pad_x = max(6, int(round((x2 - x1) * 0.03)))
    pad_top = max(6, int(round(median_h * 0.10)))
    pad_bottom = max(10, int(round(median_h * 0.38)))
    roi = _crop_box(aligned_img, (x1, y1, x2, y2), pad_x=pad_x, pad_y=0)
    if roi is None or roi.size == 0:
        return None
    h, w = aligned_img.shape[:2]
    by1 = max(0, y1 - pad_top)
    by2 = min(h, y2 + pad_bottom)
    bx1 = max(0, x1 - pad_x)
    bx2 = min(w, x2 + pad_x)
    roi = aligned_img[by1:by2, bx1:bx2]
    return roi if roi is not None and roi.size else None


def _vertical_numeric_block_from_boxes(aligned_img, boxes: Sequence[Box]) -> Optional[np.ndarray]:
    if aligned_img is None or aligned_img.size == 0 or len(boxes) < 10:
        return None
    ordered = list(sorted(boxes, key=lambda item: item[1]))
    numeric_boxes = ordered[4:10]
    if len(numeric_boxes) < 6:
        return None
    x1 = min(box[0] for box in numeric_boxes)
    y1 = min(box[1] for box in numeric_boxes)
    x2 = max(box[2] for box in numeric_boxes)
    y2 = max(box[3] for box in numeric_boxes)
    median_h = int(np.median(np.asarray([_box_h(box) for box in numeric_boxes], dtype=np.float32))) if numeric_boxes else 0
    pad_x = max(6, int(round((x2 - x1) * 0.02)))
    pad_top = max(6, int(round(median_h * 0.10)))
    pad_bottom = max(8, int(round(median_h * 0.14)))
    h, w = aligned_img.shape[:2]
    bx1 = max(0, x1 - pad_x)
    bx2 = min(w, x2 + pad_x)
    by1 = max(0, y1 - pad_top)
    by2 = min(h, y2 + pad_bottom)
    roi = aligned_img[by1:by2, bx1:bx2]
    return roi if roi is not None and roi.size else None


def _vertical_read_owner(letter_rois: Sequence[np.ndarray], owner_block, *, allow_strip_rescue: bool = True) -> tuple[str, float, str]:
    owner = ""
    raw = ""
    scores: list[float] = []
    chars: list[str] = []
    for idx, roi in enumerate(letter_rois[:4]):
        ch, score = core._vertical_recognize_char_roi(roi, idx)
        ch = core.clean(ch)[:1]
        ch = "".join(core._TO_LETTER.get(sym, sym) for sym in ch)
        if ch and ch.isalpha():
            chars.append(ch)
            scores.append(float(score))
        else:
            break
    if len(chars) == 4:
        raw = "".join(chars)
        owner = core._force_owner_category_u(raw)
        charwise_score = float(np.mean(np.asarray(scores, dtype=np.float32))) if scores else -1.0
    else:
        charwise_score = -1.0

    best_owner, best_score, best_raw = core._best_vertical_owner_from_rois(list(letter_rois[:4]), owner_block=owner_block)
    if best_owner and best_score > charwise_score:
        owner = best_owner
        raw = best_raw
        charwise_score = float(best_score)

    if allow_strip_rescue:
        strip = core._compose_symbol_strip(list(letter_rois[:4]), target_h=44, gap=5, outer_pad=5)
        if strip is not None and strip.size:
            pairs = core._collect_vertical_strip_pairs(strip, phase_bonus=0.02, profile="light")
            strip_owner, strip_score, strip_raw = core._best_owner_code_from_pairs(pairs)
            if strip_owner and strip_score > charwise_score:
                owner = strip_owner
                raw = strip_raw
                charwise_score = float(strip_score)

    if len(owner) == 4:
        owner = core._force_owner_category_u(owner)
    return owner, charwise_score, raw


def _vertical_read_base6(base_rois: Sequence[np.ndarray], base_block=None, *, allow_strip_rescue: bool = True) -> tuple[str, float, str]:
    digits: list[str] = []
    scores: list[float] = []
    raw_parts: list[str] = []
    for roi in list(base_rois[:6]):
        digit, score = core._read_digit_from_roi(roi, square_bias=False)
        digit = "".join(core._TO_DIGIT.get(sym, sym) for sym in core.clean(digit)[:1])
        raw_parts.append(digit)
        if digit and digit.isdigit():
            digits.append(digit)
            scores.append(float(score))
        else:
            break
    base6 = "".join(digits) if len(digits) == 6 else ""
    best_score = float(np.mean(np.asarray(scores, dtype=np.float32))) if len(scores) == 6 else -1.0
    best_raw = "".join(raw_parts)

    if allow_strip_rescue:
        for target_h, gap, phase_bonus, profile in ((44, 4, 0.02, "light"), (64, 6, 0.03, "full")):
            strip = core._compose_symbol_strip(list(base_rois[:6]), target_h=target_h, gap=gap, outer_pad=5)
            if strip is None or not strip.size:
                continue
            pairs = core._collect_vertical_strip_pairs(strip, phase_bonus=phase_bonus, profile=profile)
            strip_base6, _strip_check, strip_score, strip_raw = core._best_vertical_numeric_read(pairs)
            if strip_base6 and strip_score > best_score:
                base6 = strip_base6
                best_score = float(strip_score)
                best_raw = strip_raw

        if base_block is not None and getattr(base_block, "size", 0):
            seen_shapes: set[tuple[int, int]] = set()
            candidates: list[Any] = []
            tight = core._tight_foreground_crop(base_block, pad=5)
            if tight is not None and getattr(tight, "size", 0):
                candidates.append(tight)
                inner = core._safe_inner_crop(tight, margin_ratio=0.04)
                if inner is not None and getattr(inner, "size", 0):
                    candidates.append(inner)
            inner_raw = core._safe_inner_crop(base_block, margin_ratio=0.05)
            if inner_raw is not None and getattr(inner_raw, "size", 0):
                candidates.append(inner_raw)
            candidates.append(base_block)
            for candidate in candidates:
                shape = tuple(candidate.shape[:2])
                if shape in seen_shapes:
                    continue
                seen_shapes.add(shape)
                for rotate_code, rotate_bonus in (
                    (cv2.ROTATE_90_COUNTERCLOCKWISE, 0.07),
                    (cv2.ROTATE_90_CLOCKWISE, 0.04),
                ):
                    rotated = cv2.rotate(candidate, rotate_code)
                    for profile, bonus in (("light", 0.05), ("full", 0.03)):
                        pairs = core._collect_strip_pairs(rotated, phase_bonus=rotate_bonus + bonus, profile=profile)
                        block_base6, _block_check, block_score, block_raw = core._best_vertical_numeric_read(pairs)
                        if block_base6 and block_score > best_score:
                            base6 = block_base6
                            best_score = float(block_score)
                            best_raw = block_raw
    return base6, best_score, best_raw


def _vertical_read_check_digit(check_roi) -> tuple[str, float, str]:
    if check_roi is None or getattr(check_roi, "size", 0) == 0:
        return "", -1.0, ""
    digit, score = core._read_digit_from_roi(check_roi, square_bias=True)
    digit = "".join(core._TO_DIGIT.get(sym, sym) for sym in core.clean(digit)[:1])
    if digit and digit.isdigit():
        return digit, float(score), digit
    strip = core._compose_symbol_strip([check_roi], target_h=44, gap=0, outer_pad=7, square_last=True)
    if strip is not None and strip.size:
        strip_digit, strip_score = core._best_digit_from_strip(strip, profile="minimal")
        strip_digit = "".join(core._TO_DIGIT.get(sym, sym) for sym in core.clean(strip_digit)[:1])
        if strip_digit and strip_digit.isdigit():
            return strip_digit, float(strip_score), strip_digit
    return "", -1.0, ""


def _vertical_simple_symbol_rows(aligned_img, boxes: Sequence[Box]) -> list[dict[str, Any]]:
    rois = _vertical_boxes_to_rois(aligned_img, boxes)
    ordered_boxes = list(sorted(boxes, key=lambda item: item[1]))
    rows: list[dict[str, Any]] = []
    for idx, (box, roi) in enumerate(zip(ordered_boxes, rois)):
        if idx <= 3:
            ch, score = core._vertical_recognize_char_roi(roi, idx)
            ch = core.clean(ch)[:1]
            ch = "".join(core._TO_LETTER.get(sym, sym) for sym in ch)
            role = "owner"
        elif idx <= 9:
            ch, score = _vertical_read_simple_digit_roi(roi)
            role = "serial"
        else:
            ch, score = _vertical_read_simple_digit_roi(roi)
            role = "check"
        rows.append(
            {
                "pos": int(idx + 1),
                "role": role,
                "char": ch,
                "score": float(score),
                "source": "roi",
                "box": _serialize_box(box),
            }
        )
    return rows


def _vertical_best_single_digit_from_text(text: str, score: float) -> tuple[str, float, str]:
    mapped = "".join(core._TO_DIGIT.get(ch, ch) for ch in core.clean(text))
    digits = [(idx, ch) for idx, ch in enumerate(mapped) if ch.isdigit()]
    if not digits:
        return "", -1.0, mapped

    pos, digit = digits[0]
    adjusted = float(score) + 0.16
    if len(digits) == 1:
        adjusted += 0.08
    if pos == 0:
        adjusted += 0.08
    if len(mapped) <= 2:
        adjusted += 0.04
    if len(digits) > 1:
        adjusted -= 0.04 * float(len(digits) - 1)
    return digit, adjusted, mapped


def _vertical_read_simple_digit_roi(roi) -> tuple[str, float]:
    if roi is None or getattr(roi, "size", 0) == 0:
        return "", -1.0

    variants: list[Any] = []
    tight = core._tight_foreground_crop(roi, pad=2)
    if tight is not None and getattr(tight, "size", 0):
        variants.append(tight)
    inner = core._safe_inner_crop(roi, margin_ratio=0.04)
    if inner is not None and getattr(inner, "size", 0):
        variants.append(inner)
    variants.append(roi)

    best_digit = ""
    best_score = -1.0
    seen_shapes: set[tuple[int, int]] = set()
    prepared: list[Any] = []
    for variant in variants:
        shape = tuple(variant.shape[:2])
        if shape in seen_shapes:
            continue
        seen_shapes.add(shape)
        prepared.append(variant)
    for text, score in core._run_text_recognition_batch(prepared):
        digit, adjusted, _mapped = _vertical_best_single_digit_from_text(text, score)
        if digit and adjusted > best_score:
            best_digit = digit
            best_score = float(adjusted)
    return best_digit, best_score


def _vertical_simple_base6_from_strip(base_rois: Sequence[np.ndarray]) -> tuple[str, float, str]:
    if len(base_rois) < 6:
        return "", -1.0, ""

    best_base6 = ""
    best_score = -1.0
    best_raw = ""
    for target_h, gap, phase_bonus, profile in (
        (64, 6, 0.02, "full"),
        (92, 8, 0.02, "full"),
        (120, 8, 0.02, "full"),
        (44, 4, 0.02, "light"),
    ):
        strip = core._compose_symbol_strip(list(base_rois[:6]), target_h=target_h, gap=gap, outer_pad=5)
        if strip is None or getattr(strip, "size", 0) == 0:
            continue
        pairs = core._collect_vertical_strip_pairs(strip, phase_bonus=phase_bonus, profile=profile)
        for raw_text, raw_score in pairs:
            mapped = "".join(core._TO_DIGIT.get(ch, ch) for ch in core.clean(raw_text))
            chunks = list(core._DIGIT_CHUNK_RE.findall(mapped))
            exact_chunks = [chunk for chunk in chunks if len(chunk) == 6]
            for chunk in exact_chunks:
                score = float(raw_score) + 0.25
                if score > best_score:
                    best_base6 = chunk
                    best_score = score
                    best_raw = mapped

    if best_base6:
        return best_base6, best_score, best_raw

    for target_h, gap, phase_bonus, profile in (
        (92, 8, 0.0, "full"),
        (64, 6, 0.0, "full"),
    ):
        strip = core._compose_symbol_strip(list(base_rois[:6]), target_h=target_h, gap=gap, outer_pad=5)
        if strip is None or getattr(strip, "size", 0) == 0:
            continue
        pairs = core._collect_vertical_strip_pairs(strip, phase_bonus=phase_bonus, profile=profile)
        for raw_text, raw_score in pairs:
            mapped = "".join(core._TO_DIGIT.get(ch, ch) for ch in core.clean(raw_text))
            for chunk in core._DIGIT_CHUNK_RE.findall(mapped):
                if len(chunk) < 6:
                    continue
                score = float(raw_score)
                if score > best_score:
                    best_base6 = chunk[:6]
                    best_score = score
                    best_raw = mapped
    return best_base6, best_score, best_raw


def _decode_vertical_boxes_simple(
    aligned_img,
    boxes: Sequence[Box],
    *,
    segmentation_score: float,
    segmentation_method: str,
    config: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    cfg = _cfg(config)
    rows = _vertical_simple_symbol_rows(aligned_img, boxes)
    result = _empty_result(STATUS_NOT_FOUND)
    result.update(
        {
            "segmentation_score": float(segmentation_score),
            "segmentation_method": segmentation_method,
            "symbols": rows,
        }
    )
    if len(rows) < 10:
        return result

    rois = _vertical_boxes_to_rois(aligned_img, boxes)
    chars = [str(row.get("char") or "")[:1] for row in rows]
    scores = [float(row.get("score") or -1.0) for row in rows if float(row.get("score") or -1.0) >= 0.0]
    owner = "".join(chars[:4])
    base6 = "".join(chars[4:10])
    if len(base6) != 6 or not base6.isdigit():
        strip_base6, strip_score, strip_raw = _vertical_simple_base6_from_strip(rois[4:10])
        if len(strip_base6) == 6 and strip_base6.isdigit():
            base6 = strip_base6
            for offset, digit in enumerate(strip_base6):
                row_idx = 4 + offset
                if row_idx >= len(rows):
                    break
                rows[row_idx]["char"] = digit
                rows[row_idx]["score"] = float(strip_score)
                rows[row_idx]["source"] = "strip_exact"
                rows[row_idx]["raw"] = strip_raw
            chars = [str(row.get("char") or "")[:1] for row in rows]
            scores = [float(row.get("score") or -1.0) for row in rows if float(row.get("score") or -1.0) >= 0.0]
    check_digit = chars[10] if len(chars) >= 11 else ""
    raw_text = " ".join(part for part in (owner, base6, check_digit) if part).strip()
    result["raw_text"] = raw_text
    result["score"] = (float(np.mean(np.asarray(scores, dtype=np.float32))) if scores else 0.0) + (float(segmentation_score) * 0.35)

    if len(owner) != 4 or not owner.isalpha() or len(base6) != 6 or not base6.isdigit():
        result["status"] = STATUS_RAW_ONLY if raw_text else STATUS_NOT_FOUND
        return result

    base10 = f"{owner}{base6}"
    result["base10"] = base10
    if len(check_digit) == 1 and check_digit.isdigit() and core._is_valid_iso6346(f"{base10}{check_digit}"):
        result["check_digit"] = check_digit
        result["full_code"] = f"{base10}{check_digit}"
        result["status"] = STATUS_FULL_CONFIRMED
        result["is_valid_iso"] = True
        result["check_digit_source"] = "ocr_simple"
        return result

    if bool(cfg["vertical_use_iso_guess_for_check_digit"]):
        guessed = str(core._iso6346_check_digit(base10))
        result["check_digit"] = guessed
        result["full_code"] = f"{base10}{guessed}"
        result["status"] = STATUS_FULL_GUESSED
        result["is_valid_iso"] = True
        result["check_digit_source"] = "iso_guess"
        result["guessed_check_digit"] = True
        if check_digit:
            result["ocr_check_digit"] = check_digit
        if len(rows) >= 11:
            rows[10]["char"] = guessed
            rows[10]["score"] = max(float(rows[10].get("score") or -1.0), 0.0)
            rows[10]["source"] = "iso_guess"
        return result

    result["status"] = STATUS_PARTIAL_10
    result["check_digit_source"] = "none"
    result["is_valid_iso"] = False
    return result


def _vertical_read_base6_from_grid_rois(
    aligned_img,
    config: Optional[dict[str, Any]] = None,
    *,
    allow_strip_rescue: bool = True,
) -> Optional[dict[str, Any]]:
    grid_rois = core._vertical_grid_rois(aligned_img, 11)
    if len(grid_rois) < 10:
        return None
    grid_boxes = _legacy_boxes_from_symbol_rois(aligned_img, grid_rois, config)
    if len(grid_boxes) < 10:
        return None
    ordered_boxes = list(sorted(grid_boxes, key=lambda item: item[1]))
    base_block = _vertical_numeric_block_from_boxes(aligned_img, ordered_boxes)
    base6, base_score, base_raw = _vertical_read_base6(grid_rois[4:10], base_block, allow_strip_rescue=allow_strip_rescue)
    return {
        "base6": base6,
        "base_score": float(base_score),
        "base_raw": base_raw,
    }


def _decode_vertical_boxes(
    aligned_img,
    boxes: Sequence[Box],
    *,
    segmentation_score: float,
    segmentation_method: str,
    config: Optional[dict[str, Any]] = None,
    allow_strip_rescue: bool = True,
) -> dict[str, Any]:
    cfg = _cfg(config)
    rois = _vertical_boxes_to_rois(aligned_img, boxes)
    if len(rois) < 10:
        result = _empty_result(STATUS_NOT_FOUND)
        result["segmentation_score"] = float(segmentation_score)
        result["segmentation_method"] = segmentation_method
        return result

    letter_rois = rois[:4]
    base_rois = rois[4:10]
    check_roi = rois[10] if len(rois) >= 11 else None
    ordered_boxes = list(sorted(boxes, key=lambda item: item[1]))
    owner_block = _vertical_owner_block_from_boxes(aligned_img, ordered_boxes)
    base_block = _vertical_numeric_block_from_boxes(aligned_img, ordered_boxes)

    owner, owner_score, owner_raw = _vertical_read_owner(letter_rois, owner_block, allow_strip_rescue=allow_strip_rescue)
    base6, base_score, base_raw = _vertical_read_base6(base_rois, base_block, allow_strip_rescue=allow_strip_rescue)
    check_digit, check_score, check_raw = _vertical_read_check_digit(check_roi)

    if allow_strip_rescue and len(base6) != 6:
        aux = _vertical_read_base6_from_grid_rois(aligned_img, config, allow_strip_rescue=True)
        if aux is not None:
            aux_base6 = str(aux.get("base6") or "")
            aux_base_score = float(aux.get("base_score") or -1.0)
            aux_base_raw = str(aux.get("base_raw") or "")
            if len(aux_base6) == 6 and (len(base6) != 6 or aux_base_score > (base_score + 0.03)):
                base6 = aux_base6
                base_score = aux_base_score
                base_raw = aux_base_raw

    raw_text = " ".join(part for part in (owner_raw, base_raw, check_raw) if part).strip()
    score = float(max(owner_score, 0.0) + max(base_score, 0.0) + max(check_score, 0.0) + (segmentation_score * 0.35))

    result = _empty_result(STATUS_NOT_FOUND)
    result.update(
        {
            "raw_text": raw_text,
            "score": score,
            "segmentation_score": float(segmentation_score),
            "segmentation_method": segmentation_method,
        }
    )

    if len(owner) != 4 or len(base6) != 6:
        result["status"] = STATUS_RAW_ONLY if raw_text else STATUS_NOT_FOUND
        return result

    base10 = f"{owner}{base6}"
    result["base10"] = base10

    if len(check_digit) == 1 and core._is_valid_iso6346(f"{base10}{check_digit}"):
        result["check_digit"] = check_digit
        result["full_code"] = f"{base10}{check_digit}"
        result["status"] = STATUS_FULL_CONFIRMED
        result["is_valid_iso"] = True
        result["check_digit_source"] = "ocr"
        return result

    if bool(cfg["vertical_use_iso_guess_for_check_digit"]):
        guessed = str(core._iso6346_check_digit(base10))
        result["check_digit"] = guessed
        result["full_code"] = f"{base10}{guessed}"
        result["status"] = STATUS_FULL_GUESSED
        result["is_valid_iso"] = True
        result["check_digit_source"] = "iso_guess"
        result["guessed_check_digit"] = True
        if check_digit:
            result["ocr_check_digit"] = check_digit
        return result

    result["status"] = STATUS_PARTIAL_10
    result["check_digit_source"] = "none"
    result["is_valid_iso"] = False
    return result


def _annotate_boxes(img, boxes: Sequence[Box], *, color_map: Optional[dict[int, tuple[int, int, int]]] = None) -> np.ndarray:
    canvas = core._ensure_bgr(img).copy()
    for idx, box in enumerate(sorted(boxes, key=lambda item: item[1]), start=1):
        color = (0, 200, 0) if idx <= 4 else ((0, 180, 220) if idx <= 10 else (0, 0, 255))
        if color_map and idx in color_map:
            color = color_map[idx]
        x1, y1, x2, y2 = box
        cv2.rectangle(canvas, (x1, y1), (x2 - 1, y2 - 1), color, 2)
        cv2.putText(canvas, str(idx), (x1 + 2, max(14, y1 + 14)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1, cv2.LINE_AA)
    return canvas


def _render_profile_image(profile: dict[str, Any], minima: Sequence[int]) -> np.ndarray:
    smooth_src = profile.get("smooth")
    raw_src = profile.get("raw")
    smooth = np.asarray(smooth_src if smooth_src is not None else np.zeros((0,), dtype=np.float32), dtype=np.float32)
    raw = np.asarray(raw_src if raw_src is not None else np.zeros((0,), dtype=np.float32), dtype=np.float32)
    width = max(240, int(len(smooth))) if smooth.size else 240
    height = 220
    canvas = np.full((height, width, 3), 255, dtype=np.uint8)
    if smooth.size == 0:
        return canvas
    max_v = float(max(np.max(smooth), np.max(raw), 1.0))
    xs = np.linspace(0, width - 1, num=len(smooth)).astype(np.int32)

    def _to_y(value: float) -> int:
        return int(round((1.0 - (value / max_v)) * (height - 20)))

    for idx in range(1, len(smooth)):
        cv2.line(canvas, (xs[idx - 1], _to_y(float(raw[idx - 1]))), (xs[idx], _to_y(float(raw[idx]))), (180, 180, 180), 1)
        cv2.line(canvas, (xs[idx - 1], _to_y(float(smooth[idx - 1]))), (xs[idx], _to_y(float(smooth[idx]))), (40, 70, 200), 2)
    threshold = float(profile.get("threshold") or 0.0)
    ty = _to_y(threshold)
    cv2.line(canvas, (0, ty), (width - 1, ty), (0, 0, 180), 1)
    for item in minima:
        if 0 <= int(item) < len(xs):
            x = int(xs[int(item)])
            cv2.line(canvas, (x, 0), (x, height - 1), (0, 170, 0), 1)
    return canvas


def _vertical_debug_dump(
    prepared: dict[str, Any],
    candidates: Sequence[dict[str, Any]],
    chosen_index: int,
    result: dict[str, Any],
    config: Optional[dict[str, Any]] = None,
) -> str:
    cfg = _cfg(config)
    if not bool(cfg.get("vertical_debug")):
        return ""

    aligned_img = prepared.get("aligned_image")
    if aligned_img is None or getattr(aligned_img, "size", 0) == 0:
        return ""

    debug_root = Path(str(cfg.get("vertical_debug_dir") or "debug_runs"))
    if not debug_root.is_absolute():
        debug_root = Path.cwd() / debug_root
    name = str(cfg.get("vertical_debug_name") or "").strip()
    if not name:
        digest = hashlib.sha1(aligned_img.tobytes()).hexdigest()[:12]
        name = digest
    out_dir = debug_root / name
    out_dir.mkdir(parents=True, exist_ok=True)

    cv2.imwrite(str(out_dir / "aligned.jpg"), aligned_img)
    mask = prepared.get("mask")
    if mask is not None and getattr(mask, "size", 0):
        cv2.imwrite(str(out_dir / "mask.png"), mask)

    summary: dict[str, Any] = {
        "prepared": prepared.get("debug") or {},
        "chosen_index": int(chosen_index),
        "result": {
            "status": str(result.get("status") or ""),
            "full_code": str(result.get("full_code") or ""),
            "base10": str(result.get("base10") or ""),
            "check_digit": str(result.get("check_digit") or ""),
            "check_digit_source": str(result.get("check_digit_source") or ""),
            "segmentation_method": str(result.get("segmentation_method") or ""),
            "segmentation_score": float(result.get("segmentation_score") or 0.0),
        },
        "candidates": [],
    }

    for idx, candidate in enumerate(candidates):
        cand_dir = out_dir / f"candidate_{idx + 1:02d}_{candidate.get('name', 'adaptive')}"
        cand_dir.mkdir(parents=True, exist_ok=True)
        raw_boxes = candidate.get("raw_boxes") or []
        final_boxes = candidate.get("boxes") or []
        cv2.imwrite(str(cand_dir / "raw_boxes.jpg"), _annotate_boxes(aligned_img, raw_boxes))
        cv2.imwrite(str(cand_dir / "final_boxes.jpg"), _annotate_boxes(aligned_img, final_boxes))
        profile_img = _render_profile_image(candidate.get("profile") or {}, candidate.get("minima") or [])
        cv2.imwrite(str(cand_dir / "y_profile.png"), profile_img)
        rois = _vertical_boxes_to_rois(aligned_img, final_boxes)
        for ridx, roi in enumerate(rois, start=1):
            cv2.imwrite(str(cand_dir / f"roi_{ridx:02d}.jpg"), roi)
        summary["candidates"].append(
            {
                "name": str(candidate.get("name") or ""),
                "mask_name": str(candidate.get("mask_name") or ""),
                "segmentation_score": float(candidate.get("segmentation_score") or 0.0),
                "raw_boxes": [_serialize_box(box) for box in raw_boxes],
                "final_boxes": [_serialize_box(box) for box in final_boxes],
                "minima": [int(item) for item in (candidate.get("minima") or [])],
                "repairs": candidate.get("repairs") or [],
            }
        )

    chosen_boxes = candidates[chosen_index].get("boxes") if 0 <= chosen_index < len(candidates) else []
    cv2.imwrite(str(out_dir / "annotated_boxes.jpg"), _annotate_boxes(aligned_img, chosen_boxes or []))
    (out_dir / "metrics.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return str(out_dir)


def _legacy_boxes_from_symbol_rois(aligned_img, rois: Sequence[np.ndarray], config: Optional[dict[str, Any]] = None) -> list[Box]:
    if aligned_img is None or aligned_img.size == 0 or not rois:
        return []
    h, w = aligned_img.shape[:2]
    total_h = h
    start = 0
    boxes: list[Box] = []
    for roi in rois[:11]:
        roi_h = max(1, int(getattr(roi, "shape", [0, 0])[0]))
        end = min(total_h, start + roi_h)
        box = _clip_box((0, start, w, end), w, h)
        if box is not None:
            boxes.append(box)
        start = end
    return boxes


def _build_adaptive_candidates_for_mask(
    aligned_img,
    mask,
    config: Optional[dict[str, Any]] = None,
) -> list[dict[str, Any]]:
    cfg = _cfg(config)
    candidates: list[dict[str, Any]] = []
    seen_signatures: set[tuple[tuple[int, int, int, int], ...]] = set()
    seen_boxes: list[list[Box]] = []
    for idx, scale in enumerate(cfg["vertical_profile_threshold_scales"]):
        local_cfg = dict(cfg)
        local_cfg["vertical_profile_threshold_scale"] = float(cfg["vertical_profile_threshold_scale"]) * float(scale)
        details = _vertical_segment_by_y_profile_details(aligned_img, mask, local_cfg)
        signature = tuple(tuple(_serialize_box(box)) for box in details.get("boxes") or [])
        if signature in seen_signatures:
            continue
        if any(_boxes_nearly_equal(details.get("boxes") or [], prev, tolerance=10) for prev in seen_boxes):
            continue
        seen_signatures.add(signature)
        seen_boxes.append(list(details.get("boxes") or []))
        adaptive_boxes = list(details.get("boxes") or [])
        adaptive_score = float(details.get("segmentation_score") or -999.0)
        if adaptive_boxes and len(adaptive_boxes) < 8:
            adaptive_score -= float(8 - len(adaptive_boxes)) * 0.85
            details["segmentation_score"] = adaptive_score
        details["name"] = f"adaptive_{idx + 1}"
        candidates.append(details)

    structured = _vertical_structured_candidate(aligned_img, mask, cfg)
    if structured is not None:
        signature = tuple(tuple(_serialize_box(box)) for box in structured.get("boxes") or [])
        if signature and signature not in seen_signatures:
            structured_boxes = list(structured.get("boxes") or [])
            structured_score = float(structured.get("segmentation_score") or -999.0)
            if len(structured_boxes) == 11:
                owner_layout = _vertical_group_layout_score(
                    aligned_img,
                    mask,
                    structured_boxes,
                    start_idx=0,
                    count=4,
                    config=cfg,
                )
                numeric_layout = _vertical_group_layout_score(
                    aligned_img,
                    mask,
                    structured_boxes,
                    start_idx=4,
                    count=6,
                    config=cfg,
                )
                structured_score += min(0.50, max(0.0, float(owner_layout)) * 0.45)
                if float(numeric_layout) > 1.50:
                    structured_score += 0.15
                structured["segmentation_score"] = structured_score
            seen_signatures.add(signature)
            seen_boxes.append(list(structured.get("boxes") or []))
            candidates.append(structured)

    legacy_rois = core._extract_vertical_symbol_rois(aligned_img)
    if legacy_rois:
        legacy_boxes = _legacy_boxes_from_symbol_rois(aligned_img, legacy_rois, cfg)
        signature = tuple(tuple(_serialize_box(box)) for box in legacy_boxes)
        if signature and signature not in seen_signatures:
            seen_signatures.add(signature)
            profile = _vertical_y_projection_profile(aligned_img, mask, cfg)
            repaired, repairs = _vertical_repair_box_sequence(aligned_img, mask, profile, legacy_boxes, cfg)
            legacy_score = _vertical_score_segmentation(aligned_img, mask, repaired, profile, cfg) - 4.0
            if any(_boxes_nearly_equal(repaired, prev, tolerance=10) for prev in seen_boxes):
                pass
            else:
                seen_boxes.append(list(repaired))
                candidates.append(
                    {
                        "name": "legacy_symbol_boxes",
                        "profile": profile,
                        "minima": _vertical_find_split_candidates(profile, cfg),
                        "raw_bands": [],
                        "raw_boxes": legacy_boxes,
                        "boxes": repaired,
                        "repairs": repairs,
                        # Legacy ROIs do not preserve the true row positions, so even after
                        # repair this branch should remain a fallback behind structured splits.
                        "segmentation_score": legacy_score,
                    }
                )

    candidates.sort(key=lambda item: float(item.get("segmentation_score") or -999.0), reverse=True)
    return candidates[: max(1, int(cfg["vertical_candidate_limit"]))]


def _vertical_segmentation_mask_variants(
    aligned_img,
    base_mask,
    config: Optional[dict[str, Any]] = None,
) -> list[tuple[str, np.ndarray]]:
    cfg = _cfg(config)
    requested = list(cfg.get("vertical_segmentation_mask_variants") or ["current"])
    variants: list[tuple[str, np.ndarray]] = []
    for name in requested:
        mask: Optional[np.ndarray]
        if name == "current":
            mask = base_mask
        elif name == "bright_lab":
            mask = _vertical_bright_lab_mask(aligned_img, cfg)
        elif name == "gray_adaptive":
            mask = _vertical_gray_adaptive_mask(aligned_img, cfg)
        elif name == "strict_light":
            mask = _vertical_strict_light_mask(aligned_img, cfg)
        elif name == "legacy_or":
            mask = _vertical_legacy_or_mask(aligned_img, cfg)
        else:
            continue
        if mask is None or getattr(mask, "size", 0) == 0 or np.count_nonzero(mask) == 0:
            continue
        if any(existing.shape == mask.shape and np.array_equal(existing, mask) for _existing_name, existing in variants):
            continue
        variants.append((str(name), mask))
    return variants or [("current", base_mask)]


def _vertical_candidate_selection_score(aligned_img, candidate: dict[str, Any]) -> float:
    score = float(candidate.get("segmentation_score") or -999.0)
    if str(candidate.get("name") or "") == "structured_global":
        score += 1.25
    boxes = [tuple(map(int, box)) for box in (candidate.get("boxes") or [])]
    if len(boxes) != 11 or aligned_img is None or getattr(aligned_img, "size", 0) == 0:
        return score - (abs(len(boxes) - 11) * 8.0)

    h, w = aligned_img.shape[:2]
    ordered = sorted(boxes, key=lambda item: item[1])
    expected_boundaries = [max(0, min(h, int(round(ratio * h)))) for ratio in _VERTICAL_GLOBAL_BOUNDARY_RATIOS]
    pred_boundaries = [ordered[0][1], *[box[3] for box in ordered]]
    boundary_mae = sum(abs(int(pred) - int(exp)) for pred, exp in zip(pred_boundaries, expected_boundaries)) / float(len(expected_boundaries))

    heights = np.asarray([max(1, box[3] - box[1]) for box in ordered], dtype=np.float32)
    expected_h = max(8.0, float(np.median(heights)) if heights.size else h / 11.0)
    spread = float(np.std(heights) / max(expected_h, 1.0)) if heights.size else 1.0

    check = ordered[10]
    check_w = max(1, check[2] - check[0])
    check_h = max(1, check[3] - check[1])
    check_aspect = check_h / float(check_w)
    check_bonus = max(0.0, 1.25 - abs(check_aspect - 1.15)) * 0.45
    check_bonus += min(0.35, (check_w / float(max(1, w))) * 0.35)

    return score - (boundary_mae * 0.70) - (spread * 0.85) + check_bonus


def _vertical_boundary_drift(left: Sequence[Box], right: Sequence[Box]) -> float:
    if len(left) != 11 or len(right) != 11:
        return 999.0
    left_ordered = sorted([tuple(map(int, box)) for box in left], key=lambda item: item[1])
    right_ordered = sorted([tuple(map(int, box)) for box in right], key=lambda item: item[1])
    left_boundaries = [left_ordered[0][1], *[box[3] for box in left_ordered]]
    right_boundaries = [right_ordered[0][1], *[box[3] for box in right_ordered]]
    return float(max(abs(a - b) for a, b in zip(left_boundaries, right_boundaries)))


def _build_adaptive_candidates(aligned_img, mask, config: Optional[dict[str, Any]] = None) -> list[dict[str, Any]]:
    cfg = _cfg(config)
    all_candidates: list[dict[str, Any]] = []
    for mask_name, candidate_mask in _vertical_segmentation_mask_variants(aligned_img, mask, cfg):
        for candidate in _build_adaptive_candidates_for_mask(aligned_img, candidate_mask, cfg):
            item = dict(candidate)
            item["mask_name"] = mask_name
            item["selection_score"] = _vertical_candidate_selection_score(aligned_img, item)
            all_candidates.append(item)

    reference_boxes: list[Box] = []
    for candidate in all_candidates:
        if candidate.get("mask_name") == "current" and candidate.get("name") == "structured_global" and len(candidate.get("boxes") or []) == 11:
            reference_boxes = list(candidate.get("boxes") or [])
            break
    if reference_boxes:
        for candidate in all_candidates:
            if candidate.get("mask_name") == "current":
                continue
            drift = _vertical_boundary_drift(reference_boxes, list(candidate.get("boxes") or []))
            candidate["boundary_drift_from_current"] = drift
            candidate["selection_score"] = float(candidate.get("selection_score") or -999.0) - (drift * 0.12)
            if drift > 18.0:
                candidate["selection_score"] = float(candidate.get("selection_score") or -999.0) - ((drift - 18.0) * 0.30)

    all_candidates.sort(key=lambda item: float(item.get("selection_score") or -999.0), reverse=True)
    deduped: list[dict[str, Any]] = []
    seen_boxes: list[list[Box]] = []
    for candidate in all_candidates:
        boxes = list(candidate.get("boxes") or [])
        if any(_boxes_nearly_equal(boxes, prev, tolerance=10) for prev in seen_boxes):
            continue
        seen_boxes.append(boxes)
        deduped.append(candidate)
        if len(deduped) >= max(1, int(cfg["vertical_candidate_limit"])):
            break
    return deduped


def _build_grid_fallback_candidates(aligned_img, mask, config: Optional[dict[str, Any]] = None) -> list[dict[str, Any]]:
    cfg = _cfg(config)
    profile = _vertical_y_projection_profile(aligned_img, mask, cfg)
    out: list[dict[str, Any]] = []
    for parts in (11, 10):
        rois = core._vertical_grid_rois(aligned_img, parts)
        if not rois:
            continue
        boxes = _legacy_boxes_from_symbol_rois(aligned_img, rois, cfg)
        repaired, repairs = _vertical_repair_box_sequence(aligned_img, mask, profile, boxes, cfg)
        out.append(
            {
                "name": f"grid_{parts}",
                "profile": profile,
                "minima": _vertical_find_split_candidates(profile, cfg),
                "raw_bands": [],
                "raw_boxes": boxes,
                "boxes": repaired,
                "repairs": repairs,
                "segmentation_score": _vertical_score_segmentation(aligned_img, mask, repaired, profile, cfg) - (1.4 if parts == 10 else 1.0),
            }
        )
    return out


def _run_vertical_pipeline(
    img,
    *,
    config: Optional[dict[str, Any]] = None,
    allow_grid_fallback: bool = True,
    allow_strip_rescue: bool = True,
    simple_ocr: bool = True,
) -> tuple[dict[str, Any], list[dict[str, Any]], dict[str, Any], int]:
    prepared = _vertical_prepare_aligned_column(img, config)
    aligned_img = prepared.get("aligned_image")
    mask = prepared.get("mask")
    if aligned_img is None or getattr(aligned_img, "size", 0) == 0 or mask is None or getattr(mask, "size", 0) == 0:
        return _empty_result(STATUS_NOT_FOUND), [], prepared, -1

    candidates = _build_adaptive_candidates(aligned_img, mask, config)
    if allow_grid_fallback:
        candidates.extend(_build_grid_fallback_candidates(aligned_img, mask, config))

    best_result = _empty_result(STATUS_NOT_FOUND)
    best_index = -1
    best_rank = _vertical_result_rank(best_result)
    for idx, candidate in enumerate(candidates):
        boxes = list(candidate.get("boxes") or [])
        if len(boxes) < 10:
            continue
        if simple_ocr:
            result = _decode_vertical_boxes_simple(
                aligned_img,
                boxes,
                segmentation_score=float(candidate.get("segmentation_score") or 0.0),
                segmentation_method=str(candidate.get("name") or "adaptive"),
                config=config,
            )
        else:
            result = _decode_vertical_boxes(
                aligned_img,
                boxes,
                segmentation_score=float(candidate.get("segmentation_score") or 0.0),
                segmentation_method=str(candidate.get("name") or "adaptive"),
                config=config,
                allow_strip_rescue=allow_strip_rescue,
            )
        rank = _vertical_result_rank(result)
        if rank > best_rank:
            best_result = result
            best_rank = rank
            best_index = idx
        if result.get("status") == STATUS_FULL_CONFIRMED:
            break

    debug_dir = _vertical_debug_dump(prepared, candidates, best_index, best_result, config)
    if debug_dir:
        best_result = dict(best_result)
        best_result["debug_dir"] = debug_dir
    return best_result, candidates, prepared, best_index


def ocr_vertical_narrow_boxed(img, config=None) -> dict[str, Any]:
    result, _candidates, _prepared, _best_index = _run_vertical_pipeline(
        img,
        config=config,
        allow_grid_fallback=False,
        allow_strip_rescue=False,
        simple_ocr=True,
    )
    return result


def ocr_vertical_container_regions_charwise(img, config=None) -> dict[str, Any]:
    result, _candidates, _prepared, _best_index = _run_vertical_pipeline(
        img,
        config=config,
        allow_grid_fallback=False,
        allow_strip_rescue=False,
        simple_ocr=True,
    )
    return result


def ocr_vertical_container_regions(img, config=None) -> dict[str, Any]:
    result, _candidates, _prepared, _best_index = _run_vertical_pipeline(
        img,
        config=config,
        allow_grid_fallback=False,
        allow_strip_rescue=False,
        simple_ocr=True,
    )
    return result
