from typing import Any, Optional

from . import container_ocr as core
from .container_layout import extract_two_line_rois, extract_split_door_rois


def _empty_result() -> dict[str, Any]:
    return {
        "raw_text": "",
        "base10": "",
        "check_digit": "",
        "full_code": "",
        "score": -1.0,
        "is_valid_iso": False,
        "status": "NOT_FOUND",
    }


def _recover_twoline_check_digit(
    base10: str,
    *,
    check_input,
    bottom_roi,
    existing_digit: str = "",
    existing_score: float = -1.0,
) -> tuple[str, float]:
    if len(base10) != 10:
        return "", -1.0

    iso_digit = str(core._iso6346_check_digit(base10))
    votes: dict[str, float] = {}

    def _add(digit: str, score: float, bonus: float = 0.0) -> None:
        if len(str(digit or "")) != 1:
            return
        val = float(score) + float(bonus)
        if digit not in votes or val > votes[digit]:
            votes[digit] = val

    if len(existing_digit) == 1 and existing_score > -1.0:
        _add(existing_digit, existing_score, 0.02)

    if check_input is not None and getattr(check_input, 'size', 0):
        for profile, bonus in (("minimal", 0.08), ("light", 0.06), ("full", 0.03)):
            digit, score = core._best_digit_from_strip(check_input, profile=profile)
            if digit:
                _add(digit, score, bonus)

    right_digit, right_score = core._read_right_check_digit(bottom_roi)
    if right_digit:
        _add(right_digit, right_score, -0.04)

    if not votes:
        return "", -1.0

    best_digit, best_score = max(votes.items(), key=lambda item: item[1])
    iso_score = votes.get(iso_digit, -1.0)
    if iso_score >= 0.0 and iso_score >= (best_score - 0.10):
        return iso_digit, iso_score
    return best_digit, best_score


def ocr_split_door_container_regions_hard(img, config: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    split = core._extract_split_door_rois_local(img, config=config)
    if not split:
        split = extract_split_door_rois(img, config=config)
    if not split:
        return _empty_result()

    owner, owner_score, owner_raw = core._split_door_owner_read_hard(split["top_left"])
    base6, check_digit, numeric_score, numeric_raw = core._split_door_numeric_read_hard(split["bottom_left"], split["bottom_right"])
    raw_text = " ".join(part for part in (owner_raw, numeric_raw) if part).strip()

    if len(owner) != 4 or len(base6) != 6:
        return {
            "raw_text": raw_text,
            "base10": "",
            "check_digit": check_digit if len(check_digit) == 1 else "",
            "full_code": "",
            "score": -1.0,
            "is_valid_iso": False,
            "status": "RAW_ONLY" if raw_text else "NOT_FOUND",
        }

    base10 = f"{owner}{base6}"
    computed_check_digit = str(core._iso6346_check_digit(base10))
    if not check_digit or not core._is_valid_iso6346(f"{base10}{check_digit}"):
        check_digit = computed_check_digit
    full_code = f"{base10}{check_digit}" if check_digit else base10
    return {
        "raw_text": raw_text,
        "base10": base10,
        "check_digit": check_digit,
        "full_code": full_code,
        "score": float(max(owner_score, 0.0) + max(numeric_score, 0.0)),
        "is_valid_iso": bool(len(full_code) == 11 and core._is_valid_iso6346(full_code)),
        "status": "FULL_11" if len(full_code) == 11 else "PARTIAL_10",
    }


def ocr_split_door_container_regions(img, config: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    split = core._extract_split_door_rois_local(img, config=config)
    if not split:
        split = extract_split_door_rois(img, config=config)
    if not split:
        return _empty_result()

    owner, owner_score, owner_raw = core._split_door_owner_read(split["top_left"])
    base6, check_digit, numeric_score, numeric_raw = core._split_door_numeric_read(
        split["bottom_left"],
        split["bottom_right"],
    )
    raw_text = " ".join(part for part in (owner_raw, numeric_raw) if part).strip()

    if len(owner) == 4 and len(base6) == 6:
        base10 = f"{owner}{base6}"
        computed_check_digit = str(core._iso6346_check_digit(base10))
        if len(check_digit) != 1 or not core._is_valid_iso6346(f"{base10}{check_digit}"):
            check_digit = computed_check_digit
        full_code = f"{base10}{check_digit}" if len(check_digit) == 1 else base10
        is_valid_iso = bool(len(full_code) == 11 and core._is_valid_iso6346(full_code))
        return {
            "raw_text": raw_text,
            "base10": base10,
            "check_digit": check_digit if len(check_digit) == 1 else "",
            "full_code": full_code,
            "score": float(max(owner_score, 0.0) + max(numeric_score, 0.0)),
            "is_valid_iso": is_valid_iso,
            "status": "FULL_11" if len(full_code) == 11 else "PARTIAL_10",
        }

    enable_hard_fallback = bool((config or {}).get("enable_two_lines_hard_fallback", False))
    recognition_mode = str((config or {}).get("recognition_mode", "accurate") or "accurate").strip().lower()
    if recognition_mode == "fast":
        enable_hard_fallback = False
    raw_compact = core.clean(raw_text)
    should_try_hard_fallback = bool(
        enable_hard_fallback
        and ((not raw_compact) or len(raw_compact) < 8 or (max(float(owner_score), float(numeric_score)) < 0.85))
    )
    if should_try_hard_fallback:
        hard = ocr_split_door_container_regions_hard(img, config=config)
        if hard.get("base10"):
            return hard
        if hard.get("raw_text") and len(hard.get("raw_text", "")) > len(raw_text):
            return hard

    return {
        "raw_text": raw_text,
        "base10": "",
        "check_digit": check_digit if len(check_digit) == 1 else "",
        "full_code": "",
        "score": -1.0,
        "is_valid_iso": False,
        "status": "RAW_ONLY" if raw_text else "NOT_FOUND",
    }


def ocr_split_door_4_2_box(img, config: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    cfg = core.SPECIALIZED_OCR_SETTINGS["split_door_4_2_box"]
    runtime_config = dict(config or {})
    recognition_mode = str(runtime_config.get("recognition_mode", "accurate") or "accurate").strip().lower()
    is_fast_mode = recognition_mode == "fast"
    fast_max_stage_ms = float(runtime_config.get("fast_max_stage_ms", 1500.0) or 1500.0)
    fast_max_side = int(runtime_config.get("fast_max_side", 960) or 960)
    runtime_config["enable_two_lines_hard_fallback"] = bool(
        runtime_config.get("enable_two_lines_hard_fallback", cfg["enable_two_lines_hard_fallback"])
    )
    runtime_config["enable_resize_digit_pass"] = bool(
        runtime_config.get("enable_resize_digit_pass", cfg["enable_resize_digit_pass"])
    )
    if is_fast_mode:
        runtime_config["enable_two_lines_hard_fallback"] = False
        runtime_config["enable_resize_digit_pass"] = False

    t_mode_start = core.time.perf_counter()
    work_img = img
    if is_fast_mode and img is not None and img.size:
        h0, w0 = img.shape[:2]
        max_side = max(h0, w0)
        if max_side > fast_max_side:
            scale = fast_max_side / float(max_side)
            new_w = max(32, int(round(w0 * scale)))
            new_h = max(32, int(round(h0 * scale)))
            work_img = core.cv2.resize(img, (new_w, new_h), interpolation=core.cv2.INTER_AREA)

    best_split = ocr_split_door_container_regions(work_img, config=runtime_config)
    best_rank = core._result_structure_rank(
        best_split,
        prefer_full_code_bonus=float(cfg["prefer_full_code_bonus"]),
        prefer_check_digit_bonus=float(cfg["prefer_check_digit_bonus"]),
    )

    if (
        str(best_split.get("status") or "") == "FULL_11"
        and str(best_split.get("base10") or "")
        and len(str(best_split.get("check_digit") or "")) == 1
    ):
        return best_split

    if is_fast_mode:
        elapsed_ms = (core.time.perf_counter() - t_mode_start) * 1000.0
        if elapsed_ms >= fast_max_stage_ms:
            return best_split

        expanded_fast = core._expand_crop(work_img)
        horizontal_fast = core._ocr_horizontal_container_regions(
            expanded_fast,
            enable_resize_digit_pass=False,
            enable_oneline_slow_fallback=False,
        )
        horizontal_rank = core._result_structure_rank(
            horizontal_fast,
            prefer_full_code_bonus=float(cfg["prefer_full_code_bonus"]),
            prefer_check_digit_bonus=float(cfg["prefer_check_digit_bonus"]),
        )
        if horizontal_rank > best_rank:
            return horizontal_fast
        return best_split

    expanded = core._expand_crop(img)
    expanded_split = ocr_split_door_container_regions(expanded, config=runtime_config)
    expanded_rank = core._result_structure_rank(
        expanded_split,
        prefer_full_code_bonus=float(cfg["prefer_full_code_bonus"]),
        prefer_check_digit_bonus=float(cfg["prefer_check_digit_bonus"]),
    )
    if expanded_rank > best_rank:
        best_split = expanded_split
        best_rank = expanded_rank

    if not best_split:
        best_split = _empty_result()
    if best_split.get("base10") or best_split.get("raw_text"):
        return best_split

    return core._ocr_horizontal_container_regions(
        expanded,
        enable_resize_digit_pass=bool(runtime_config.get("enable_resize_digit_pass", False)),
    )


def ocr_twoline_container_regions(img, config: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    if img is None or img.size == 0:
        return _empty_result()

    top_roi, bottom_roi = extract_two_line_rois(img)
    if top_roi is None or bottom_roi is None:
        return ocr_split_door_container_regions(img, config=config)

    top_symbols = core._extract_horizontal_symbol_rois(top_roi)
    bottom_symbols = core._extract_horizontal_symbol_rois(bottom_roi)

    owner_input = (
        core._compose_symbol_strip(top_symbols[:4], target_h=64, gap=10, outer_pad=8)
        if len(top_symbols) >= 4
        else top_roi
    )

    base_symbols = bottom_symbols[:6] if len(bottom_symbols) >= 6 else []
    check_symbol = bottom_symbols[6] if len(bottom_symbols) >= 7 else None
    use_symbol_bottom = len(base_symbols) == 6
    digits6_input = (
        core._compose_symbol_strip(base_symbols, target_h=64, gap=8, outer_pad=8)
        if use_symbol_bottom
        else bottom_roi
    )
    digits7_input = (
        core._compose_symbol_strip(
            base_symbols + ([check_symbol] if check_symbol is not None else []),
            target_h=64,
            gap=8,
            outer_pad=8,
            square_last=(check_symbol is not None),
        )
        if use_symbol_bottom
        else bottom_roi
    )
    check_input = (
        core._compose_symbol_strip([check_symbol], target_h=64, gap=0, outer_pad=10, square_last=True)
        if check_symbol is not None
        else None
    )

    owner = ""
    owner_score = -1.0
    owner_raw = ""
    letter_pairs = core._collect_compact_strip_pairs(owner_input, phase_bonus=0.03, profile="light")
    if letter_pairs:
        owner, owner_score, owner_raw = core._best_owner_code_from_pairs(letter_pairs)

    numeric_candidates: list[dict[str, Any]] = []
    numeric_raw = ""
    for strip, bonus, profile in (
        (digits7_input, 0.06, "light"),
        (digits6_input, 0.04, "light"),
        (bottom_roi, 0.02, "minimal"),
    ):
        pairs = core._collect_compact_strip_pairs(strip, phase_bonus=bonus, profile=profile)
        if pairs and len(" ".join(text for text, _ in pairs)) > len(numeric_raw):
            numeric_raw = " ".join(text for text, _ in pairs).strip()
        numeric_candidates.extend(core._numeric_region_candidates(pairs, phase_bonus=bonus))

    base6, check_digit, numeric_score, numeric_best_raw, _meta = core._pick_best_numeric_candidate(numeric_candidates)
    if numeric_best_raw and len(numeric_best_raw) > len(numeric_raw):
        numeric_raw = numeric_best_raw

    if base6 and not check_digit:
        right_digit = ""
        right_score = -1.0
        if check_input is not None:
            right_digit, right_score = core._best_digit_from_strip(check_input)
        if not right_digit:
            right_digit, right_score = core._read_right_check_digit(bottom_roi)
        if right_digit:
            check_digit = right_digit
            numeric_score = max(numeric_score, right_score)

    raw_text = " ".join(part for part in (owner_raw, numeric_raw) if part).strip()
    if len(owner) != 4 or len(base6) != 6:
        split_door = ocr_split_door_container_regions(img, config=config)
        if split_door.get("base10") or split_door.get("raw_text"):
            return split_door
        return {
            "raw_text": raw_text,
            "base10": "",
            "check_digit": "",
            "full_code": "",
            "score": -1.0,
            "is_valid_iso": False,
            "status": "RAW_ONLY" if raw_text else "NOT_FOUND",
        }

    base10 = f"{owner}{base6}"
    full_code = f"{base10}{check_digit}" if check_digit else base10
    return {
        "raw_text": raw_text,
        "base10": base10,
        "check_digit": check_digit,
        "full_code": full_code,
        "score": float(max(owner_score, 0.0) + max(numeric_score, 0.0)),
        "is_valid_iso": bool(len(full_code) == 11 and core._is_valid_iso6346(full_code)),
        "status": "FULL_11" if len(full_code) == 11 else "PARTIAL_10",
    }
