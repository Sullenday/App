from __future__ import annotations

import html
import importlib.util
import json
import logging
import mimetypes
import os
import re
import socket
import sqlite3
import subprocess
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import requests
from fastapi import FastAPI, File, Form, HTTPException, Query, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, Response
from pydantic import BaseModel, Field

from .. import container_crop_service
from ..config.admin_ui_settings import get_bool, get_int, get_visible_tabs
from ..container_layout import classify_container_layout

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = PROJECT_ROOT / "dashboard_data"
ADMIN_CFG_PATH = DATA_DIR / "admin_service_config.json"
ADMIN_DB_PATH = DATA_DIR / "admin_ui.db"
SERVICE_STDOUT_LOG_PATH = DATA_DIR / "service_stdout.log"
APP_LOG_PATH = PROJECT_ROOT / "app.log"
UI_HTML_PATH = PROJECT_ROOT / "app" / "ui" / "admin_ui_page.html"
TEST_REPORTS_DIR = DATA_DIR / "test_reports"
UI_TABS = ("service", "logs", "debug", "testing", "about")

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}
CONTAINER_RE = re.compile(r"\b[A-Z]{4}\d{7}\b")
RESULT_RE = re.compile(r"RESULT\s*:\s*(.+)$", re.IGNORECASE)
REPORT_FILE_RE = re.compile(r"^run_(\d+)\.html$")
DEFAULT_TEST_TIMEOUT_SEC = 120.0
MAX_TEST_TIMEOUT_SEC = 1800.0

KNOWN_NUMBER_TYPES = ("oneline", "twolines", "vertical")
NUMBER_TYPE_ALIASES = {
    "oneline": "oneline",
    "one_line": "oneline",
    "singleline": "oneline",
    "single_line": "oneline",
    "horizontal": "oneline",
    "gorizontal": "oneline",
    "twoline": "twolines",
    "two_line": "twolines",
    "two_lines": "twolines",
    "twolines": "twolines",
    "doubleline": "twolines",
    "double_line": "twolines",
    "vertical": "vertical",
}
NUMBER_TYPE_HINT_RE = re.compile(r"(?<![a-z])(oneline|one_line|singleline|single_line|horizontal|gorizontal|twoline|two_line|two_lines|twolines|doubleline|double_line|vertical)(?![a-z])")


class ServiceConfig(BaseModel):
    host: str = "127.0.0.1"
    port: int = 8000
    workers: int = Field(default=1, ge=1, le=16)
    debug_visualization: bool = False


class DebugConfigPayload(BaseModel):
    enabled: bool


class TestRunPayload(BaseModel):
    dataset_dir: str
    mode: str = Field(default="container", pattern="^(container|seal)$")
    timeout_sec: float = Field(default=DEFAULT_TEST_TIMEOUT_SEC, ge=1.0, le=MAX_TEST_TIMEOUT_SEC)


class WorkersPayload(BaseModel):
    workers: int = Field(ge=1, le=16)


class CleanupReportsPayload(BaseModel):
    mode: str = Field(default="policy", pattern="^(policy|all)$")
    dry_run: bool = False


app = FastAPI(title="FastService Admin UI")
logger = logging.getLogger("admin_ui")

_managed_lock = threading.Lock()
_managed_process: subprocess.Popen | None = None


def _model_dump(model: BaseModel) -> dict[str, Any]:
    if hasattr(model, "model_dump"):
        return model.model_dump()  # для pydantic 2
    return model.dict()  # для pydantic 1


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _load_config() -> ServiceConfig:
    if not ADMIN_CFG_PATH.exists():
        return ServiceConfig()
    try:
        data = json.loads(ADMIN_CFG_PATH.read_text(encoding="utf-8"))
        return ServiceConfig(**data)
    except Exception:
        return ServiceConfig()


def _save_config(cfg: ServiceConfig) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    ADMIN_CFG_PATH.write_text(json.dumps(_model_dump(cfg), ensure_ascii=False, indent=2), encoding="utf-8")


def _visible_ui_tabs() -> list[str]:
    return get_visible_tabs(UI_TABS)


def _reports_cleanup_settings() -> dict[str, int | bool]:
    enabled = get_bool(
        "testing.reports_cleanup.enabled",
        True,
        env_var="ADMIN_UI_REPORTS_CLEANUP_ENABLED",
    )
    max_age_days = max(
        1,
        get_int(
            "testing.reports_cleanup.max_age_days",
            30,
            env_var="ADMIN_UI_REPORTS_CLEANUP_MAX_AGE_DAYS",
        ),
    )
    keep_last_runs = max(
        0,
        get_int(
            "testing.reports_cleanup.keep_last_runs",
            100,
            env_var="ADMIN_UI_REPORTS_CLEANUP_KEEP_LAST_RUNS",
        ),
    )
    return {
        "enabled": enabled,
        "max_age_days": max_age_days,
        "keep_last_runs": keep_last_runs,
    }


def _load_recent_run_ids(limit: int) -> set[int]:
    if limit <= 0 or not ADMIN_DB_PATH.exists():
        return set()
    try:
        with sqlite3.connect(ADMIN_DB_PATH) as conn:
            rows = conn.execute(
                """
                SELECT id
                FROM test_runs
                ORDER BY id DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
    except sqlite3.Error:
        return set()
    return {int(row[0]) for row in rows}


def _cleanup_test_reports(*, mode: str = "policy", dry_run: bool = False, reason: str = "manual") -> dict[str, Any]:
    settings = _reports_cleanup_settings()
    TEST_REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    files = sorted([p for p in TEST_REPORTS_DIR.glob("run_*.html") if p.is_file()], key=lambda p: p.name)

    if mode == "policy" and not bool(settings["enabled"]) and reason != "manual":
        return {
            "mode": mode,
            "reason": reason,
            "dry_run": dry_run,
            "cleanup_enabled": bool(settings["enabled"]),
            "max_age_days": int(settings["max_age_days"]),
            "keep_last_runs": int(settings["keep_last_runs"]),
            "total_files": len(files),
            "removed_count": 0,
            "removed_files": [],
            "skipped": "auto cleanup disabled",
        }

    keep_ids = _load_recent_run_ids(int(settings["keep_last_runs"])) if mode == "policy" else set()
    cutoff_ts = time.time() - int(settings["max_age_days"]) * 86400
    removable: list[Path] = []

    if mode == "all":
        removable = files
    else:
        for path in files:
            match = REPORT_FILE_RE.match(path.name)
            run_id = int(match.group(1)) if match else None
            if run_id is not None and run_id in keep_ids:
                continue
            try:
                is_old = path.stat().st_mtime < cutoff_ts
            except OSError:
                is_old = False
            if is_old:
                removable.append(path)

    removed_names: list[str] = []
    removed_count = 0
    for path in removable:
        removed_names.append(path.name)
        if dry_run:
            continue
        try:
            path.unlink()
            removed_count += 1
        except OSError:
            continue

    return {
        "mode": mode,
        "reason": reason,
        "dry_run": dry_run,
        "cleanup_enabled": bool(settings["enabled"]),
        "max_age_days": int(settings["max_age_days"]),
        "keep_last_runs": int(settings["keep_last_runs"]),
        "total_files": len(files),
        "candidate_count": len(removable),
        "removed_count": len(removable) if dry_run else removed_count,
        "removed_files": removed_names,
        "kept_recent_run_ids": sorted(keep_ids),
    }


def _testing_report_path(run_id: int) -> Path:
    return TEST_REPORTS_DIR / f"run_{run_id}.html"


def _service_base_url(cfg: ServiceConfig) -> str:
    return f"http://{cfg.host}:{cfg.port}"


def _is_running(proc: subprocess.Popen | None) -> bool:
    return proc is not None and proc.poll() is None


def _can_bind_address(host: str, port: int) -> tuple[bool, str | None]:
    try:
        addr_infos = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
    except OSError as exc:
        return False, str(exc)

    for family, socktype, proto, _canonname, sockaddr in addr_infos:
        s = socket.socket(family, socktype, proto)
        try:
            if os.name == "nt" and hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
                s.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            s.bind(sockaddr)
            return True, None
        except OSError as exc:
            return False, f"[Errno {exc.errno}] {exc.strerror}"
        finally:
            s.close()
    return True, None


def _effective_workers(requested_workers: int) -> int:
    if os.name == "nt" and requested_workers > 1:
        return 1
    return max(1, requested_workers)


def _start_managed_service() -> dict[str, Any]:
    global _managed_process
    cfg = _load_config()
    base_url = _service_base_url(cfg)
    workers_used = _effective_workers(cfg.workers)
    with _managed_lock:
        if _is_running(_managed_process):
            return {"running": True, "pid": _managed_process.pid, "message": "already running"}

        health = _probe_health(base_url)
        if health.get("reachable"):
            return {
                "running": False,
                "message": "service already reachable on configured host/port (likely started outside admin)",
                "base_url": base_url,
                "health": health,
            }

        can_bind, bind_error = _can_bind_address(cfg.host, cfg.port)
        if not can_bind:
            return {
                "running": False,
                "message": "cannot bind configured host/port",
                "base_url": base_url,
                "error": bind_error,
            }

        DATA_DIR.mkdir(parents=True, exist_ok=True)
        log_file = open(SERVICE_STDOUT_LOG_PATH, "a", encoding="utf-8")
        cmd = [
            sys.executable,
            "-m",
            "uvicorn",
            "app.api.main:app",
            "--host",
            cfg.host,
            "--port",
            str(cfg.port),
            "--workers",
            str(workers_used),
        ]
        env = os.environ.copy()
        env["DEBUG_VISUALIZATION_ENABLED"] = "1" if cfg.debug_visualization else "0"
        env.setdefault("LOG_PATH", str(APP_LOG_PATH))
        creationflags = 0
        if os.name == "nt" and hasattr(subprocess, "CREATE_NO_WINDOW"):
            creationflags = subprocess.CREATE_NO_WINDOW

        _managed_process = subprocess.Popen(
            cmd,
            cwd=str(PROJECT_ROOT),
            stdout=log_file,
            stderr=subprocess.STDOUT,
            env=env,
            creationflags=creationflags,
        )
        time.sleep(0.7)
        if not _is_running(_managed_process):
            _managed_process = None
            return {
                "running": False,
                "message": "managed service exited immediately after start",
                "base_url": base_url,
                "log_tail": _tail_lines(SERVICE_STDOUT_LOG_PATH, 40),
                "workers_requested": cfg.workers,
                "workers_used": workers_used,
            }

    response: dict[str, Any] = {
        "running": True,
        "pid": _managed_process.pid,
        "message": "started",
        "workers_requested": cfg.workers,
        "workers_used": workers_used,
    }
    if workers_used != cfg.workers:
        response["note"] = "workers>1 is unstable on Windows for managed mode; started with workers=1"
    return response


def _stop_managed_service() -> dict[str, Any]:
    global _managed_process
    with _managed_lock:
        if not _is_running(_managed_process):
            _managed_process = None
            return {"running": False, "message": "not running"}
        assert _managed_process is not None
        proc = _managed_process
        proc.terminate()
        try:
            proc.wait(timeout=20)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait(timeout=5)
        _managed_process = None
    return {"running": False, "message": "stopped"}


def _restart_managed_service() -> dict[str, Any]:
    _stop_managed_service()
    return _start_managed_service()


def _probe_health(base_url: str, timeout: float = 2.0) -> dict[str, Any]:
    try:
        resp = requests.get(f"{base_url}/health", timeout=timeout)
        return {"reachable": resp.status_code == 200, "status_code": resp.status_code}
    except requests.RequestException as exc:
        return {"reachable": False, "error": str(exc)}


def _tail_lines(path: Path, lines: int) -> str:
    if not path.exists():
        return ""
    text = path.read_text(encoding="utf-8", errors="ignore")
    return "\n".join(text.splitlines()[-lines:])


def _proxy_json(method: str, path: str, payload: dict | None = None) -> dict[str, Any]:
    cfg = _load_config()
    url = f"{_service_base_url(cfg)}{path}"
    try:
        resp = requests.request(method=method, url=url, json=payload, timeout=30)
    except requests.RequestException as exc:
        raise HTTPException(status_code=502, detail=f"Service request failed: {exc}") from exc
    try:
        data = resp.json()
    except ValueError:
        data = {"raw": resp.text}
    if not resp.ok:
        raise HTTPException(status_code=resp.status_code, detail=data)
    return data


def _init_admin_db() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(ADMIN_DB_PATH) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS test_runs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL,
                dataset_dir TEXT NOT NULL,
                mode TEXT NOT NULL,
                timeout_sec REAL NOT NULL,
                labels_available INTEGER NOT NULL,
                text_available INTEGER NOT NULL,
                summary_json TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS test_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id INTEGER NOT NULL,
                file_name TEXT NOT NULL,
                number_type TEXT,
                predicted_text TEXT,
                raw_text TEXT,
                normalized_predicted TEXT,
                expected_label TEXT,
                expected_text TEXT,
                status_code INTEGER,
                elapsed_ms REAL,
                stage_timings_json TEXT,
                error TEXT,
                FOREIGN KEY(run_id) REFERENCES test_runs(id)
            )
            """
        )
        cols = [row[1] for row in conn.execute("PRAGMA table_info(test_items)").fetchall()]
        if "number_type" not in cols:
            conn.execute("ALTER TABLE test_items ADD COLUMN number_type TEXT")
        if "raw_text" not in cols:
            conn.execute("ALTER TABLE test_items ADD COLUMN raw_text TEXT")
        if "stage_timings_json" not in cols:
            conn.execute("ALTER TABLE test_items ADD COLUMN stage_timings_json TEXT")
        conn.commit()


def _normalize_text(value: str | None) -> str:
    if not value:
        return ""
    return "".join(ch for ch in value.upper() if ch.isalnum())


def _extract_result_text(response_obj: Any, fallback_text: str) -> str:
    if isinstance(response_obj, dict):
        result = response_obj.get("result")
        if isinstance(result, str) and result.strip():
            return result.strip()
        m = RESULT_RE.search(str(response_obj.get("message", "")))
        if m:
            return m.group(1).strip()
    m = RESULT_RE.search(fallback_text or "")
    return m.group(1).strip() if m else ""


def _extract_raw_text(response_obj: Any, fallback_text: str) -> str:
    if isinstance(response_obj, dict):
        raw_text = response_obj.get("raw_text")
        if isinstance(raw_text, str) and raw_text.strip():
            return raw_text.strip()
    return _extract_result_text(response_obj, fallback_text)


def _extract_failure_reason(response_obj: Any) -> str:
    if not isinstance(response_obj, dict):
        return ""
    failure_reason = response_obj.get("failure_reason")
    if isinstance(failure_reason, str) and failure_reason.strip():
        return failure_reason.strip()
    ocr_debug = response_obj.get("ocr_debug")
    if isinstance(ocr_debug, dict):
        reason = ocr_debug.get("reason")
        if isinstance(reason, str) and reason.strip() and reason.strip() != "ok":
            return reason.strip()
    return ""


def _extract_stage_timings(response_obj: Any) -> dict[str, float]:
    if not isinstance(response_obj, dict):
        return {}
    raw = response_obj.get("timings_ms")
    if not isinstance(raw, dict):
        return {}
    out: dict[str, float] = {}
    for key in ("read_ms", "decode_ms", "bbox_ms", "ocr_ms", "validation_ms", "postprocess_ms", "total_ms"):
        value = raw.get(key)
        try:
            if value is None:
                continue
            out[key] = round(float(value), 3)
        except (TypeError, ValueError):
            continue
    return out


def _mime_for_filename(name: str) -> str:
    mime, _ = mimetypes.guess_type(name)
    return mime or "application/octet-stream"


def _format_request_error(exc: requests.RequestException, timeout_sec: float) -> str:
    if isinstance(exc, requests.ReadTimeout):
        return f"Read timeout after {timeout_sec:.1f}s. Increase timeout and retry."
    return str(exc)


def _find_match_file(base_dir: Path, image_path: Path) -> Path | None:
    if not base_dir.exists():
        return None
    txt = base_dir / f"{image_path.stem}.txt"
    if txt.exists():
        return txt
    same = base_dir / image_path.name
    return same if same.exists() else None


def _read_expected_label(labels_dir: Path | None, image_path: Path) -> str | None:
    if labels_dir is None:
        return None
    path = _find_match_file(labels_dir, image_path)
    if path is None:
        return None
    raw = path.read_text(encoding="utf-8", errors="ignore")
    found = CONTAINER_RE.findall(raw.upper())
    if found:
        return found[0]
    normalized = _normalize_text(raw)
    return normalized or None


def _read_expected_text(text_dir: Path | None, image_path: Path) -> str | None:
    if text_dir is None:
        return None
    path = _find_match_file(text_dir, image_path)
    if path is None:
        return None
    normalized = _normalize_text(path.read_text(encoding="utf-8", errors="ignore"))
    return normalized or None


def _normalize_number_type(value: str | None) -> str:
    if value is None:
        return "unknown"
    normalized = str(value).strip().lower().replace("-", "_").replace(" ", "_")
    return NUMBER_TYPE_ALIASES.get(normalized, "unknown")


def _detect_number_type_hint(source: str | Path | None) -> str:
    if source is None:
        return "unknown"
    raw = str(source).strip().lower().replace("\\", "/")
    if not raw:
        return "unknown"

    for part in raw.split("/"):
        part = part.strip()
        if not part:
            continue
        direct = _normalize_number_type(part)
        if direct != "unknown":
            return direct
        match = NUMBER_TYPE_HINT_RE.search(part)
        if match:
            return _normalize_number_type(match.group(1))
    return "unknown"


def _detect_number_type_from_image_bytes(image_bytes: bytes, mode: str, source_hint: str | None = None) -> str:
    if str(mode).lower() != "container":
        return "unknown"
    arr = np.frombuffer(image_bytes, dtype=np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img is None:
        return _detect_number_type_hint(source_hint)
    detected_type = _detect_container_type_from_image(img)
    if detected_type != "unknown":
        return detected_type
    return _detect_number_type_hint(source_hint)


def _detect_number_type_from_image_path(image_path: Path, mode: str) -> str:
    if str(mode).lower() != "container":
        return "unknown"
    img = cv2.imread(str(image_path))
    if img is None:
        return _detect_number_type_hint(image_path)
    detected_type = _detect_container_type_from_image(img)
    if detected_type != "unknown":
        return detected_type
    return _detect_number_type_hint(image_path)


def _detect_container_type_from_image(img) -> str:
    direct_type = "unknown"
    try:
        direct_type = _normalize_number_type(classify_container_layout(img))
    except Exception as exc:
        logger.debug("direct container type detection failed: %s", exc)

    crop_type = "unknown"
    try:
        fn = getattr(container_crop_service, "detect_and_crop_container_with_box", None)
        if callable(fn):
            crop, _bbox = fn(img)
            if crop is not None and getattr(crop, "size", 0):
                crop_type = _normalize_number_type(classify_container_layout(crop))

        if crop_type == "unknown":
            fallback = getattr(container_crop_service, "detect_and_crop", None)
            if callable(fallback):
                crops = fallback(img)
                if crops:
                    crop = crops[0]
                    if crop is not None and getattr(crop, "size", 0):
                        crop_type = _normalize_number_type(classify_container_layout(crop))
    except Exception as exc:
        logger.debug("container type detection by crop failed: %s", exc)

    for candidate in (crop_type, direct_type):
        if candidate != "unknown":
            return candidate
    return "unknown"


def _percentile(values: list[float], p: float) -> float | None:
    if not values:
        return None
    data = sorted(values)
    if len(data) == 1:
        return data[0]
    rank = (len(data) - 1) * p
    low = int(rank)
    high = min(low + 1, len(data) - 1)
    frac = rank - low
    return data[low] + (data[high] - data[low]) * frac


def _finalize_and_store_test_run(
    *,
    dataset_id: str,
    mode: str,
    endpoint: str,
    timeout_sec: float,
    items: list[dict[str, Any]],
    labels_available: bool,
    text_available: bool,
) -> dict[str, Any]:
    latencies = [float(it["elapsed_ms"]) for it in items if it.get("elapsed_ms") is not None]
    ok_items = [it for it in items if it["status_code"] == 200 and not it["error"]]
    not_found_count = sum(1 for it in ok_items if it["normalized_predicted"] in {"", "NOTFOUND"})
    labels_items = [it for it in items if it["expected_label"]]
    text_items = [it for it in items if it["expected_text"]]
    label_matches = sum(
        1
        for it in labels_items
        if it["normalized_predicted"] == _normalize_text(it["expected_label"]) and it["normalized_predicted"]
    )
    text_matches = sum(
        1
        for it in text_items
        if it["normalized_predicted"] == _normalize_text(it["expected_text"]) and it["normalized_predicted"]
    )

    summary = {
        "created_at": _utc_now_iso(),
        "dataset_dir": dataset_id,
        "mode": mode,
        "endpoint": endpoint,
        "total_images": len(items),
        "ok_requests": len(ok_items),
        "failed_requests": len(items) - len(ok_items),
        "not_found_count": not_found_count,
        "latency_mean_ms": round(sum(latencies) / len(latencies), 3) if latencies else None,
        "latency_p95_ms": round(_percentile(latencies, 0.95), 3) if latencies else None,
        "labels_available": labels_available,
        "text_available": text_available,
        "label_total": len(labels_items),
        "label_matches": label_matches,
        "label_accuracy": round(label_matches / len(labels_items), 4) if labels_items else None,
        "text_total": len(text_items),
        "text_matches": text_matches,
        "text_accuracy": round(text_matches / len(text_items), 4) if text_items else None,
    }

    with sqlite3.connect(ADMIN_DB_PATH) as conn:
        cur = conn.execute(
            """
            INSERT INTO test_runs (
                created_at, dataset_dir, mode, timeout_sec, labels_available, text_available, summary_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                summary["created_at"],
                summary["dataset_dir"],
                summary["mode"],
                timeout_sec,
                int(summary["labels_available"]),
                int(summary["text_available"]),
                json.dumps(summary, ensure_ascii=False),
            ),
        )
        run_id = int(cur.lastrowid)
        for it in items:
            conn.execute(
                """
                INSERT INTO test_items (
                    run_id, file_name, number_type, predicted_text, raw_text, normalized_predicted, expected_label, expected_text, status_code, elapsed_ms, stage_timings_json, error
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    run_id,
                    it["file_name"],
                    _normalize_number_type(it.get("number_type")),
                    it["predicted_text"],
                    it.get("raw_text", ""),
                    it["normalized_predicted"],
                    it["expected_label"],
                    it["expected_text"],
                    it["status_code"],
                    it["elapsed_ms"],
                    json.dumps(it.get("stage_timings") or {}, ensure_ascii=False),
                    it["error"],
                ),
            )
        conn.commit()
    return {"run_id": run_id, "summary": summary, "items": items}


def _load_test_run_data(run_id: int) -> dict[str, Any]:
    with sqlite3.connect(ADMIN_DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            """
            SELECT id, created_at, dataset_dir, mode, timeout_sec, labels_available, text_available, summary_json
            FROM test_runs
            WHERE id = ?
            """,
            (run_id,),
        ).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="run not found")
        items = conn.execute(
            """
            SELECT file_name, number_type, predicted_text, raw_text, normalized_predicted, expected_label, expected_text, status_code, elapsed_ms, stage_timings_json, error
            FROM test_items
            WHERE run_id = ?
            ORDER BY id ASC
            """,
            (run_id,),
        ).fetchall()
    parsed_items: list[dict[str, Any]] = []
    for x in items:
        item = dict(x)
        raw_stage = item.pop("stage_timings_json", None)
        try:
            item["stage_timings"] = json.loads(raw_stage) if raw_stage else {}
        except json.JSONDecodeError:
            item["stage_timings"] = {}
        item["number_type"] = _normalize_number_type(item.get("number_type"))
        parsed_items.append(item)
    return {
        "run_id": int(row["id"]),
        "created_at": row["created_at"],
        "dataset_dir": row["dataset_dir"],
        "mode": row["mode"],
        "timeout_sec": float(row["timeout_sec"]),
        "labels_available": bool(row["labels_available"]),
        "text_available": bool(row["text_available"]),
        "summary": json.loads(row["summary_json"]),
        "items": parsed_items,
    }


def _fmt_pct(value: float | None) -> str:
    if value is None:
        return "N/A"
    return f"{value * 100:.2f}%"


def _fmt_num(value: float | None) -> str:
    if value is None:
        return "N/A"
    return f"{value:.3f}"


def _build_svg_bar_chart(
    *,
    labels: list[str],
    values: list[float],
    title: str,
    y_title: str,
    x_title: str = "Stage number",
    multicolor: bool = False,
) -> str:
    if not labels or not values:
        return '<div class="plot-empty">No data</div>'

    palette = [
        "#2f6db5",
        "#1f9d8b",
        "#d9822b",
        "#ad1457",
        "#6d4c41",
        "#5e35b1",
        "#00897b",
        "#ef6c00",
        "#455a64",
        "#7cb342",
    ]

    w = max(920, min(3600, 220 + len(values) * 24))
    h = 420
    pad_l, pad_r, pad_t, pad_b = 70, 20, 50, 95
    plot_w = w - pad_l - pad_r
    plot_h = h - pad_t - pad_b
    vmax = max(max(values), 1.0)
    y_max = vmax * 1.1
    ticks = 5
    bw = plot_w / max(len(values), 1)
    bar_w = max(5.0, bw * 0.68)
    label_step = max(1, len(values) // 25)

    out: list[str] = []
    out.append(f'<svg viewBox="0 0 {w} {h}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="{html.escape(title)}">')
    out.append('<rect x="0" y="0" width="100%" height="100%" fill="#ffffff"/>')
    out.append(
        f'<text x="{w/2:.1f}" y="28" text-anchor="middle" fill="#1f2937" '
        'font-size="16" font-family="Arial, sans-serif" font-weight="700">'
        f"{html.escape(title)}</text>"
    )

    for i in range(ticks + 1):
        y = pad_t + plot_h - (plot_h * i / ticks)
        tick_val = y_max * i / ticks
        out.append(f'<line x1="{pad_l}" y1="{y:.1f}" x2="{w - pad_r}" y2="{y:.1f}" stroke="#e5eaf2" stroke-width="1"/>')
        out.append(
            f'<text x="{pad_l - 8}" y="{y + 4:.1f}" text-anchor="end" fill="#607086" '
            f'font-size="11" font-family="Arial, sans-serif">{tick_val:.0f}</text>'
        )

    out.append(
        f'<line x1="{pad_l}" y1="{pad_t + plot_h}" x2="{w - pad_r}" y2="{pad_t + plot_h}" stroke="#9aa8bc" stroke-width="1.2"/>'
    )
    out.append(f'<line x1="{pad_l}" y1="{pad_t}" x2="{pad_l}" y2="{pad_t + plot_h}" stroke="#9aa8bc" stroke-width="1.2"/>')

    for idx, (label, raw_value) in enumerate(zip(labels, values)):
        value = max(0.0, float(raw_value))
        bh = 0.0 if y_max <= 0 else plot_h * value / y_max
        x = pad_l + bw * idx + (bw - bar_w) / 2
        y = pad_t + plot_h - bh
        color = palette[idx % len(palette)] if multicolor else "#2f6db5"
        out.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="{bar_w:.1f}" height="{bh:.1f}" fill="{color}" rx="2"/>')

        if len(values) <= 40 or idx % label_step == 0:
            out.append(
                f'<text x="{x + bar_w/2:.1f}" y="{pad_t + plot_h + 16:.1f}" text-anchor="middle" '
                'fill="#607086" font-size="10" font-family="Arial, sans-serif">'
                f"{html.escape(str(label))}</text>"
            )

    out.append(
        f'<text x="{pad_l - 50:.1f}" y="{pad_t - 10:.1f}" text-anchor="start" '
        'fill="#4b5b71" font-size="11" font-family="Arial, sans-serif">'
        f"{html.escape(y_title)}</text>"
    )
    out.append(
        f'<text x="{w/2:.1f}" y="{h - 12:.1f}" text-anchor="middle" fill="#4b5b71" '
        f'font-size="11" font-family="Arial, sans-serif">{html.escape(x_title)}</text>'
    )
    out.append("</svg>")
    return "".join(out)




def _as_container_candidate(value: str | None) -> str | None:
    if value is None:
        return None
    normalized = _normalize_text(value)
    m = re.search(r"[A-Z]{4}\d{7}", normalized)
    if m:
        return m.group(0)
    return None


def _expected_candidate_from_item(item: dict[str, Any]) -> str | None:
    return _as_container_candidate(item.get("expected_text")) or _as_container_candidate(item.get("expected_label"))


def _predicted_candidate_from_item(item: dict[str, Any]) -> str | None:
    return _as_container_candidate(item.get("normalized_predicted") or item.get("predicted_text"))


def _item_result_category(item: dict[str, Any]) -> str:
    predicted = _predicted_candidate_from_item(item)
    expected = _expected_candidate_from_item(item)
    if item.get("status_code") != 200 or item.get("error") or not predicted or predicted == "NOTFOUND":
        return "not_recognized"
    if expected:
        return "correct" if predicted == expected else "incorrect"
    return "correct"


def _recognition_elapsed_sec(item: dict[str, Any]) -> float:
    stage_timings = item.get("stage_timings") or {}
    recognition_ms = (
        float(stage_timings.get("bbox_ms") or 0.0)
        + float(stage_timings.get("ocr_ms") or 0.0)
        + float(stage_timings.get("validation_ms") or 0.0)
        + float(stage_timings.get("postprocess_ms") or 0.0)
    )
    elapsed_ms = float(item.get("elapsed_ms") or 0.0)
    if recognition_ms <= 0.0:
        recognition_ms = elapsed_ms
    return max(0.0, recognition_ms / 1000.0)


def _request_elapsed_sec(item: dict[str, Any]) -> float:
    return max(0.0, float(item.get("elapsed_ms") or 0.0) / 1000.0)


def _present_known_number_types(items: list[dict[str, Any]]) -> list[str]:
    present: list[str] = []
    for number_type in KNOWN_NUMBER_TYPES:
        if any(_normalize_number_type(it.get("number_type")) == number_type for it in items):
            present.append(number_type)
    return present


def _type_stats(items: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    stats: dict[str, dict[str, Any]] = {}
    for number_type in _present_known_number_types(items):
        bucket = [it for it in items if _normalize_number_type(it.get("number_type")) == number_type]
        correct = sum(1 for it in bucket if _item_result_category(it) == "correct")
        incorrect = sum(1 for it in bucket if _item_result_category(it) == "incorrect")
        not_recognized = sum(1 for it in bucket if _item_result_category(it) == "not_recognized")
        recognition_times = [_recognition_elapsed_sec(it) for it in bucket]
        request_times = [_request_elapsed_sec(it) for it in bucket]
        total = len(bucket)
        stats[number_type] = {
            "items": bucket,
            "total": total,
            "correct": correct,
            "incorrect": incorrect,
            "not_recognized": not_recognized,
            "accuracy_pct": (correct / total * 100.0) if total else 0.0,
            "recognition_times": recognition_times,
            "request_times": request_times,
        }
    return stats


def _build_svg_line_chart(*, labels: list[str], values: list[float], title: str, y_title: str, x_title: str) -> str:
    if not labels or not values:
        return '<div class="plot-empty">No data</div>'

    w = max(920, min(3600, 220 + len(values) * 28))
    h = 420
    pad_l, pad_r, pad_t, pad_b = 72, 24, 52, 90
    plot_w = w - pad_l - pad_r
    plot_h = h - pad_t - pad_b
    vmin = min(values)
    vmax = max(values)
    if vmax <= vmin:
        vmax = vmin + 1.0
    y_min = min(0.0, vmin)
    y_max = vmax * 1.1 if vmax > 0 else 1.0
    ticks = 5
    step_x = plot_w / max(len(values) - 1, 1)
    label_step = max(1, len(values) // 25)

    def y_of(value: float) -> float:
        return pad_t + plot_h - ((value - y_min) / (y_max - y_min) * plot_h)

    out: list[str] = []
    out.append(f'<svg viewBox="0 0 {w} {h}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="{html.escape(title)}">')
    out.append('<rect x="0" y="0" width="100%" height="100%" fill="#ffffff"/>')
    out.append(
        f'<text x="{w/2:.1f}" y="28" text-anchor="middle" fill="#1f2937" '
        'font-size="16" font-family="Arial, sans-serif" font-weight="700">'
        f"{html.escape(title)}</text>"
    )
    for i in range(ticks + 1):
        y = pad_t + plot_h - (plot_h * i / ticks)
        tick_val = y_min + (y_max - y_min) * i / ticks
        out.append(f'<line x1="{pad_l}" y1="{y:.1f}" x2="{w - pad_r}" y2="{y:.1f}" stroke="#e5eaf2" stroke-width="1"/>')
        out.append(
            f'<text x="{pad_l - 8}" y="{y + 4:.1f}" text-anchor="end" fill="#607086" '
            f'font-size="11" font-family="Arial, sans-serif">{tick_val:.2f}</text>'
        )
    out.append(f'<line x1="{pad_l}" y1="{pad_t + plot_h}" x2="{w - pad_r}" y2="{pad_t + plot_h}" stroke="#9aa8bc" stroke-width="1.2"/>')
    out.append(f'<line x1="{pad_l}" y1="{pad_t}" x2="{pad_l}" y2="{pad_t + plot_h}" stroke="#9aa8bc" stroke-width="1.2"/>')

    points = []
    for idx, value in enumerate(values):
        x = pad_l + step_x * idx
        y = y_of(float(value))
        points.append(f"{x:.1f},{y:.1f}")
    out.append(f'<polyline fill="none" stroke="#2f6db5" stroke-width="2.2" points="{" ".join(points)}"/>')
    for idx, (label, value) in enumerate(zip(labels, values)):
        x = pad_l + step_x * idx
        y = y_of(float(value))
        out.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="3.5" fill="#2f6db5"/>')
        if len(values) <= 40 or idx % label_step == 0:
            out.append(
                f'<text x="{x:.1f}" y="{pad_t + plot_h + 16:.1f}" text-anchor="middle" '
                'fill="#607086" font-size="10" font-family="Arial, sans-serif">'
                f"{html.escape(str(label))}</text>"
            )
    out.append(
        f'<text x="{pad_l - 54:.1f}" y="{pad_t - 10:.1f}" text-anchor="start" '
        'fill="#4b5b71" font-size="11" font-family="Arial, sans-serif">'
        f"{html.escape(y_title)}</text>"
    )
    out.append(
        f'<text x="{w/2:.1f}" y="{h - 12:.1f}" text-anchor="middle" fill="#4b5b71" '
        f'font-size="11" font-family="Arial, sans-serif">{html.escape(x_title)}</text>'
    )
    out.append('</svg>')
    return ''.join(out)


def _build_svg_stacked_bar_chart(*, labels: list[str], series: list[tuple[str, list[float], str]], title: str, y_title: str, x_title: str) -> str:
    if not labels or not series:
        return '<div class="plot-empty">No data</div>'

    totals = [0.0] * len(labels)
    for _name, values, _color in series:
        for idx, value in enumerate(values):
            totals[idx] += max(0.0, float(value))
    vmax = max(max(totals), 1.0)

    w = max(920, min(2600, 260 + len(labels) * 110))
    h = 420
    pad_l, pad_r, pad_t, pad_b = 72, 24, 52, 92
    plot_w = w - pad_l - pad_r
    plot_h = h - pad_t - pad_b
    ticks = 5
    bw = plot_w / max(len(labels), 1)
    bar_w = max(24.0, min(90.0, bw * 0.55))
    y_max = vmax * 1.12

    out: list[str] = []
    out.append(f'<svg viewBox="0 0 {w} {h}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="{html.escape(title)}">')
    out.append('<rect x="0" y="0" width="100%" height="100%" fill="#ffffff"/>')
    out.append(
        f'<text x="{w/2:.1f}" y="28" text-anchor="middle" fill="#1f2937" '
        'font-size="16" font-family="Arial, sans-serif" font-weight="700">'
        f"{html.escape(title)}</text>"
    )
    for i in range(ticks + 1):
        y = pad_t + plot_h - (plot_h * i / ticks)
        tick_val = y_max * i / ticks
        out.append(f'<line x1="{pad_l}" y1="{y:.1f}" x2="{w - pad_r}" y2="{y:.1f}" stroke="#e5eaf2" stroke-width="1"/>')
        out.append(
            f'<text x="{pad_l - 8}" y="{y + 4:.1f}" text-anchor="end" fill="#607086" '
            f'font-size="11" font-family="Arial, sans-serif">{tick_val:.0f}</text>'
        )
    out.append(f'<line x1="{pad_l}" y1="{pad_t + plot_h}" x2="{w - pad_r}" y2="{pad_t + plot_h}" stroke="#9aa8bc" stroke-width="1.2"/>')
    out.append(f'<line x1="{pad_l}" y1="{pad_t}" x2="{pad_l}" y2="{pad_t + plot_h}" stroke="#9aa8bc" stroke-width="1.2"/>')
    for idx, label in enumerate(labels):
        x = pad_l + bw * idx + (bw - bar_w) / 2
        bottom = 0.0
        for _name, values, color in series:
            value = max(0.0, float(values[idx]))
            bh = 0.0 if y_max <= 0 else plot_h * value / y_max
            y = pad_t + plot_h - bh - (plot_h * bottom / y_max)
            out.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="{bar_w:.1f}" height="{bh:.1f}" fill="{color}" rx="2"/>')
            bottom += value
        out.append(
            f'<text x="{x + bar_w/2:.1f}" y="{pad_t + plot_h + 18:.1f}" text-anchor="middle" '
            'fill="#607086" font-size="11" font-family="Arial, sans-serif">'
            f"{html.escape(str(label))}</text>"
        )
    legend_x = pad_l
    legend_y = 40
    for idx, (name, _values, color) in enumerate(series):
        lx = legend_x + idx * 148
        out.append(f'<rect x="{lx}" y="{legend_y}" width="12" height="12" rx="2" fill="{color}"/>')
        out.append(f'<text x="{lx + 18}" y="{legend_y + 10}" fill="#36485f" font-size="12" font-family="Arial, sans-serif">{html.escape(name)}</text>')
    out.append(
        f'<text x="{pad_l - 52:.1f}" y="{pad_t - 10:.1f}" text-anchor="start" '
        'fill="#4b5b71" font-size="11" font-family="Arial, sans-serif">'
        f"{html.escape(y_title)}</text>"
    )
    out.append(
        f'<text x="{w/2:.1f}" y="{h - 12:.1f}" text-anchor="middle" fill="#4b5b71" '
        f'font-size="11" font-family="Arial, sans-serif">{html.escape(x_title)}</text>'
    )
    out.append('</svg>')
    return ''.join(out)


def _build_svg_box_plot(*, groups: list[tuple[str, list[float]]], title: str, y_title: str, x_title: str) -> str:
    usable = [(label, [float(v) for v in values if v is not None]) for label, values in groups if values]
    if not usable:
        return '<div class="plot-empty">No data</div>'

    all_values = [v for _label, vals in usable for v in vals]
    vmin = min(all_values)
    vmax = max(all_values)
    if vmax <= vmin:
        vmax = vmin + 1.0

    w = max(920, min(2600, 260 + len(usable) * 200))
    h = 420
    pad_l, pad_r, pad_t, pad_b = 72, 24, 52, 90
    plot_w = w - pad_l - pad_r
    plot_h = h - pad_t - pad_b
    ticks = 5
    y_min = max(0.0, vmin - (vmax - vmin) * 0.08)
    y_max = vmax + (vmax - vmin) * 0.08

    def y_of(value: float) -> float:
        return pad_t + plot_h - ((value - y_min) / (y_max - y_min) * plot_h)

    out: list[str] = []
    out.append(f'<svg viewBox="0 0 {w} {h}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="{html.escape(title)}">')
    out.append('<rect x="0" y="0" width="100%" height="100%" fill="#ffffff"/>')
    out.append(
        f'<text x="{w/2:.1f}" y="28" text-anchor="middle" fill="#1f2937" '
        'font-size="16" font-family="Arial, sans-serif" font-weight="700">'
        f"{html.escape(title)}</text>"
    )
    for i in range(ticks + 1):
        y = pad_t + plot_h - (plot_h * i / ticks)
        tick_val = y_min + (y_max - y_min) * i / ticks
        out.append(f'<line x1="{pad_l}" y1="{y:.1f}" x2="{w - pad_r}" y2="{y:.1f}" stroke="#e5eaf2" stroke-width="1"/>')
        out.append(
            f'<text x="{pad_l - 8}" y="{y + 4:.1f}" text-anchor="end" fill="#607086" '
            f'font-size="11" font-family="Arial, sans-serif">{tick_val:.2f}</text>'
        )
    out.append(f'<line x1="{pad_l}" y1="{pad_t + plot_h}" x2="{w - pad_r}" y2="{pad_t + plot_h}" stroke="#9aa8bc" stroke-width="1.2"/>')
    out.append(f'<line x1="{pad_l}" y1="{pad_t}" x2="{pad_l}" y2="{pad_t + plot_h}" stroke="#9aa8bc" stroke-width="1.2"/>')

    step_x = plot_w / max(len(usable), 1)
    box_w = min(80.0, step_x * 0.34)
    for idx, (label, values) in enumerate(usable):
        values = sorted(values)
        q1 = _percentile(values, 0.25) or values[0]
        q2 = _percentile(values, 0.50) or values[0]
        q3 = _percentile(values, 0.75) or values[-1]
        low = values[0]
        high = values[-1]
        cx = pad_l + step_x * idx + step_x / 2
        x = cx - box_w / 2
        out.append(f'<line x1="{cx:.1f}" y1="{y_of(low):.1f}" x2="{cx:.1f}" y2="{y_of(high):.1f}" stroke="#777" stroke-width="1.5"/>')
        out.append(f'<line x1="{cx - box_w/3:.1f}" y1="{y_of(low):.1f}" x2="{cx + box_w/3:.1f}" y2="{y_of(low):.1f}" stroke="#777" stroke-width="1.5"/>')
        out.append(f'<line x1="{cx - box_w/3:.1f}" y1="{y_of(high):.1f}" x2="{cx + box_w/3:.1f}" y2="{y_of(high):.1f}" stroke="#777" stroke-width="1.5"/>')
        out.append(f'<rect x="{x:.1f}" y="{y_of(q3):.1f}" width="{box_w:.1f}" height="{max(2.0, y_of(q1)-y_of(q3)):.1f}" fill="#ffffff" stroke="#777" stroke-width="1.5"/>')
        out.append(f'<line x1="{x:.1f}" y1="{y_of(q2):.1f}" x2="{x + box_w:.1f}" y2="{y_of(q2):.1f}" stroke="#c57b32" stroke-width="2"/>')
        out.append(
            f'<text x="{cx:.1f}" y="{pad_t + plot_h + 18:.1f}" text-anchor="middle" '
            'fill="#607086" font-size="11" font-family="Arial, sans-serif">'
            f"{html.escape(str(label))}</text>"
        )
    out.append(
        f'<text x="{pad_l - 52:.1f}" y="{pad_t - 10:.1f}" text-anchor="start" '
        'fill="#4b5b71" font-size="11" font-family="Arial, sans-serif">'
        f"{html.escape(y_title)}</text>"
    )
    out.append(
        f'<text x="{w/2:.1f}" y="{h - 12:.1f}" text-anchor="middle" fill="#4b5b71" '
        f'font-size="11" font-family="Arial, sans-serif">{html.escape(x_title)}</text>'
    )
    out.append('</svg>')
    return ''.join(out)


def _build_request_rows_html(items: list[dict[str, Any]]) -> str:
    row_html: list[str] = []
    for it in items:
        row_html.append(
            "<tr>"
            f"<td>{html.escape(str(it.get('file_name') or ''))}</td>"
            f"<td>{html.escape(str(it.get('number_type') or 'unknown'))}</td>"
            f"<td>{html.escape(str(it.get('predicted_text') or ''))}</td>"
            f"<td>{html.escape(str(it.get('raw_text') or ''))}</td>"
            f"<td>{html.escape(str(it.get('expected_label') or ''))}</td>"
            f"<td>{html.escape(str(it.get('expected_text') or ''))}</td>"
            f"<td>{html.escape(str(it.get('status_code') or ''))}</td>"
            f"<td>{_fmt_num(float(it.get('elapsed_ms') or 0.0) / 1000.0)}</td>"
            f"<td>{html.escape(str(it.get('error') or ''))}</td>"
            "</tr>"
        )
    return "".join(row_html)


def _build_requests_table_section(items: list[dict[str, Any]]) -> str:
    row_html = _build_request_rows_html(items)
    return f"""
    <h2>Таблица запросов</h2>
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Файл</th><th>Тип</th><th>Predicted</th><th>Raw</th><th>Expected Label</th><th>Expected Text</th><th>Status</th><th>Latency (с)</th><th>Error</th>
          </tr>
        </thead>
        <tbody>
          {row_html if row_html else '<tr><td colspan="9">No data</td></tr>'}
        </tbody>
      </table>
    </div>
"""


def _build_testing_html_report(run: dict[str, Any]) -> str:
    items = run["items"]
    summary = run["summary"]

    for item in items:
        item["number_type"] = _normalize_number_type(item.get("number_type"))

    result_categories = [_item_result_category(it) for it in items]
    correct_count = sum(1 for x in result_categories if x == "correct")
    incorrect_count = sum(1 for x in result_categories if x == "incorrect")
    not_recognized_count = sum(1 for x in result_categories if x == "not_recognized")

    recognition_times_sec = [_recognition_elapsed_sec(it) for it in items]
    request_times_sec = [_request_elapsed_sec(it) for it in items]
    present_types = _present_known_number_types(items)
    type_stats = _type_stats(items)

    accuracy_chart = _build_svg_bar_chart(
        labels=present_types,
        values=[type_stats[number_type]["accuracy_pct"] for number_type in present_types],
        title="Точность по типам номеров",
        y_title="Точность (%)",
        x_title="Тип номера",
        multicolor=False,
    )
    count_chart = _build_svg_bar_chart(
        labels=present_types,
        values=[float(type_stats[number_type]["total"]) for number_type in present_types],
        title="Количество номеров по типам",
        y_title="Количество (шт)",
        x_title="Тип номера",
        multicolor=False,
    )
    errors_chart = _build_svg_stacked_bar_chart(
        labels=present_types,
        series=[
            ("правильно", [float(type_stats[number_type]["correct"]) for number_type in present_types], "#2e9b44"),
            ("неверно", [float(type_stats[number_type]["incorrect"]) for number_type in present_types], "#d9822b"),
            ("не распознано", [float(type_stats[number_type]["not_recognized"]) for number_type in present_types], "#d64545"),
        ],
        title="Ошибки по типам номеров",
        y_title="Количество (шт)",
        x_title="Тип номера",
    )
    box_chart = _build_svg_box_plot(
        groups=[(number_type, type_stats[number_type]["recognition_times"]) for number_type in present_types],
        title="Время распознавания по типам номеров",
        y_title="Время (с)",
        x_title="Тип номера",
    )
    line_chart = _build_svg_line_chart(
        labels=[str(idx) for idx in range(1, len(request_times_sec) + 1)],
        values=request_times_sec,
        title="Время запросов по порядку",
        y_title="Время (с)",
        x_title="Порядковый номер запроса",
    )

    requests_table_block = _build_requests_table_section(items)

    median_recognition = _percentile(recognition_times_sec, 0.5) if recognition_times_sec else None
    p95_recognition = _percentile(recognition_times_sec, 0.95) if recognition_times_sec else None
    p99_recognition = _percentile(recognition_times_sec, 0.99) if recognition_times_sec else None
    median_request = _percentile(request_times_sec, 0.5) if request_times_sec else None
    error_rate = ((incorrect_count + not_recognized_count) / len(items) * 100.0) if items else 0.0
    accuracy_pct = (correct_count / len(items) * 100.0) if items else 0.0

    html_content = f"""<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Статистика распознавания из логов</title>
  <style>
    * {{ box-sizing: border-box; }}
    body {{ margin: 0; font-family: Arial, sans-serif; color: #111827; background: #f5f7fb; }}
    .container {{ max-width: 1420px; margin: 0 auto; padding: 20px; }}
    h1 {{ margin: 0 0 10px; font-size: 24px; }}
    h2 {{ margin: 24px 0 12px; font-size: 18px; }}
    .meta, .subtitle {{ color: #5f6f86; font-size: 14px; }}
    .cards {{ display:grid; grid-template-columns: repeat(4, minmax(0,1fr)); gap:12px; }}
    .card {{ background:#fff; border:1px solid #d8e1ef; border-radius:10px; padding:14px 16px; }}
    .label {{ color:#697a92; font-size:13px; margin-bottom:6px; }}
    .value {{ font-size:18px; font-weight:700; }}
    .plots {{ display:grid; grid-template-columns: repeat(2, minmax(0,1fr)); gap:16px; }}
    .plot {{ background:#fff; border:1px solid #d8e1ef; border-radius:12px; padding:10px; overflow:auto; }}
    .plot:empty {{ display:none; }}
    table {{ width:100%; border-collapse: collapse; background:#fff; }}
    th, td {{ border:1px solid #e3e9f3; padding:8px; font-size:12px; text-align:left; vertical-align:top; }}
    th {{ background:#eef3fb; position: sticky; top: 0; z-index: 1; }}
    .table-wrap {{ max-height:620px; overflow:auto; border:1px solid #d8e1ef; border-radius:12px; background:#fff; }}
    .report-meta {{ margin-top: 8px; color:#5f6f86; font-size:13px; }}
    @media (max-width: 1100px) {{
      .cards {{ grid-template-columns: repeat(2, minmax(0,1fr)); }}
      .plots {{ grid-template-columns: 1fr; }}
    }}
  </style>
</head>
<body>
  <div class="container">
    <h1>Статистика распознавания из логов</h1>
    <div class="subtitle">Единицы измерения: время = секунды (с), количество = штуки (шт), точность/доля/error rate = проценты (%)</div>
    <div class="report-meta">Run ID: {run['run_id']} | Created: {html.escape(str(run['created_at']))} | Dataset: {html.escape(str(run['dataset_dir']))} | Mode: {html.escape(str(run['mode']))} | Timeout: {run['timeout_sec']} s</div>

    <h2>Общая статистика</h2>
    <div class="cards">
      <div class="card"><div class="label">Всего запросов (шт)</div><div class="value">{len(items)}</div></div>
      <div class="card"><div class="label">Всего фотографий (шт)</div><div class="value">{len(items)}</div></div>
      <div class="card"><div class="label">Всего номеров (шт)</div><div class="value">{len(items)}</div></div>
      <div class="card"><div class="label">Правильно распознано (шт)</div><div class="value">{correct_count}</div></div>
      <div class="card"><div class="label">Неверно распознано (шт)</div><div class="value">{incorrect_count}</div></div>
      <div class="card"><div class="label">Не распознано (шт)</div><div class="value">{not_recognized_count}</div></div>
      <div class="card"><div class="label">Точность по фото (%)</div><div class="value">{accuracy_pct:.2f}%</div></div>
      <div class="card"><div class="label">Error rate (%)</div><div class="value">{error_rate:.2f}%</div></div>
    </div>

    <h2>Время распознавания</h2>
    <div class="cards">
      <div class="card"><div class="label">Среднее (с)</div><div class="value">{(sum(recognition_times_sec)/len(recognition_times_sec)) if recognition_times_sec else 0.0:.4f} s</div></div>
      <div class="card"><div class="label">Медиана (с)</div><div class="value">{(median_recognition or 0.0):.4f} s</div></div>
      <div class="card"><div class="label">P95 (с)</div><div class="value">{(p95_recognition or 0.0):.4f} s</div></div>
      <div class="card"><div class="label">P99 (с)</div><div class="value">{(p99_recognition or 0.0):.4f} s</div></div>
      <div class="card"><div class="label">Максимум (с)</div><div class="value">{(max(recognition_times_sec) if recognition_times_sec else 0.0):.4f} s</div></div>
      <div class="card"><div class="label">Минимум (с)</div><div class="value">{(min(recognition_times_sec) if recognition_times_sec else 0.0):.4f} s</div></div>
    </div>

    <h2>Время обработки запросов</h2>
    <div class="cards">
      <div class="card"><div class="label">Среднее (с)</div><div class="value">{(sum(request_times_sec)/len(request_times_sec)) if request_times_sec else 0.0:.4f} s</div></div>
      <div class="card"><div class="label">Максимум (с)</div><div class="value">{(max(request_times_sec) if request_times_sec else 0.0):.4f} s</div></div>
      <div class="card"><div class="label">Минимум (с)</div><div class="value">{(min(request_times_sec) if request_times_sec else 0.0):.4f} s</div></div>
      <div class="card"><div class="label">Запросов (шт)</div><div class="value">{len(request_times_sec)}</div></div>
    </div>

    <h2>Графики</h2>
    <div class="plots">
      <div class="plot">{accuracy_chart}</div>
      <div class="plot">{count_chart}</div>
      <div class="plot">{errors_chart}</div>
      <div class="plot">{box_chart}</div>
      <div class="plot">{line_chart}</div>
    </div>

    {requests_table_block}
  </div>
</body>
</html>
"""
    return html_content

def _generate_testing_report_html_file(run_id: int) -> Path:
    run = _load_test_run_data(run_id)
    TEST_REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    html_path = _testing_report_path(run_id)
    html_path.write_text(_build_testing_html_report(run), encoding="utf-8")
    _cleanup_test_reports(mode="policy", dry_run=False, reason="report_generated")
    return html_path


def _ensure_testing_report_html_file(run_id: int) -> Path:
    return _generate_testing_report_html_file(run_id)


def _run_dataset_test(payload: TestRunPayload) -> dict[str, Any]:
    cfg = _load_config()
    dataset_dir = Path(payload.dataset_dir).expanduser()
    if not dataset_dir.exists():
        raise HTTPException(status_code=400, detail=f"dataset_dir not found: {dataset_dir}")

    images_dir = dataset_dir / "images"
    source_images_dir = images_dir if images_dir.exists() and images_dir.is_dir() else dataset_dir
    labels_dir = dataset_dir / "labels"
    labels_dir = labels_dir if labels_dir.exists() and labels_dir.is_dir() else None
    text_dir = dataset_dir / "text"
    text_dir = text_dir if text_dir.exists() and text_dir.is_dir() else None

    image_files = sorted(
        [p for p in source_images_dir.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTS],
        key=lambda p: p.name,
    )
    if not image_files:
        raise HTTPException(status_code=400, detail="No images found in dataset")

    endpoint = "/RecognizeContainerNumber" if payload.mode == "container" else "/RecognizeSealNumber"
    url = f"{_service_base_url(cfg)}{endpoint}"
    items: list[dict[str, Any]] = []
    latencies: list[float] = []

    for img_path in image_files:
        expected_label = _read_expected_label(labels_dir, img_path)
        expected_text = _read_expected_text(text_dir, img_path)
        number_type = _detect_number_type_from_image_path(img_path, payload.mode)
        start = time.perf_counter()
        status_code, predicted, raw_text, normalized_predicted, error = None, "", "", "", None
        stage_timings: dict[str, float] = {}
        try:
            with img_path.open("rb") as fh:
                files = {"files": (img_path.name, fh.read(), _mime_for_filename(img_path.name))}
                resp = requests.post(url, files=files, timeout=payload.timeout_sec)
            status_code = resp.status_code
            elapsed_ms = (time.perf_counter() - start) * 1000.0
            latencies.append(elapsed_ms)
            try:
                obj = resp.json()
                fallback = json.dumps(obj, ensure_ascii=False)
            except ValueError:
                obj = None
                fallback = resp.text
            predicted = _extract_result_text(obj, fallback)
            raw_text = _extract_raw_text(obj, fallback)
            stage_timings = _extract_stage_timings(obj)
            normalized_predicted = _normalize_text(predicted)
            if not resp.ok:
                error = f"HTTP {resp.status_code}"
            elif normalized_predicted in {"", "NOTFOUND"}:
                failure_reason = _extract_failure_reason(obj)
                if failure_reason:
                    error = failure_reason
        except requests.RequestException as exc:
            elapsed_ms = (time.perf_counter() - start) * 1000.0
            error = _format_request_error(exc, payload.timeout_sec)

        try:
            display_name = str(img_path.relative_to(dataset_dir)).replace("\\", "/")
        except Exception:
            display_name = img_path.name

        items.append(
            {
                "file_name": display_name,
                "number_type": number_type,
                "predicted_text": predicted,
                "raw_text": raw_text,
                "normalized_predicted": normalized_predicted,
                "expected_label": expected_label,
                "expected_text": expected_text,
                "status_code": status_code,
                "elapsed_ms": round(elapsed_ms, 3),
                "stage_timings": stage_timings,
                "error": error,
            }
        )

    return _finalize_and_store_test_run(
        dataset_id=str(dataset_dir),
        mode=payload.mode,
        endpoint=endpoint,
        timeout_sec=payload.timeout_sec,
        items=items,
        labels_available=(labels_dir is not None),
        text_available=(text_dir is not None),
    )


@app.on_event("startup")
def on_startup() -> None:
    _init_admin_db()
    if not ADMIN_CFG_PATH.exists():
        _save_config(ServiceConfig())
    _cleanup_test_reports(mode="policy", dry_run=False, reason="startup")


@app.get("/", response_class=HTMLResponse)
def index() -> str:
    if not UI_HTML_PATH.exists():
        return "<html><body><h3>admin_ui_page.html missing</h3></body></html>"
    html_text = UI_HTML_PATH.read_text(encoding="utf-8", errors="ignore")
    return html_text.replace("__ADMIN_UI_VISIBLE_TABS_JSON__", json.dumps(_visible_ui_tabs(), ensure_ascii=False))


@app.get("/api/service/config")
def get_service_config() -> dict[str, Any]:
    return {"config": _model_dump(_load_config())}


@app.post("/api/service/config")
def set_service_config(payload: ServiceConfig) -> dict[str, Any]:
    _save_config(payload)
    return {"config": _model_dump(payload)}


@app.get("/api/service/status")
def service_status() -> dict[str, Any]:
    cfg = _load_config()
    workers_used = _effective_workers(cfg.workers)
    with _managed_lock:
        proc = _managed_process
        running = _is_running(proc)
        pid = proc.pid if running and proc is not None else None
    return {
        "config": _model_dump(cfg),
        "effective_workers": workers_used,
        "managed_running": running,
        "managed_pid": pid,
        "health": _probe_health(_service_base_url(cfg)),
        "base_url": _service_base_url(cfg),
    }


@app.post("/api/service/start")
def start_service() -> dict[str, Any]:
    return _start_managed_service()


@app.post("/api/service/stop")
def stop_service() -> dict[str, Any]:
    return _stop_managed_service()


@app.post("/api/service/restart")
def restart_service() -> dict[str, Any]:
    return _restart_managed_service()


@app.post("/api/service/workers")
def set_workers(payload: WorkersPayload) -> dict[str, Any]:
    cfg = _load_config()
    cfg.workers = payload.workers
    _save_config(cfg)
    with _managed_lock:
        running = _is_running(_managed_process)
    if running:
        _restart_managed_service()
    return {"workers": cfg.workers, "restarted": running}


@app.get("/api/logs")
def get_logs(
    source: str = Query(default="app", pattern="^(app|stdout|all)$"),
    lines: int = Query(default=300, ge=20, le=5000),
) -> dict[str, str]:
    app_chunk = _tail_lines(APP_LOG_PATH, lines)
    stdout_chunk = _tail_lines(SERVICE_STDOUT_LOG_PATH, lines)
    if source == "app":
        return {"text": app_chunk}
    if source == "stdout":
        return {"text": stdout_chunk}
    text = ""
    if app_chunk:
        text += "===== app.log =====\n" + app_chunk + "\n"
    if stdout_chunk:
        text += "===== service_stdout.log =====\n" + stdout_chunk
    return {"text": text}


@app.get("/api/debug/config")
def get_debug_config() -> dict[str, Any]:
    return _proxy_json("GET", "/admin/debug/config")


@app.post("/api/debug/config")
def set_debug_config(payload: DebugConfigPayload) -> dict[str, Any]:
    cfg = _load_config()
    cfg.debug_visualization = payload.enabled
    _save_config(cfg)
    return _proxy_json("POST", "/admin/debug/config", _model_dump(payload))


@app.post("/api/models/reload")
def reload_models() -> dict[str, Any]:
    return _proxy_json("POST", "/admin/models/reload")


@app.get("/api/debug/meta")
def get_debug_meta() -> dict[str, Any]:
    return _proxy_json("GET", "/admin/debug/last-meta")


@app.get("/api/debug/image")
def get_debug_image() -> Response:
    cfg = _load_config()
    try:
        resp = requests.get(f"{_service_base_url(cfg)}/admin/debug/last-image", timeout=15)
    except requests.RequestException as exc:
        raise HTTPException(status_code=502, detail=f"Service request failed: {exc}") from exc
    if resp.status_code == 404:
        raise HTTPException(status_code=404, detail="No debug image yet")
    if not resp.ok:
        raise HTTPException(status_code=resp.status_code, detail=resp.text)
    return Response(content=resp.content, media_type="image/jpeg")


@app.get("/api/recognized")
def get_recognized(limit: int = Query(default=500, ge=1, le=5000)) -> dict[str, Any]:
    return _proxy_json("GET", f"/admin/recognized?limit={limit}")


@app.post("/api/testing/run")
def run_testing(payload: TestRunPayload) -> dict[str, Any]:
    return _run_dataset_test(payload)


@app.post("/api/testing/run-files")
async def run_testing_files(
    mode: str = Form(default="container"),
    timeout_sec: float = Form(default=DEFAULT_TEST_TIMEOUT_SEC),
    files: list[UploadFile] = File(default_factory=list),
) -> dict[str, Any]:
    mode = (mode or "").strip().lower()
    if mode not in {"container", "seal"}:
        raise HTTPException(status_code=400, detail="mode must be 'container' or 'seal'")
    if timeout_sec < 1.0 or timeout_sec > MAX_TEST_TIMEOUT_SEC:
        raise HTTPException(status_code=400, detail=f"timeout_sec must be in range [1, {int(MAX_TEST_TIMEOUT_SEC)}]")
    if not files:
        raise HTTPException(status_code=400, detail="No files uploaded")

    cfg = _load_config()
    endpoint = "/RecognizeContainerNumber" if mode == "container" else "/RecognizeSealNumber"
    url = f"{_service_base_url(cfg)}{endpoint}"

    images: list[tuple[str, str, bytes]] = []
    labels_by_stem: dict[str, str] = {}
    text_by_stem: dict[str, str] = {}
    roots: set[str] = set()

    for upl in files:
        rel = (upl.filename or "").replace("\\", "/").strip("/")
        if not rel:
            continue
        parts = [p for p in rel.split("/") if p]
        if not parts:
            continue
        roots.add(parts[0])

        low_rel = rel.lower()
        parent = parts[-2].lower() if len(parts) >= 2 else ""
        name = parts[-1]
        stem = Path(name).stem
        suffix = Path(name).suffix.lower()
        data = await upl.read()

        if suffix in IMAGE_EXTS and ("/images/" in f"/{low_rel}/" or parent == "images" or len(parts) == 1):
            images.append((rel, name, data))
            continue

        if suffix != ".txt":
            continue

        txt = data.decode("utf-8", errors="ignore")
        if "/labels/" in f"/{low_rel}/" or parent == "labels":
            found = CONTAINER_RE.findall(txt.upper())
            label = found[0] if found else (_normalize_text(txt) or None)
            if label:
                labels_by_stem[stem] = label
        elif "/text/" in f"/{low_rel}/" or parent == "text":
            norm = _normalize_text(txt)
            if norm:
                text_by_stem[stem] = norm

    if not images:
        raise HTTPException(status_code=400, detail="No image files found in selected folder")

    items: list[dict[str, Any]] = []
    for rel, name, data in images:
        stem = Path(name).stem
        expected_label = labels_by_stem.get(stem)
        expected_text = text_by_stem.get(stem)
        number_type = _detect_number_type_from_image_bytes(data, mode, source_hint=rel)

        start = time.perf_counter()
        status_code, predicted, raw_text, normalized_predicted, error = None, "", "", "", None
        stage_timings: dict[str, float] = {}
        try:
            resp = requests.post(
                url,
                files={"files": (name, data, _mime_for_filename(name))},
                timeout=timeout_sec,
            )
            status_code = resp.status_code
            elapsed_ms = (time.perf_counter() - start) * 1000.0
            try:
                obj = resp.json()
                fallback = json.dumps(obj, ensure_ascii=False)
            except ValueError:
                obj = None
                fallback = resp.text
            predicted = _extract_result_text(obj, fallback)
            raw_text = _extract_raw_text(obj, fallback)
            stage_timings = _extract_stage_timings(obj)
            normalized_predicted = _normalize_text(predicted)
            if not resp.ok:
                error = f"HTTP {resp.status_code}"
            elif normalized_predicted in {"", "NOTFOUND"}:
                failure_reason = _extract_failure_reason(obj)
                if failure_reason:
                    error = failure_reason
        except requests.RequestException as exc:
            elapsed_ms = (time.perf_counter() - start) * 1000.0
            error = _format_request_error(exc, timeout_sec)

        items.append(
            {
                "file_name": rel,
                "number_type": number_type,
                "predicted_text": predicted,
                "raw_text": raw_text,
                "normalized_predicted": normalized_predicted,
                "expected_label": expected_label,
                "expected_text": expected_text,
                "status_code": status_code,
                "elapsed_ms": round(elapsed_ms, 3),
                "stage_timings": stage_timings,
                "error": error,
            }
        )

    if len(images) == 1 and "/" not in images[0][0]:
        dataset_id = f"uploaded:file:{images[0][1]}"
    elif len(roots) == 1:
        dataset_id = f"uploaded:{next(iter(roots))}"
    else:
        dataset_id = "uploaded:folder"
    return _finalize_and_store_test_run(
        dataset_id=dataset_id,
        mode=mode,
        endpoint=endpoint,
        timeout_sec=timeout_sec,
        items=items,
        labels_available=bool(labels_by_stem),
        text_available=bool(text_by_stem),
    )


@app.get("/api/testing/runs")
def list_testing_runs(limit: int = Query(default=20, ge=1, le=200)) -> dict[str, Any]:
    with sqlite3.connect(ADMIN_DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            """
            SELECT id, created_at, dataset_dir, mode, labels_available, text_available, summary_json
            FROM test_runs
            ORDER BY id DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
    runs = []
    for row in rows:
        run_id = int(row["id"])
        runs.append(
            {
                "id": run_id,
                "created_at": row["created_at"],
                "dataset_dir": row["dataset_dir"],
                "mode": row["mode"],
                "labels_available": bool(row["labels_available"]),
                "text_available": bool(row["text_available"]),
                "summary": json.loads(row["summary_json"]),
                "has_report": _testing_report_path(run_id).exists(),
            }
        )
    return {"runs": runs}


@app.get("/api/testing/runs/{run_id}")
def get_testing_run(run_id: int) -> dict[str, Any]:
    run = _load_test_run_data(run_id)
    return {"run_id": run_id, "summary": run["summary"], "items": run["items"]}


@app.get("/api/testing/runs/{run_id}/report/download")
def download_testing_report(run_id: int):
    html_path = _ensure_testing_report_html_file(run_id)
    return FileResponse(
        str(html_path),
        media_type="text/html; charset=utf-8",
        filename=f"testing_report_run_{run_id}.html",
    )


@app.get("/api/testing/runs/{run_id}/report/view", response_class=HTMLResponse)
def view_testing_report(run_id: int) -> str:
    html_path = _ensure_testing_report_html_file(run_id)
    return html_path.read_text(encoding="utf-8", errors="ignore")


@app.get("/api/testing/reports/cleanup/config")
def get_testing_reports_cleanup_config() -> dict[str, Any]:
    return {"config": _reports_cleanup_settings()}


@app.post("/api/testing/reports/cleanup")
def cleanup_testing_reports(payload: CleanupReportsPayload) -> dict[str, Any]:
    return {"result": _cleanup_test_reports(mode=payload.mode, dry_run=payload.dry_run, reason="manual")}
